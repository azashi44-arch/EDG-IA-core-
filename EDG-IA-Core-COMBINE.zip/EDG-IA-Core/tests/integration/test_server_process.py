"""Test d'intégration : lance réellement `python -m edgia_core serve` et l'interroge en HTTP sur la boucle locale.

Aucun accès externe, aucun modèle, aucun GPU. Le port est choisi librement pour éviter les conflits.
"""

from __future__ import annotations

import http.client
import json
import os
import socket
import subprocess
import sys
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KEY = "integration-key-" + "x" * 16


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


class ServerProcessTest(unittest.TestCase):
    process: subprocess.Popen[bytes]
    port: int

    @classmethod
    def setUpClass(cls) -> None:
        cls.port = free_port()
        env = {
            **os.environ,
            "PYTHONPATH": str(ROOT / "src"),
            "EDGIA_PORT": str(cls.port),
            "EDGIA_API_KEYS": KEY,
            "EDGIA_LOG_LEVEL": "INFO",
        }
        cls.process = subprocess.Popen(
            [sys.executable, "-m", "edgia_core", "serve"],
            env=env,
            cwd=ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            if cls.process.poll() is not None:
                raise RuntimeError("le serveur s'est arrêté : " + cls.process.stdout.read().decode())
            try:
                if cls.call("GET", "/health")[0] == 200:
                    return
            except OSError:
                time.sleep(0.1)
        cls.process.kill()
        raise RuntimeError("le serveur n'a pas démarré dans les 15 secondes")

    @classmethod
    def tearDownClass(cls) -> None:
        cls.process.terminate()
        try:
            cls.logs = cls.process.communicate(timeout=10)[0].decode()
        except subprocess.TimeoutExpired:
            cls.process.kill()
            cls.logs = cls.process.communicate()[0].decode()

    @classmethod
    def call(cls, method: str, path: str, body: dict | None = None, key: str | None = KEY):
        connection = http.client.HTTPConnection("127.0.0.1", cls.port, timeout=10)
        headers = {}
        if key:
            headers["Authorization"] = f"Bearer {key}"
        payload = None
        if body is not None:
            payload = json.dumps(body)
            headers["Content-Type"] = "application/json"
        try:
            connection.request(method, path, body=payload, headers=headers)
            response = connection.getresponse()
            return response.status, dict(response.getheaders()), response.read()
        finally:
            connection.close()

    def test_health_and_ready(self) -> None:
        self.assertEqual(self.call("GET", "/health", key=None)[0], 200)
        status, _, body = self.call("GET", "/ready", key=None)
        self.assertEqual(status, 200)
        self.assertTrue(json.loads(body)["demo"])

    def test_authentication_is_enforced(self) -> None:
        self.assertEqual(self.call("GET", "/v1/models", key=None)[0], 401)
        self.assertEqual(self.call("GET", "/v1/models", key="mauvaise-cle")[0], 401)
        self.assertEqual(self.call("GET", "/v1/models")[0], 200)

    def test_chat_completion_over_real_http(self) -> None:
        status, headers, body = self.call("POST", "/v1/chat/completions", {"messages": [{"role": "user", "content": "Salut"}]})
        self.assertEqual(status, 200)
        data = json.loads(body)
        self.assertTrue(data["edgia"]["demo"])
        self.assertIn("PAS générée par le modèle EDG-IA entraîné", data["choices"][0]["message"]["content"])
        self.assertNotIn("server", {k.lower() for k in headers})

    def test_streaming_over_real_http(self) -> None:
        status, headers, body = self.call(
            "POST", "/v1/chat/completions", {"messages": [{"role": "user", "content": "Salut"}], "stream": True}
        )
        self.assertEqual(status, 200)
        self.assertTrue(headers["content-type"].startswith("text/event-stream"))
        events = [b[len("data: ") :] for b in body.decode().split("\n\n") if b.startswith("data: ")]
        self.assertEqual(events[-1], "[DONE]")
        self.assertGreater(len(events), 3)

    def test_unknown_route_is_json_404(self) -> None:
        status, _, body = self.call("GET", "/inconnu", key=None)
        self.assertEqual(status, 404)
        self.assertEqual(json.loads(body)["error"]["code"], "not_found")


class StartupRefusalTest(unittest.TestCase):
    def run_serve(self, **env: str) -> subprocess.CompletedProcess[str]:
        clean = {k: v for k, v in os.environ.items() if not k.startswith("EDGIA_")}
        return subprocess.run(
            [sys.executable, "-m", "edgia_core", "serve"],
            env={**clean, "PYTHONPATH": str(ROOT / "src"), "EDGIA_PORT": str(free_port()), **env},
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=30,
        )

    def test_refuses_without_api_keys(self) -> None:
        result = self.run_serve()
        self.assertEqual(result.returncode, 2)
        self.assertIn("EDGIA_API_KEYS", result.stdout)

    def test_refuses_real_mode_with_missing_model(self) -> None:
        result = self.run_serve(EDGIA_API_KEYS=KEY, EDGIA_MODE="real", EDGIA_MODEL_DESCRIPTOR=str(ROOT / "configs" / "model.example.yaml"))
        self.assertEqual(result.returncode, 2)
        self.assertIn("Poids introuvables", result.stdout)

    @unittest.skipIf(__import__("importlib.util").util.find_spec("torch") is not None, "PyTorch est installé")
    def test_real_mode_without_pytorch_refuses_and_never_serves_the_demo(self) -> None:
        import tempfile

        import yaml

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "weights").mkdir()
            (root / "weights" / "config.json").write_text("{}", encoding="utf-8")
            (root / "weights" / "model.safetensors").write_bytes(b"x")
            (root / "tok").mkdir()
            descriptor = root / "model.yaml"
            descriptor.write_text(
                yaml.safe_dump(
                    {
                        "model_id": "edgia-test",
                        "version": "1",
                        "weights_path": "weights",
                        "tokenizer_path": "tok",
                        "weights_format": "safetensors",
                        "runtime": "transformers",
                        "license": {"name": "t", "commercial_use_allowed": True, "reviewed": True},
                    }
                ),
                encoding="utf-8",
            )
            result = self.run_serve(EDGIA_API_KEYS=KEY, EDGIA_MODE="real", EDGIA_MODEL_DESCRIPTOR=str(descriptor))
        self.assertEqual(result.returncode, 2)
        self.assertIn("Dépendance absente", result.stdout)

    def test_refuses_unknown_variable(self) -> None:
        result = self.run_serve(EDGIA_API_KEYS=KEY, EDGIA_PROT="9000")
        self.assertEqual(result.returncode, 2)
        self.assertIn("EDGIA_PROT", result.stdout)


if __name__ == "__main__":
    unittest.main()
