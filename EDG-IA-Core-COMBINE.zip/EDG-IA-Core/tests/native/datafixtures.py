"""Aides de test : sources approuvées, registre, enregistrements synthétiques."""

import synthetic

from edgia_core.native.data.registry import Source, SourceRegistry

H = "a" * 64


def source(source_id, license_id="CC0-1.0", **kw):
    base = dict(source_id=source_id, name=source_id, publisher="éditeur de test", url="https://exemple.invalid/" + source_id,
                license_id=license_id, license_text_sha256=H, archive_sha256=H, acquired_at="2026-11-05", collection_version="v1",
                validator="Alice Test", validated_at="2026-11-05", decision_training="approved_training")
    base.update(kw)
    return Source(**base)


def registry():
    return SourceRegistry([
        source("pd"),
        source("by", "CC-BY-4.0", training_review_ref="avis-by-1"),
        source("sa", "CC-BY-SA-4.0"),                      # classe C sans décision juridique
        source("nc", "CC-BY-NC-4.0"),                      # classe D
        source("unk", "licence-maison"),                   # classe E
        source("pending", decision_training="pending"),
    ])


def records(n=50, words=300, seed=3, source_id="pd", license_id="CC0-1.0", lang="fr"):
    return [{"text": t, "source_id": source_id, "license_id": license_id, "lang": lang} for t in synthetic.make_documents(n, words_per_doc=words, seed=seed)]
