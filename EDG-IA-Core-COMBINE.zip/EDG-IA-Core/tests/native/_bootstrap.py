"""Rend `edgia_core` (src/) et les aides de test (tests/native/) importables, sous unittest comme sous pytest."""

import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
for _p in (ROOT / "src", ROOT / "tests" / "native"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))
sys.dont_write_bytecode = True
