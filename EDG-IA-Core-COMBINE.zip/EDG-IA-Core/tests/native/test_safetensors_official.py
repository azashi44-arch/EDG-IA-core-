"""Test croisé avec la bibliothèque OFFICIELLE `safetensors` (SAUTÉ si elle est absente — c'était le cas lors de L0)."""

import tempfile
import unittest
from pathlib import Path

import _bootstrap  # noqa: F401
import numpy as np

try:
    import safetensors.numpy as official
except ImportError:  # pragma: no cover
    official = None

from edgia_core.native import safetensors_io as st


@unittest.skipIf(official is None, "bibliothèque officielle `safetensors` absente : compatibilité croisée NON vérifiée")
class TestCrossCompat(unittest.TestCase):
    def test_we_write_official_reads_and_vice_versa(self):
        tensors = {"a": np.arange(12, dtype=np.float32).reshape(3, 4), "b": np.arange(5, dtype=np.int64), "c": np.zeros((0, 2), dtype=np.float32)}
        with tempfile.TemporaryDirectory() as d:
            ours, theirs = Path(d) / "ours.safetensors", Path(d) / "theirs.safetensors"
            st.save(ours, tensors, {"k": "v"})
            loaded = official.load_file(str(ours))
            for k, v in tensors.items():
                self.assertTrue(np.array_equal(loaded[k], v), k)
            official.save_file(tensors, str(theirs), metadata={"k": "v"})
            back, meta = st.load_numpy(theirs)
            self.assertEqual(meta, {"k": "v"})
            for k, v in tensors.items():
                self.assertTrue(np.array_equal(back[k], v), k)


if __name__ == "__main__":
    unittest.main()
