"""Intégration additive avec Core : descripteur, dispatch du runtime, non-régression des runtimes existants. SAUTÉ sans pydantic.

!!! ÉCRIT mais NON EXÉCUTÉ lors de la livraison L0 (pydantic/starlette absents de l'environnement de développement).
Pour la suite de tests EXISTANTE de Core : python -m pytest tests/unit  (à lancer chez vous après installation de Core).
"""

import tempfile
import unittest
from pathlib import Path
from unittest import mock

import _bootstrap  # noqa: F401
import numpy as np
import synthetic

try:
    import pydantic  # noqa: F401
    HAVE_CORE = True
except ImportError:  # pragma: no cover
    HAVE_CORE = False

from edgia_core.native.config import PRESETS
from edgia_core.native.reference.numpy_model import init_params
from edgia_core.native.tokenizer.tokenizer import TrainCorpus, train_tokenizer
from edgia_core.native.train.export import export_model


@unittest.skipIf(not HAVE_CORE, "pydantic absent : intégration Core non exécutée")
class TestDescriptorAndLoader(unittest.TestCase):
    def descriptor(self, **kw):
        from edgia_core.model.descriptor import LicenseInfo, ModelDescriptor, Runtime, WeightsFormat

        base = dict(model_id="edgia-native-test", version="0", weights_path=Path("."), tokenizer_path=Path("."),
                    weights_format=WeightsFormat.EDGIA_SAFETENSORS, runtime=Runtime.EDGIA_NATIVE,
                    license=LicenseInfo(name="EDG-IA", commercial_use_allowed=True, reviewed=True))
        base.update(kw)
        return ModelDescriptor(**base)

    def test_new_runtime_and_format_are_accepted_and_consistent(self):
        from pydantic import ValidationError

        from edgia_core.model.descriptor import Runtime, WeightsFormat

        self.assertEqual(self.descriptor().runtime, Runtime.EDGIA_NATIVE)
        with self.assertRaises(ValidationError):
            self.descriptor(runtime=Runtime.TRANSFORMERS)                    # format edgia-safetensors ⇒ runtime edgia_native
        with self.assertRaises(ValidationError):
            self.descriptor(tokenizer_path=None)                              # tokenizer obligatoire
        # non-régression : combinaisons existantes toujours valides
        self.descriptor(weights_format=WeightsFormat.SAFETENSORS, runtime=Runtime.TRANSFORMERS)
        self.descriptor(weights_format=WeightsFormat.GGUF, runtime=Runtime.LLAMA_CPP, tokenizer_path=None)

    def test_build_engine_dispatch_is_lazy_and_other_runtimes_unchanged(self):
        from edgia_core.errors import ConfigurationError
        from edgia_core.model import loader
        from edgia_core.model.descriptor import Runtime, WeightsFormat

        with mock.patch("edgia_core.native.backend.build_native_engine", return_value="engine") as builder:
            self.assertEqual(loader.build_engine(mock.MagicMock(), self.descriptor()), "engine")
            builder.assert_called_once()
        with self.assertRaises(ConfigurationError):                           # llama_cpp : comportement d'origine conservé
            loader.build_engine(mock.MagicMock(), self.descriptor(weights_format=WeightsFormat.GGUF, runtime=Runtime.LLAMA_CPP, tokenizer_path=None))

    def test_check_model_accepts_a_real_export_directory(self):
        from edgia_core.model.descriptor import check_model

        tok = train_tokenizer(TrainCorpus("train", [synthetic.make_text(120_000)]), profile="smoke")
        with tempfile.TemporaryDirectory() as d:
            export_model(init_params(PRESETS["smoke"], dtype=np.float32), PRESETS["smoke"], tok, Path(d) / "m", status="smoke_test")
            problems = check_model(self.descriptor(weights_path=Path(d) / "m", tokenizer_path=Path(d) / "m"))
            self.assertEqual([p for p in problems if "introuvable" in p or "absent" in p], [])


@unittest.skipIf(not HAVE_CORE, "pydantic absent")
class TestStaticContract(unittest.TestCase):
    def test_backend_implements_the_abstract_interface(self):
        import ast

        src = (Path(__file__).resolve().parents[2] / "src/edgia_core/native/backend.py").read_text(encoding="utf-8")
        methods = {n.name for n in ast.walk(ast.parse(src)) if isinstance(n, ast.FunctionDef)}
        self.assertTrue({"count_prompt_tokens", "stream", "close"} <= methods)


if __name__ == "__main__":
    unittest.main()
