"""Checkpoints atomiques, reprise, niveaux de reproductibilité, planificateur — S3, S4, S4b, S5, S13, S15, M13 (sans PyTorch)."""

import json
import math
import random
import tempfile
import unittest
from pathlib import Path

import _bootstrap  # noqa: F401
import datafixtures as fx
import numpy as np
import synthetic
from toy_trainer import FINGERPRINTS, ToyTrainer, capture_rng

from edgia_core.native.config import TrainConfig
from edgia_core.native.data.loader import WindowLoader
from edgia_core.native.data.manifest import train_shard_paths
from edgia_core.native.data.pipeline import DataConfig, build_dataset
from edgia_core.native.errors import CheckpointError
from edgia_core.native.train import checkpoint as ckpt
from edgia_core.native.train.env import capture_environment, compare_environments
from edgia_core.native.train.schedule import lr_at, warmup_steps

TC = TrainConfig(seed=5, max_steps=40, peak_lr=5e-3, warmup_frac=0.1, weight_decay=0.1, grad_clip=1.0)


def mk(step=1, **extra):
    return dict(model={"w": np.full(3, float(step))}, optimizer={"w.exp_avg": np.zeros(3)}, trainer_state={"fingerprints": FINGERPRINTS, **extra},
                rng_state={"x": 1})


class TestSchedule(unittest.TestCase):
    def test_m13_exact_values(self):
        cfg = TrainConfig(max_steps=100, peak_lr=1e-3, warmup_frac=0.1, min_lr_frac=0.1)
        self.assertEqual(warmup_steps(cfg), 10)
        self.assertAlmostEqual(lr_at(0, cfg), 1e-4, places=15)             # peak·1/10
        self.assertAlmostEqual(lr_at(4, cfg), 5e-4, places=15)             # peak·5/10
        self.assertAlmostEqual(lr_at(9, cfg), 1e-3, places=15)             # fin d'échauffement
        self.assertAlmostEqual(lr_at(10, cfg), 1e-3, places=15)            # début de la décroissance = pic
        mid = 1e-4 + 0.5 * (1e-3 - 1e-4) * (1 + math.cos(math.pi * 45 / 90))
        self.assertAlmostEqual(lr_at(55, cfg), mid, places=15)             # milieu : moyenne pic/min
        self.assertAlmostEqual(mid, 5.5e-4, places=12)
        last = lr_at(99, cfg)
        self.assertGreater(last, 1e-4)
        self.assertLess(last, 1.1e-4)
        values = [lr_at(s, cfg) for s in range(10, 100)]
        self.assertTrue(all(a >= b for a, b in zip(values, values[1:])))  # décroissante après l'échauffement
        with self.assertRaises(ValueError):
            lr_at(-1, cfg)

    def test_no_warmup_and_constant(self):
        self.assertEqual(lr_at(0, TrainConfig(max_steps=10, warmup_frac=0.0, peak_lr=1.0, min_lr_frac=1.0)), 1.0)


class TestCheckpointFiles(unittest.TestCase):
    def test_s3_crash_leaves_last_valid_checkpoint_intact(self):
        for crash_after in ("model.safetensors", "optimizer.safetensors", "rng.json"):
            with tempfile.TemporaryDirectory() as d:
                ckpt.save_checkpoint(d, 10, **mk(1))
                with self.assertRaises(RuntimeError):
                    ckpt.save_checkpoint(d, 20, **mk(2), _fail_after=crash_after)
                self.assertEqual(ckpt.list_checkpoints(d), [10], crash_after)
                self.assertEqual(ckpt.verify_checkpoint(Path(d) / "step_000010"), [])
                self.assertTrue((Path(d) / ".tmp_step_000020").exists())      # débris ignoré…
                ckpt.save_checkpoint(d, 20, **mk(2))                           # …et nettoyé à la sauvegarde suivante
                self.assertEqual(ckpt.list_checkpoints(d), [10, 20])
                self.assertFalse((Path(d) / ".tmp_step_000020").exists())

    def test_incomplete_directory_is_never_listed(self):
        with tempfile.TemporaryDirectory() as d:
            ckpt.save_checkpoint(d, 10, **mk())
            (Path(d) / "step_000020").mkdir()                                  # dossier au bon nom mais sans COMPLETE
            (Path(d) / "step_000030").mkdir(); (Path(d) / "step_000030" / "model.safetensors").write_bytes(b"x")
            self.assertEqual(ckpt.list_checkpoints(d), [10])
            self.assertEqual(ckpt.list_checkpoints(Path(d) / "absent"), [])

    def test_corruption_is_detected(self):
        with tempfile.TemporaryDirectory() as d:
            path = ckpt.save_checkpoint(d, 10, **mk())
            self.assertEqual(ckpt.verify_checkpoint(path), [])
            raw = bytearray((path / "model.safetensors").read_bytes()); raw[-1] ^= 1; (path / "model.safetensors").write_bytes(bytes(raw))
            self.assertTrue(any("model.safetensors" in p for p in ckpt.verify_checkpoint(path)))
            with self.assertRaises(CheckpointError):
                ckpt.load_checkpoint(path)
            path2 = ckpt.save_checkpoint(d, 20, **mk())
            manifest = json.loads((path2 / "MANIFEST.json").read_text()); manifest["step"] = 99
            (path2 / "MANIFEST.json").write_text(json.dumps(manifest))
            self.assertTrue(any("COMPLETE" in p for p in ckpt.verify_checkpoint(path2)))
            path3 = ckpt.save_checkpoint(d, 30, **mk())
            (path3 / "rng.json").unlink()
            self.assertTrue(any("rng.json" in p for p in ckpt.verify_checkpoint(path3)))
            (path3 / "COMPLETE").unlink()
            self.assertEqual(ckpt.verify_checkpoint(path3), ["marqueur COMPLETE absent"])

    def test_never_overwrites_a_different_checkpoint(self):
        with tempfile.TemporaryDirectory() as d:
            ckpt.save_checkpoint(d, 10, **mk(1))
            ckpt.save_checkpoint(d, 10, **mk(1))                               # contenu identique : idempotent
            with self.assertRaises(CheckpointError):
                ckpt.save_checkpoint(d, 10, **mk(2))
            self.assertEqual(ckpt.load_checkpoint(Path(d) / "step_000010")["model"]["w"][0], 1.0)

    def test_retention(self):
        with tempfile.TemporaryDirectory() as d:
            for s in range(100, 1100, 100):
                ckpt.save_checkpoint(d, s, **mk(s))
            removed = ckpt.apply_retention(d, keep_last=2, milestone_every=500, best_step=300)
            self.assertEqual(ckpt.list_checkpoints(d), [300, 500, 900, 1000])
            self.assertEqual(removed, [100, 200, 400, 600, 700, 800])

    def test_state_is_json_only_no_pickle(self):
        with tempfile.TemporaryDirectory() as d:
            path = ckpt.save_checkpoint(d, 5, **mk(5, extra="é"))
            for name in ("trainer_state.json", "rng.json", "MANIFEST.json"):
                json.loads((path / name).read_text(encoding="utf-8"))
            self.assertEqual(sorted(p.name for p in path.iterdir()), sorted(ckpt.FILES + ("MANIFEST.json", "COMPLETE")))


class TestResumeMechanics(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.out = Path(cls.tmp.name) / "ds"
        build_dataset(fx.records(60, words=300, seed=9), fx.registry(), DataConfig(val_rate=0.1, test_rate=0.1, min_chars=50,
                      tokenizer_profile="smoke", shard_tokens=5000), cls.out)
        cls.paths = train_shard_paths(cls.out)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def trainer(self, root, **kw):
        return ToyTrainer(WindowLoader(self.paths, 32, TC.seed, 4), TC, Path(root), **kw)

    def straight(self):
        with tempfile.TemporaryDirectory() as d:
            t = self.trainer(d)
            t.run_to(40)
            return t

    def interrupted(self, **kw):
        with tempfile.TemporaryDirectory() as d:
            a = self.trainer(d)
            a.run_to(20)
            a.save()
            random.seed(999); np.random.seed(999)                              # le processus « redémarre » avec un autre état aléatoire
            b = self.trainer(d, **kw)
            b.load_latest()
            self.assertEqual(b.step, 20)
            b.run_to(40)
            return b

    def test_s4_resume_is_bit_exact_on_cpu(self):
        ref, res = self.straight(), self.interrupted()
        for k in ref.p:
            self.assertTrue(np.array_equal(ref.p[k], res.p[k]), k)
            self.assertTrue(np.array_equal(ref.m[k], res.m[k]), k)
            self.assertTrue(np.array_equal(ref.v[k], res.v[k]), k)
        self.assertEqual(ref.t, res.t)
        self.assertEqual(ref.losses[20:], res.losses)
        self.assertLess(ref.losses[-1], ref.losses[0])                          # l'entraînement apprend quelque chose

    def test_s4b_forgetting_adam_step_counter_changes_the_result(self):
        """Preuve de sensibilité : la même reprise, compteur de pas d'Adam NON restauré, donne un résultat DIFFÉRENT."""
        ref, bad = self.straight(), self.interrupted(restore_adam_step=False)
        self.assertTrue(any(not np.array_equal(ref.p[k], bad.p[k]) for k in ref.p))

    def test_s13_no_hidden_randomness(self):
        ref = self.straight()
        with tempfile.TemporaryDirectory() as d:
            t = self.trainer(d, perturb_rng=True)
            t.run_to(40)
        for k in ref.p:
            self.assertTrue(np.array_equal(ref.p[k], t.p[k]), k)

    def test_s5_resume_refused_when_a_fingerprint_differs(self):
        with tempfile.TemporaryDirectory() as d:
            t = self.trainer(d)
            t.run_to(3)
            t.save()
            state = ckpt.load_checkpoint(Path(d) / "step_000003")["trainer_state"]
            ckpt.check_resume_compatibility(state, FINGERPRINTS)
            for key in FINGERPRINTS:
                with self.assertRaises(CheckpointError, msg=key):
                    ckpt.check_resume_compatibility(state, {**FINGERPRINTS, key: "autre"})
            with self.assertRaises(CheckpointError):
                ckpt.check_resume_compatibility({"fingerprints": {}}, FINGERPRINTS)

    def test_rng_state_round_trip(self):
        random.seed(3); np.random.seed(3)
        state = capture_rng()
        expected = (random.random(), float(np.random.rand()))
        random.seed(0); np.random.seed(0)
        from toy_trainer import restore_rng

        restore_rng(json.loads(json.dumps(state)))
        self.assertEqual((random.random(), float(np.random.rand())), expected)


class TestEnvironmentLevels(unittest.TestCase):
    base = {f: "x" for f in ("python", "numpy", "torch", "cuda", "cudnn", "device_name", "device_capability", "device_count", "tf32_matmul",
                             "tf32_cudnn", "matmul_precision", "attention_backend")}
    base.update(device_type="cpu", precision="fp32", deterministic=True, num_threads=1, compiled=False, micro_batch_seqs=8, accumulation_steps=32)

    def test_s15_levels(self):
        self.assertEqual(compare_environments(self.base, dict(self.base)), ("A", []))
        gpu = {**self.base, "device_type": "cuda", "precision": "bf16"}
        self.assertEqual(compare_environments(gpu, dict(gpu)), ("B", []))                                  # GPU : fidèle, pas bit à bit
        self.assertEqual(compare_environments({**self.base, "deterministic": False}, {**self.base, "deterministic": False})[0], "B")
        self.assertEqual(compare_environments({**self.base, "num_threads": 4}, {**self.base, "num_threads": 4})[0], "B")
        for field, other in (("torch", "9.9"), ("device_name", "RTX"), ("precision", "bf16"), ("micro_batch_seqs", 4), ("num_threads", 2),
                             ("attention_backend", "flash"), ("compiled", True), ("python", "3.99")):
            level, diffs = compare_environments(self.base, {**self.base, field: other})
            self.assertEqual((level, diffs), ("C", [field]), field)

    def test_capture_environment_has_the_fields(self):
        env = capture_environment({"precision": "fp32", "deterministic": True})
        for key in ("python", "numpy", "platform", "device_type", "precision", "deterministic"):
            self.assertIn(key, env)
        self.assertEqual(env["precision"], "fp32")


if __name__ == "__main__":
    unittest.main()
