"""Modèle PyTorch vs référence NumPy (M1, M4–M9, M11, M12, M15, M17). SAUTÉS sans PyTorch.

!!! Ces tests sont ÉCRITS mais n'ont PAS été exécutés lors de la livraison L0 (PyTorch absent de l'environnement de développement).
À lancer : pip install -e .[native] puis  python tools/run_native_tests.py test_torch_model -v
"""

import unittest

import _bootstrap  # noqa: F401
import numpy as np

try:
    import torch
except ImportError:  # pragma: no cover
    torch = None

from edgia_core.native import naming
from edgia_core.native.config import PRESETS, PROFILE_TEST, ModelConfig
from edgia_core.native.errors import ConfigError
from edgia_core.native.reference import numpy_model as R

CFG = ModelConfig("t", PROFILE_TEST, 97, 32, 2, 4, 2, 8, 64, 40)


def strong(cfg, seed=3):
    params = R.init_params(cfg, seed=seed, dtype=np.float32)
    for k in params:
        if k.endswith("proj.weight"):
            params[k] = params[k] * 15
    return params


@unittest.skipIf(torch is None, "PyTorch absent : tests du modèle PyTorch non exécutés")
class TestTorchModel(unittest.TestCase):
    def build(self, cfg=CFG, params=None):
        from edgia_core.native.model import EdgiaModel

        model = EdgiaModel(cfg, init=False)
        model.load_tensors(params if params is not None else strong(cfg))
        return model.eval()

    def test_m1_param_count_including_xs_on_meta_device(self):
        from edgia_core.native.model import EdgiaModel

        with torch.device("meta"):
            xs = EdgiaModel(PRESETS["xs"], init=False)
        self.assertEqual(sum(p.numel() for p in xs.parameters()), 25_172_352)  # embedding partagé compté une fois

    def test_m15_tied_weights_no_lm_head_and_strict_loading(self):
        model = self.build()
        self.assertEqual(set(model.state_dict()), set(naming.expected_shapes(CFG)))
        self.assertFalse([k for k in model.state_dict() if "lm_head" in k])
        broken = strong(CFG); del broken[naming.FINAL_NORM]
        with self.assertRaises(ConfigError):
            self.build(params=broken)
        wrong = strong(CFG); wrong[naming.EMBEDDING] = wrong[naming.EMBEDDING][:-1]
        with self.assertRaises(ConfigError):
            self.build(params=wrong)

    def test_m17_logits_match_numpy_reference(self):
        params = strong(CFG)
        model = self.build(params=params)
        ref_params = {k: v.astype(np.float64) for k, v in params.items()}
        for length in (1, 7, 30, 40):
            ids = np.random.default_rng(length).integers(0, 97, size=length)
            with torch.no_grad():
                got = model(torch.tensor(ids)[None])[0].numpy()
            np.testing.assert_allclose(got, R.forward(ref_params, CFG, ids), rtol=1e-3, atol=1e-3)

    def test_m4_rope_matches_numpy(self):
        from edgia_core.native.model import apply_rope, rope_tables

        cos, sin = rope_tables(CFG)
        x = torch.randn(1, 2, 6, CFG.head_dim)
        got = apply_rope(x, cos[3:9], sin[3:9])[0, 1].numpy()
        np.testing.assert_allclose(got, R.apply_rope(x[0, 1].numpy().astype(np.float64), np.arange(3, 9), CFG.rope_theta), atol=1e-5)

    def test_m5_causality(self):
        model = self.build()
        ids = torch.tensor(np.random.default_rng(1).integers(0, 97, size=(1, 30)))
        with torch.no_grad():
            full = model(ids)
            for t in (0, 9, 28):
                changed = ids.clone(); changed[:, t + 1:] = (changed[:, t + 1:] + 13) % 97
                self.assertTrue(torch.equal(model(changed)[:, : t + 1], full[:, : t + 1]), t)

    def test_m9_kv_cache_equals_full_forward_for_every_chunking(self):
        """Inclut le cas dangereux : un morceau de plusieurs tokens AVEC un cache non vide (is_causal=True y serait FAUX)."""
        from edgia_core.native.model import KVCache

        model = self.build()
        ids = torch.tensor(np.random.default_rng(2).integers(0, 97, size=(1, 30)))
        with torch.no_grad():
            full = model(ids)
            for bounds in ([(0, 10)] + [(i, i + 1) for i in range(10, 30)], [(0, 5), (5, 8), (8, 9), (9, 16), (16, 17), (17, 30)],
                           [(i, i + 1) for i in range(30)], [(0, 15), (15, 30)]):
                cache = KVCache(CFG)
                out = torch.cat([model(ids[:, a:b], cache) for a, b in bounds], dim=1)
                torch.testing.assert_close(out, full, rtol=1e-4, atol=1e-4)
                self.assertEqual(cache.length, 30)
            with self.assertRaises(ValueError):   # le cache contient 30 tokens, le contexte maximal est 40 : 30 + 40 > 40
                model(torch.zeros(1, 40, dtype=torch.long), cache)

    def test_m6_gqa_mapping_matches_numpy(self):
        params = strong(CFG)
        model = self.build(params=params)
        ids = np.random.default_rng(3).integers(0, 97, size=12)
        with torch.no_grad():
            got = model(torch.tensor(ids)[None])[0].numpy()
        np.testing.assert_allclose(got, R.forward({k: v.astype(np.float64) for k, v in params.items()}, CFG, ids), rtol=1e-3, atol=1e-3)

    def test_m12_loss_shift_and_value(self):
        from edgia_core.native.model import language_model_loss

        model = self.build()
        seq = torch.tensor(np.random.default_rng(4).integers(0, 97, size=(3, 21)))
        with torch.no_grad():
            loss = float(language_model_loss(model, seq))
            logits = model(seq[:, :-1]).numpy().reshape(-1, 97)
        manual = R.cross_entropy(logits.astype(np.float64), seq[:, 1:].numpy().reshape(-1))
        self.assertAlmostEqual(loss, manual, places=4)

    def test_m11_overfits_one_batch(self):
        from edgia_core.native.model import EdgiaModel, language_model_loss

        torch.manual_seed(0)
        model = EdgiaModel(CFG, init=True)
        batch = torch.tensor(np.random.default_rng(5).integers(0, 97, size=(2, 17)))
        optimizer = torch.optim.AdamW(model.parameters(), lr=3e-3, weight_decay=0.0)
        for _ in range(400):
            optimizer.zero_grad(); language_model_loss(model, batch).backward(); optimizer.step()
        self.assertLess(float(language_model_loss(model, batch)), 0.05)

    def test_tied_embedding_receives_gradient_from_the_output_path(self):
        from edgia_core.native.model import EdgiaModel, language_model_loss

        model = EdgiaModel(CFG, init=True)
        batch = torch.tensor([[1, 2, 3, 4, 5, 6]])
        language_model_loss(model, batch).backward()
        grad = model.tok_embeddings.weight.grad
        absent = [t for t in range(97) if t not in (1, 2, 3, 4, 5)]
        self.assertTrue(bool((grad[absent].abs().sum(dim=1) > 0).all()))  # tokens jamais en entrée : gradient venant de la sortie

    def test_initial_loss_matches_the_numpy_measurement_interval(self):
        from edgia_core.native.model import EdgiaModel, language_model_loss

        with torch.no_grad():
            xs = EdgiaModel(PRESETS["xs"], init=True)
            batch = torch.randint(128, 32768, (1, 65))
            self.assertTrue(10.3 < float(language_model_loss(xs, batch)) < 10.8)


if __name__ == "__main__":
    unittest.main()
