"""M1 (nombre de paramètres, généralisé) et S1 (configuration invalide)."""

import unittest

import _bootstrap  # noqa: F401
import numpy as np

from edgia_core.native import naming
from edgia_core.native.config import (EXPECTED_PARAMS, PRESETS, PROFILE_PRODUCTION, PROFILE_TEST, ModelConfig, TrainConfig,
                                      ffn_dim_for)
from edgia_core.native.errors import ConfigError
from edgia_core.native.reference import numpy_model as R


def make(**kw):
    base = dict(name="t", profile=PROFILE_TEST, vocab_size=97, d_model=32, n_layers=2, n_heads=4, n_kv_heads=2, head_dim=8,
                ffn_dim=64, max_seq_len=40)
    base.update(kw)
    return ModelConfig(**base)


class TestParamCount(unittest.TestCase):
    def test_spec_table_values(self):
        for name, expected in EXPECTED_PARAMS.items():
            self.assertEqual(PRESETS[name].param_count(), expected, name)
        self.assertEqual(PRESETS["xs"].param_count(), 25_172_352)

    def test_formula_equals_sum_of_shapes(self):
        """La formule du §3.4 = somme des formes canoniques (embedding compté une seule fois) pour XS, S, M, L et des cas limites."""
        configs = list(PRESETS.values()) + [make(), make(n_kv_heads=4), make(ffn_dim=50), make(d_model=16, n_heads=2, head_dim=8, n_kv_heads=1)]
        for cfg in configs:
            self.assertEqual(cfg.param_count(), naming.total_params_from_shapes(naming.expected_shapes(cfg)), cfg.name)

    def test_numpy_init_allocates_exactly_that_many(self):
        """Comptage indépendant : on alloue réellement les tableaux de la référence et on additionne leurs tailles."""
        for cfg in (PRESETS["smoke"], make(), make(n_kv_heads=4)):
            self.assertEqual(R.param_count(R.init_params(cfg)), cfg.param_count())
        xs = PRESETS["xs"]
        self.assertEqual(R.param_count(R.init_params(xs, dtype=np.float32)), 25_172_352)

    def test_no_output_matrix(self):
        self.assertFalse([n for n in naming.expected_shapes(PRESETS["xs"]) if "lm_head" in n or "output" in n])

    def test_ffn_dim_rule(self):
        self.assertEqual([ffn_dim_for(d) for d in (384, 768, 1024, 2048)], [1024, 2048, 2752, 5504])

    def test_kv_cache_size_xs(self):
        self.assertEqual(PRESETS["xs"].kv_cache_elements() * 2, 4 * 1024 * 1024)  # 4 Mio en bf16


class TestInvalidConfigs(unittest.TestCase):
    def test_rejections(self):
        bad = [
            dict(d_model=30), dict(n_heads=3), dict(n_kv_heads=3), dict(head_dim=7, d_model=28), dict(vocab_size=0),
            dict(tie_embeddings=False), dict(profile="inconnu"), dict(profile=PROFILE_PRODUCTION),  # vocab ≠ 32768
            dict(vocab_size=70_000), dict(rope_theta=0.5), dict(rms_eps=0.5), dict(init_std=2.0), dict(max_seq_len=0),
        ]
        for kw in bad:
            with self.assertRaises(ConfigError, msg=str(kw)):
                make(**kw)

    def test_unknown_key_rejected(self):
        with self.assertRaises(ConfigError):
            ModelConfig.from_dict({**make().to_dict(), "bogus": 1})

    def test_hash_is_stable_and_sensitive(self):
        self.assertEqual(make().config_hash(), make().config_hash())
        self.assertNotEqual(make().config_hash(), make(seed=1).config_hash())

    def test_train_config_checks(self):
        xs = PRESETS["xs"]
        TrainConfig().validate(xs)
        for kw in (dict(batch_tokens=1000), dict(micro_batch_seqs=7), dict(micro_batch_seqs=0),
                   dict(precision="fp16"), dict(status="x"), dict(peak_lr=0), dict(grad_clip=0),
                   dict(beta1=1.0), dict(ckpt_every_minutes=0), dict(weight_decay=-0.1)):
            with self.assertRaises(ConfigError, msg=str(kw)):
                TrainConfig(**kw).validate(xs)


if __name__ == "__main__":
    unittest.main()
