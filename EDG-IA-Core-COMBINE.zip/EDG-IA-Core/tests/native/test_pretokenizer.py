"""Pré-découpage : propriétés, cas à la main et test DIFFÉRENTIEL contre `re` sur un alphabet restreint (ASCII + Latin-1)."""

import random
import re
import unittest

import _bootstrap  # noqa: F401

from edgia_core.native.tokenizer.pretokenizer import split_text

# Même motif que la spécification, avec \p{L} → lettres ASCII/Latin-1 et \p{N} → [0-9] (valable sur cet alphabet seulement).
_L = "A-Za-zÀ-ÖØ-öø-ÿ"
_PATTERN = re.compile(
    rf"(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\r\n{_L}0-9]?[{_L}]+|[0-9]| ?[^\s{_L}0-9]+[\r\n]*|\s*[\r\n]+|\s+(?!\S)|\s+"
)
_ALPHABET = list("abcXYZéàÇ09 '.,!?-\n\r\t") + ["\u00a0", "ß", "ÿ"]


class TestPretokenizer(unittest.TestCase):
    def test_concatenation_restores_text(self):
        rng = random.Random(1)
        pool = _ALPHABET + list("日本🙂\u0301\x0b\x0c")
        for _ in range(3000):
            text = "".join(rng.choice(pool) for _ in range(rng.randint(0, 40)))
            self.assertEqual("".join(split_text(text)), text)

    def test_differential_against_re(self):
        rng = random.Random(2)
        for _ in range(6000):
            text = "".join(rng.choice(_ALPHABET) for _ in range(rng.randint(0, 30)))
            self.assertEqual(split_text(text), _PATTERN.findall(text), repr(text))

    def test_hand_checked_french(self):
        self.assertEqual(split_text("l'été d'aujourd'hui"), ["l", "'été", " d", "'aujourd", "'hui"])
        self.assertEqual(split_text("2026"), ["2", "0", "2", "6"])
        self.assertEqual(split_text("Hello, world!"), ["Hello", ",", " world", "!"])
        self.assertEqual(split_text("a\n\nb"), ["a", "\n\n", "b"])
        self.assertEqual(split_text("don't"), ["don", "'t"])
        self.assertEqual(split_text(""), [])

    def test_digits_always_isolated(self):
        for chunk in split_text("abc123def4567"):
            if any(c.isdigit() for c in chunk):
                self.assertEqual(len(chunk), 1)


if __name__ == "__main__":
    unittest.main()
