"""Pipeline de données : nettoyage, doublons, groupes, découpage sans fuite, fragments, index, manifeste, chargeur
(S6–S8, S14, T12, T13 au niveau du pipeline)."""

import json
import random
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import _bootstrap  # noqa: F401
import datafixtures as fx
import numpy as np
import synthetic

from edgia_core.native.data import pipeline
from edgia_core.native.data.dedup import MinHasher, UnionFind, build_groups, estimated_jaccard, find_near_duplicates
from edgia_core.native.data.loader import WindowLoader
from edgia_core.native.data.manifest import load_manifest, train_shard_paths, verify_manifest
from edgia_core.native.data.pipeline import DataConfig, build_dataset
from edgia_core.native.data.split import assert_no_leak, assign_groups, leak_filter
from edgia_core.native.data.text import guess_lang, make_doc_id, normalize_text, scrub_pii
from edgia_core.native.errors import DataError
from edgia_core.native.tokenizer import specials
from edgia_core.native.tokenizer.tokenizer import EdgiaTokenizer

CFG = DataConfig(val_rate=0.2, test_rate=0.2, min_chars=50, tokenizer_profile="smoke", shard_tokens=6000, tokdev_permille=100)


def edit_words(text, fraction, seed=0):
    """Variante d'un texte : remplace `fraction` des mots par d'autres mots (modifications réparties)."""
    rng = random.Random(seed)
    words = text.split(" ")
    for i in range(len(words)):
        if rng.random() < fraction:
            words[i] = "zz" + words[i][::-1]
    return " ".join(words)


class TestTextCleaning(unittest.TestCase):
    def test_normalize_and_doc_id(self):
        self.assertEqual(normalize_text("  e\u0301\r\nx\x00y\x07 \n"), "é\nxy")
        self.assertEqual(make_doc_id("abc"), make_doc_id("abc"))
        self.assertEqual(len(make_doc_id("abc")), 32)
        self.assertNotEqual(make_doc_id("abc"), make_doc_id("abd"))

    def test_language_guess(self):
        self.assertEqual(guess_lang("le chat est dans la maison et il ne veut pas sortir de la cuisine avec nous"), "fr")
        self.assertEqual(guess_lang("the cat is in the house and it does not want to go out of the kitchen"), "en")
        self.assertEqual(guess_lang("xyz qrs tuv wxy zzz aaa bbb ccc ddd eee"), "other")
        self.assertEqual(guess_lang("trop court"), "other")

    def test_pii_scrubbing_and_false_positives(self):
        text = "Mail a.b@ex.fr, tel 06 12 34 56 78, carte 4111 1111 1111 1111, IBAN FR76 3000 6000 0112 3456 7890 189, ip 10.0.0.1"
        out, counts = scrub_pii(text)
        for secret in ("a.b@ex.fr", "06 12 34 56 78", "4111", "FR76", "10.0.0.1"):
            self.assertNotIn(secret, out)
        self.assertEqual(set(counts), {"EMAIL", "TELEPHONE", "CARTE", "IBAN", "IP"})
        keep = "En 2026, 1234567890123456 n'est pas une carte (Luhn), version 1.2.3, page 12."
        self.assertEqual(scrub_pii(keep)[0], keep)


class TestNearDuplicates(unittest.TestCase):
    def test_recall_is_measured_and_high_for_light_edits(self):
        docs = synthetic.make_documents(60, words_per_doc=400, seed=21)
        ids = [f"d{i}" for i in range(len(docs))]
        variants, labels = [], []
        for i in range(0, 30):
            kind = ("append", "edit1", "edit5")[i % 3]
            text = docs[i] + " " + docs[i][:300] if kind == "append" else edit_words(docs[i], 0.01 if kind == "edit1" else 0.05, seed=i)
            variants.append(text); labels.append(kind)
        all_texts = docs + variants
        all_ids = ids + [f"v{i}" for i in range(len(variants))]
        pairs, stats = find_near_duplicates(all_ids, all_texts, hasher=MinHasher(), threshold=0.8)
        found = {frozenset((a, b)) for a, b, _ in pairs}
        recall = {}
        for kind in ("append", "edit1", "edit5"):
            idx = [i for i, k in enumerate(labels) if k == kind]
            recall[kind] = sum(frozenset((f"d{i}", f"v{i}")) in found for i in idx) / len(idx)
        print(f"\n[mesure S14] rappel de détection des quasi-doublons (seuil 0,8) : {recall}")
        self.assertGreaterEqual(recall["append"], 0.9)
        self.assertGreaterEqual(recall["edit1"], 0.9)
        # edit5 (5 % de mots modifiés ≈ 22 % des empreintes de 5 mots changées) : rappel publié, AUCUN seuil promis
        false_pairs = [p for p in found if not (len(p) == 2 and {x[0] for x in p} == {"d", "v"} and len({x[1:] for x in p}) == 1)]
        self.assertEqual(false_pairs, [])  # aucun faux positif entre documents indépendants

    def test_jaccard_estimate_is_sane(self):
        h = MinHasher()
        a = synthetic.make_text(600, seed=1)
        self.assertEqual(estimated_jaccard(h.signature(a), h.signature(a)), 1.0)
        self.assertLess(estimated_jaccard(h.signature(a), h.signature(synthetic.make_text(600, seed=2))), 0.1)

    def test_signature_is_deterministic_and_handles_tiny_texts(self):
        h = MinHasher()
        self.assertTrue(np.array_equal(h.signature("a b c d e f g"), h.signature("a b c d e f g")))
        self.assertEqual(h.signature("").shape, (128,))
        self.assertEqual(h.signature("deux mots").shape, (128,))

    def test_groups_union_find(self):
        uf = UnionFind()
        for a, b in (("c", "b"), ("b", "a"), ("x", "y")):
            uf.union(a, b)
        self.assertEqual(uf.find("c"), "a")
        groups = build_groups(["a", "b", "c", "x", "y", "z"], [None, "W", "W", None, None, None], [("c", "x", 0.9)])
        self.assertEqual(groups["b"], groups["c"])           # même œuvre (work_id)
        self.assertEqual(groups["c"], groups["x"])           # quasi-doublon, transitivement
        self.assertEqual(groups["x"], groups["y"] if groups["x"] == groups["y"] else groups["x"])
        self.assertNotEqual(groups["z"], groups["a"])
        self.assertTrue(all(g.startswith("g_") for g in groups.values()))
        # indépendance de l'ordre des unions
        g2 = build_groups(["z", "y", "x", "c", "b", "a"], [None, None, None, None, "W", "W"], [("c", "x", 0.9)])
        self.assertEqual(groups["a"], g2["a"])


class TestSplitAndLeak(unittest.TestCase):
    def test_assignment_deterministic_rates_and_notes(self):
        groups = [f"g_{i}" for i in range(4000)]
        a, notes = assign_groups(groups, val_rate=0.1, test_rate=0.05, salt="s")
        b, _ = assign_groups(list(reversed(groups)), val_rate=0.1, test_rate=0.05, salt="s")
        self.assertEqual(a, b)
        share = {k: sum(v == k for v in a.values()) / len(a) for k in ("train", "val", "test")}
        self.assertAlmostEqual(share["val"], 0.1, delta=0.02)
        self.assertAlmostEqual(share["test"], 0.05, delta=0.015)
        self.assertNotEqual(a, assign_groups(groups, val_rate=0.1, test_rate=0.05, salt="autre")[0])
        # peu de groupes : val/test jamais vides (promotion déterministe, consignée)
        few, notes = assign_groups([f"g_{i}" for i in range(12)], val_rate=0.001, test_rate=0.001, salt="s")
        self.assertIn("val", few.values()); self.assertIn("test", few.values()); self.assertEqual(len(notes), 2)
        with self.assertRaises(DataError):
            assign_groups(groups, val_rate=0.6, test_rate=0.5, salt="s")

    def test_leak_filter_removes_overlapping_val_docs_only(self):
        train = synthetic.make_text(500, seed=31)
        words = train.split()
        leaky = " ".join(words[100:180]) + " " + synthetic.make_text(250, seed=32)      # ~25 % copié de train
        clean = synthetic.make_text(300, seed=33)
        docs = {"t": ("train", train), "leaky": ("val", leaky), "clean": ("val", clean), "leaky_test": ("test", leaky)}
        removed, report = leak_filter(docs, ngram=13, max_fraction=0.10)
        self.assertEqual(removed, {"leaky", "leaky_test"})
        self.assertEqual(report.checked, 3)
        self.assertTrue(all(r["fraction_in_train"] >= 0.10 for r in report.removed))
        self.assertEqual(leak_filter({"t": ("train", train), "c": ("val", clean)})[0], set())
        self.assertEqual(leak_filter({"t": ("train", train), "same": ("val", train)})[0], {"same"})  # copie intégrale

    def test_leak_filter_is_the_second_net_for_edits_minhash_misses(self):
        """Mesuré : MinHash (seuil 0,8) ne détecte PAS 5 % de mots modifiés (rappel 0 ci-dessus). Les séquences de 13 mots,
        elles, voient encore ~50 % de recouvrement : le document est retiré de val/test."""
        original = synthetic.make_text(600, seed=41)
        variant = edit_words(original, 0.05, seed=3)
        pairs, _ = find_near_duplicates(["o", "v"], [original, variant], hasher=MinHasher(), threshold=0.8)
        self.assertEqual(pairs, [])                                   # regroupement manqué…
        removed, report = leak_filter({"o": ("train", original), "v": ("val", variant)}, ngram=13, max_fraction=0.10)
        self.assertEqual(removed, {"v"})                              # …mais la fuite est attrapée
        self.assertGreater(report.removed[0]["fraction_in_train"], 0.3)

    def test_assert_no_leak(self):
        assert_no_leak({"a": "train", "b": "train", "c": "val"}, {"a": "g1", "b": "g1", "c": "g2"})
        with self.assertRaises(DataError):
            assert_no_leak({"a": "train", "b": "val"}, {"a": "g1", "b": "g1"})


class TestPipeline(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.tmp.name)
        cls.docs = synthetic.make_documents(70, words_per_doc=300, seed=5)
        cls.records = [{"text": t, "source_id": "pd", "license_id": "CC0-1.0", "lang": "fr"} for t in cls.docs[:55]]
        # 12 couples de quasi-doublons (copie + ajout) répartis dans le corpus : sans regroupement, certains couples seraient séparés
        cls.records += [{"text": cls.docs[i] + " " + cls.docs[i][:250], "source_id": "pd", "license_id": "CC0-1.0", "lang": "fr"} for i in range(12)]
        cls.records += [
            {"text": cls.docs[60], "source_id": "sa", "license_id": "CC-BY-SA-4.0"},          # classe C
            {"text": cls.docs[61], "source_id": "by", "license_id": "CC0-1.0"},               # licence ≠ registre
            {"text": cls.docs[62], "source_id": "pending", "license_id": "CC0-1.0"},          # porte 1 non franchie
            {"text": cls.docs[63], "source_id": "inconnue", "license_id": "CC0-1.0"},         # source absente
            {"text": "trop court", "source_id": "pd", "license_id": "CC0-1.0", "lang": "fr"},
            {"text": cls.docs[64], "source_id": "pd", "license_id": "CC0-1.0", "lang": "de"},  # langue refusée
            {"text": cls.docs[0], "source_id": "pd", "license_id": "CC0-1.0", "lang": "fr"},   # doublon exact
        ]
        cls.out = cls.root / "ds"
        cls.manifest = build_dataset(cls.records, fx.registry(), CFG, cls.out)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_gates_and_counts(self):
        rejected = [json.loads(l) for l in (self.out / "rejections.jsonl").read_text().splitlines()]
        reasons = " | ".join(r["reason"] for r in rejected)
        for fragment in ("classe C", "≠ licence enregistrée", "porte 1 non franchie", "source inconnue", "trop court", "langue non autorisée"):
            self.assertIn(fragment, reasons)
        c = self.manifest["counts"]
        self.assertEqual(c["exact_duplicates_dropped"], 1)
        self.assertEqual(c["near_duplicate_pairs"], 12)
        self.assertEqual(c["groups"], 55)  # 55 œuvres distinctes (les 12 copies rejoignent leur original)
        sources = {s["source_id"] for s in self.manifest["sources"]}
        self.assertEqual(sources, {"pd"})  # aucune source non admise n'apparaît dans le jeu

    def test_s14_no_leak_between_splits(self):
        by_split = {}
        for split in ("train", "val", "test"):
            rows = []
            for shard in self.manifest["splits"][split]["shards"]:
                rows += [json.loads(l) for l in (self.out / split / shard["index_path"]).read_text().splitlines()]
            by_split[split] = rows
        for a in by_split:
            for b in by_split:
                if a < b:
                    self.assertFalse({r["doc_id"] for r in by_split[a]} & {r["doc_id"] for r in by_split[b]}, (a, b))
                    self.assertFalse({r["group_id"] for r in by_split[a]} & {r["group_id"] for r in by_split[b]}, (a, b))
        self.assertTrue(all(by_split[s] for s in by_split))
        # chaque copie (quasi-doublon) est dans le même jeu que son original
        text_split = {}
        for split, rows in by_split.items():
            for r in rows:
                text_split[r["doc_id"]] = split
        for i in range(12):
            a, b = make_ids(self.docs[i]), make_ids(self.docs[i] + " " + self.docs[i][:250])
            if a in text_split and b in text_split:
                self.assertEqual(text_split[a], text_split[b], i)

    def test_tokenizer_trained_on_train_only(self):
        seen = {}
        real = pipeline.train_tokenizer

        def spy(corpus, **kw):
            seen["split"], seen["texts"] = corpus.split, list(corpus)
            return real(type(corpus)("train", seen["texts"]), **kw)

        with mock.patch.object(pipeline, "train_tokenizer", spy), tempfile.TemporaryDirectory() as d:
            m = build_dataset(self.records, fx.registry(), CFG, d)
            by_id = {}
            for split in ("train", "val", "test"):
                for shard in m["splits"][split]["shards"]:
                    for line in (Path(d) / split / shard["index_path"]).read_text().splitlines():
                        by_id[json.loads(line)["doc_id"]] = split
            tokdev = set(json.loads((Path(d) / "tokenizer" / "tokenizer_manifest.json").read_text())["tokdev_docs"])
        self.assertEqual(seen["split"], "train")
        trained_ids = {make_ids(t) for t in seen["texts"]}
        self.assertTrue(trained_ids)
        self.assertTrue(all(by_id.get(i) == "train" for i in trained_ids if i in by_id))   # aucun texte val/test dans l'entraînement
        self.assertTrue({i for i, sp in by_id.items() if sp != "train"})                    # et il existe bien des textes val/test à exclure
        self.assertFalse({i for i, sp in by_id.items() if sp != "train"} & trained_ids)
        self.assertTrue(tokdev)
        self.assertFalse(tokdev & trained_ids)  # la tranche tokdev est exclue de l'entraînement du tokenizer
        self.assertEqual({by_id[i] for i in tokdev}, {"train"})

    def test_t12_sentinels_and_index_consistency(self):
        tok = EdgiaTokenizer.load(self.out / "tokenizer")
        for split in ("train", "val", "test"):
            for shard in self.manifest["splits"][split]["shards"]:
                data = np.fromfile(self.out / split / shard["path"], dtype="<u2")
                self.assertEqual(data.size, shard["tokens"])
                self.assertEqual(sorted(set(data[data < 128].tolist())), [specials.EOS])   # seul EOS < 128
                rows = [json.loads(l) for l in (self.out / split / shard["index_path"]).read_text().splitlines()]
                self.assertEqual(int((data == specials.EOS).sum()), len(rows))
                cursor = 0
                for row in rows:
                    self.assertEqual(row["offset"], cursor)
                    self.assertEqual(int(data[row["offset"] + row["length"] - 1]), specials.EOS)
                    text = tok.decode(data[row["offset"]: row["offset"] + row["length"] - 1].tolist())
                    self.assertEqual(make_doc_id(text), row["doc_id"])   # le jeton → texte → doc_id retrouve le document d'origine
                    cursor += row["length"]
                self.assertEqual(cursor, data.size)
                self.assertLessEqual(data.max(), tok.vocab_size - 1)

    def test_s7_determinism_independent_of_input_order(self):
        shuffled = list(self.records)
        random.Random(1).shuffle(shuffled)
        with tempfile.TemporaryDirectory() as d:
            m2 = build_dataset(shuffled, fx.registry(), CFG, d)
            self.assertEqual(m2["manifest_sha256"], self.manifest["manifest_sha256"])
            for split in ("train", "val", "test"):
                a = [s["sha256"] for s in self.manifest["splits"][split]["shards"]]
                b = [s["sha256"] for s in m2["splits"][split]["shards"]]
                self.assertEqual(a, b, split)
            self.assertEqual(verify_manifest(d), [])

    def test_manifest_verification_detects_tampering(self):
        self.assertEqual(verify_manifest(self.out), [])
        with tempfile.TemporaryDirectory() as d:
            copy = Path(d) / "ds"
            shutil.copytree(self.out, copy)
            shard = copy / "train" / self.manifest["splits"]["train"]["shards"][0]["path"]
            raw = bytearray(shard.read_bytes()); raw[10] ^= 1; shard.write_bytes(bytes(raw))
            self.assertTrue(any("empreinte différente" in p for p in verify_manifest(copy)))
            (copy / "train" / self.manifest["splits"]["train"]["shards"][0]["index_path"]).unlink()
            self.assertTrue(any("absent" in p for p in verify_manifest(copy)))
            manifest = json.loads((copy / "dataset_manifest.json").read_text()); manifest["vocab_size"] = 5
            (copy / "dataset_manifest.json").write_text(json.dumps(manifest))
            self.assertTrue(any("manifeste" in p for p in verify_manifest(copy)))

    def test_data_card_and_lineage_fields(self):
        card = (self.out / "DATA_CARD.md").read_text(encoding="utf-8")
        self.assertIn("| pd | CC0-1.0 | A |", card)
        self.assertIn("pas un avis juridique", card)
        for source in self.manifest["sources"]:
            self.assertTrue(source["license_text_sha256"] and source["archive_sha256"] and source["validator"])
        self.assertEqual(self.manifest["registry_sha256"], fx.registry().registry_hash())

    def test_input_validation(self):
        with self.assertRaises(DataError):
            build_dataset([{"text": "x", "source_id": "pd"}], fx.registry(), CFG, tempfile.mkdtemp())
        with self.assertRaises(DataError):
            build_dataset([{"text": self.docs[0], "source_id": "sa", "license_id": "CC-BY-SA-4.0"}], fx.registry(), CFG, tempfile.mkdtemp())

    def test_exact_duplicate_keeps_smallest_source_independently_of_order(self):
        reg = fx.registry()
        a = {"text": self.docs[3], "source_id": "pd", "license_id": "CC0-1.0", "lang": "fr"}
        for order in ([a, {**a, "source_id": "by", "license_id": "CC-BY-4.0"}], [{**a, "source_id": "by", "license_id": "CC-BY-4.0"}, a]):
            with tempfile.TemporaryDirectory() as d:
                m = build_dataset(order + fx.records(30, seed=8)[:30], reg, CFG, d)
                self.assertEqual(m["counts"]["exact_duplicates_dropped"], 1)
                rows = [json.loads(l) for s in ("train", "val", "test") for sh in m["splits"][s]["shards"]
                        for l in (Path(d) / s / sh["index_path"]).read_text().splitlines()]
                kept = [r for r in rows if r["doc_id"] == make_ids(self.docs[3])]
                self.assertEqual([r["source_id"] for r in kept], ["by"])  # « by » < « pd » : plus petit identifiant de source


def make_ids(text):
    return make_doc_id(scrub_pii(normalize_text(text))[0])


class TestWindowLoader(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.out = Path(cls.tmp.name) / "ds"
        build_dataset(fx.records(60, words=300, seed=9), fx.registry(), DataConfig(val_rate=0.1, test_rate=0.1, min_chars=50,
                      tokenizer_profile="smoke", shard_tokens=5000), cls.out)
        cls.paths = train_shard_paths(cls.out)
        cls.ctx = 32

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def loader(self, seed=1, batch=4):
        return WindowLoader(self.paths, self.ctx, seed, batch)

    def test_s8_stateless_batches(self):
        a, b = self.loader(), self.loader()
        for step in (0, 1, 7, 500):
            self.assertTrue(np.array_equal(a.get_batch(step), b.get_batch(step)))
            self.assertEqual(a.batch_fingerprint(step), b.batch_fingerprint(step))
        _ = a.get_batch(3); _ = a.get_batch(2)                      # l'ordre des appels n'a aucune influence
        self.assertTrue(np.array_equal(a.get_batch(7), self.loader().get_batch(7)))
        self.assertFalse(np.array_equal(self.loader(seed=1).get_batch(0), self.loader(seed=2).get_batch(0)))
        batch = a.get_batch(0)
        self.assertEqual(batch.shape, (4, self.ctx + 1))
        self.assertEqual(batch.dtype, np.int64)

    def test_s8_each_window_exactly_once_per_epoch_and_epochs_differ(self):
        ld = self.loader()
        w = ld.total_windows
        steps = -(-2 * w // ld.batch_seqs)
        seen = [i for s in range(steps) for i in ld.window_indices(s)]
        self.assertEqual(sorted(seen[:w]), list(range(w)))          # époque 0 : chaque fenêtre une fois
        self.assertEqual(sorted(seen[w: 2 * w]), list(range(w)))    # époque 1 aussi, y compris à cheval sur deux lots
        self.assertNotEqual(seen[:w], seen[w: 2 * w])               # permutation différente à chaque époque

    def test_s8_every_token_predicted_once_and_no_window_crosses_a_shard(self):
        ld = self.loader()
        total_targets = 0
        for path in self.paths:
            n = np.memmap(path, dtype="<u2", mode="r").size
            windows = (n - 1) // self.ctx
            total_targets += windows * self.ctx
            self.assertLessEqual(windows * self.ctx + 1, n)         # la dernière fenêtre tient dans le fragment
        self.assertEqual(ld.total_windows * self.ctx, total_targets)
        # chevauchement d'exactement 1 token entre fenêtres voisines d'un même fragment
        first = np.memmap(self.paths[0], dtype="<u2", mode="r")
        w0, w1 = ld.window(0), ld.window(1)
        self.assertTrue(np.array_equal(w0, first[: self.ctx + 1].astype(np.int64)))
        self.assertEqual(w0[-1], w1[0])
        self.assertTrue(np.array_equal(w1, first[self.ctx: 2 * self.ctx + 1].astype(np.int64)))

    def test_tail_is_reported_and_short_data_refused(self):
        ld = self.loader()
        self.assertGreaterEqual(ld.unused_tail_tokens, 0)
        with tempfile.TemporaryDirectory() as d:
            tiny = Path(d) / "t.bin"
            np.arange(10, dtype="<u2").tofile(tiny)
            with self.assertRaises(DataError):
                WindowLoader([tiny], 32, 0, 2)
            with self.assertRaises(DataError):
                WindowLoader(self.paths, 0, 0, 2)


if __name__ == "__main__":
    unittest.main()
