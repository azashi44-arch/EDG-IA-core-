"""Vérification mathématique de la RÉFÉRENCE NumPy (M2–M9, M12, M16) : formules, RoPE, GQA, masque, cache KV.

La référence est l'oracle des tests PyTorch (`test_torch_model.py`). Ici on la valide elle-même par des identités
indépendantes écrites dans le test (rotation explicite cos/sin, calcul manuel d'attention, équivalence MHA↔GQA…).
"""

import math
import unittest

import _bootstrap  # noqa: F401
import numpy as np

from edgia_core.native import naming
from edgia_core.native.config import PRESETS, PROFILE_TEST, ModelConfig
from edgia_core.native.reference import numpy_model as R


def tiny(**kw):
    base = dict(name="t", profile=PROFILE_TEST, vocab_size=97, d_model=32, n_layers=2, n_heads=4, n_kv_heads=2, head_dim=8,
                ffn_dim=64, max_seq_len=40)
    base.update(kw)
    return ModelConfig(**base)


def strong_params(cfg, seed=3, scale=15.0):
    """Poids grossis : les tests deviennent sensibles (sinon l'attention est presque uniforme et les erreurs passent inaperçues)."""
    params = R.init_params(cfg, seed=seed)
    for name in params:
        if name.endswith("proj.weight"):
            params[name] = params[name] * scale
    return params


class TestInitialisation(unittest.TestCase):
    def test_m2_standard_deviations(self):
        cfg = tiny(d_model=64, n_heads=4, head_dim=16, ffn_dim=128, n_layers=4)
        params = R.init_params(cfg, seed=1)
        for name, value in params.items():
            if name.endswith("norm.weight") or name == naming.FINAL_NORM:
                self.assertTrue(np.all(value == 1.0), name)
                continue
            target = cfg.residual_init_std if name.endswith(naming.RESIDUAL_SUFFIXES) else cfg.init_std
            self.assertAlmostEqual(float(value.std()) / target, 1.0, delta=0.05, msg=name)
            self.assertAlmostEqual(float(value.mean()), 0.0, delta=4 * target / math.sqrt(value.size) + 1e-9, msg=name)
        self.assertAlmostEqual(cfg.residual_init_std, 0.02 / math.sqrt(8), places=12)

    def test_xs_residual_std_is_0_005(self):
        self.assertAlmostEqual(PRESETS["xs"].residual_init_std, 0.005, places=12)

    def test_m2_initial_loss_xs_is_in_the_predicted_interval(self):
        """MESURE sur le vrai modèle XS (référence NumPy) : l'analyse du §3.5 prédisait ≈ 10,5 dans [10,3 ; 10,8]."""
        xs = PRESETS["xs"]
        params = R.init_params(xs, seed=0, dtype=np.float64)
        rng = np.random.default_rng(0)
        losses = []
        for _ in range(3):
            ids = rng.integers(128, xs.vocab_size, size=65)
            losses.append(R.cross_entropy(R.forward(params, xs, ids[:-1]), ids[1:]))
        loss = float(np.mean(losses))
        print(f"\n[mesure M2] perte initiale XS = {loss:.4f}  (ln V = {math.log(xs.vocab_size):.4f}, intervalle visé [10.3, 10.8])")
        self.assertGreater(loss, 10.3)
        self.assertLess(loss, 10.8)
        self.assertGreater(loss, math.log(xs.vocab_size))  # la variance des logits ne peut que l'augmenter


class TestRmsNorm(unittest.TestCase):
    def test_m3_formula(self):
        x = np.random.default_rng(0).normal(size=(5, 16)) * 3
        g = np.random.default_rng(1).normal(size=16)
        expected = x / np.sqrt((x ** 2).mean(axis=-1, keepdims=True) + 1e-5) * g
        np.testing.assert_allclose(R.rmsnorm(x, g, 1e-5), expected, rtol=1e-12)

    def test_unit_rms_when_gain_is_one(self):
        x = np.random.default_rng(2).normal(size=(4, 64)) * 7
        y = R.rmsnorm(x, np.ones(64), 1e-8)
        np.testing.assert_allclose(np.sqrt((y ** 2).mean(axis=-1)), 1.0, rtol=1e-6)

    def test_zero_input_and_large_values_stay_finite(self):
        self.assertTrue(np.all(R.rmsnorm(np.zeros((2, 8)), np.ones(8), 1e-5) == 0))  # le rôle de ε : pas de 0/0
        self.assertTrue(np.isfinite(R.rmsnorm(np.full((1, 8), 1e4), np.ones(8), 1e-5)).all())


class TestRope(unittest.TestCase):
    hd, theta = 16, 10_000.0

    def explicit(self, x, pos):
        """Rotation écrite avec cos/sin (convention moitiés), indépendante de la version complexe de la référence."""
        half = self.hd // 2
        out = np.empty_like(x)
        for t, p in enumerate(pos):
            for j in range(half):
                angle = p * self.theta ** (-2.0 * j / self.hd)
                a, b = x[t, j], x[t, j + half]
                out[t, j] = a * math.cos(angle) - b * math.sin(angle)
                out[t, j + half] = b * math.cos(angle) + a * math.sin(angle)
        return out

    def test_m4_matches_explicit_rotation(self):
        x = np.random.default_rng(0).normal(size=(6, self.hd))
        pos = np.array([0, 1, 2, 7, 100, 1023])
        np.testing.assert_allclose(R.apply_rope(x, pos, self.theta), self.explicit(x, pos), atol=1e-12)

    def test_norm_preserved_and_position_zero_is_identity(self):
        x = np.random.default_rng(1).normal(size=(5, self.hd))
        y = R.apply_rope(x, np.arange(5), self.theta)
        np.testing.assert_allclose(np.linalg.norm(y, axis=-1), np.linalg.norm(x, axis=-1), rtol=1e-12)
        np.testing.assert_allclose(R.apply_rope(x[:1], np.array([0]), self.theta), x[:1], atol=1e-15)

    def test_relative_position_property(self):
        rng = np.random.default_rng(2)
        q, k = rng.normal(size=(1, self.hd)), rng.normal(size=(1, self.hd))
        def score(m, n):
            return float((R.apply_rope(q, np.array([m]), self.theta) @ R.apply_rope(k, np.array([n]), self.theta).T)[0, 0])
        for m, n, s in ((5, 2, 10), (0, 0, 77), (30, 29, 500), (3, 8, 1)):
            self.assertAlmostEqual(score(m, n), score(m + s, n + s), places=9)
        self.assertNotAlmostEqual(score(5, 2), score(5, 3), places=3)  # dépend bien de l'écart

    def test_frequencies(self):
        angles = R.rope_angles(np.array([1]), self.hd, self.theta)[0]
        self.assertAlmostEqual(angles[0], 1.0)
        self.assertAlmostEqual(angles[-1], self.theta ** (-(self.hd - 2) / self.hd))
        self.assertTrue(np.all(np.diff(angles) < 0))


class TestAttentionAndFeedForward(unittest.TestCase):
    def test_m7_attend_matches_hand_computation(self):
        q = np.array([[1.0, 0.0]]); k = np.array([[1.0, 0.0], [0.0, 1.0]]); v = np.array([[1.0, 2.0], [3.0, 4.0]])
        w0 = math.exp(1 / math.sqrt(2)); w = np.array([w0, 1.0]) / (w0 + 1.0)
        np.testing.assert_allclose(R.attend(q, k, v, np.ones((1, 2), bool), 2), (w[:, None] * v).sum(axis=0, keepdims=True), rtol=1e-12)
        masked = R.attend(q, k, v, np.array([[True, False]]), 2)  # la 2ᵉ clé est interdite
        np.testing.assert_allclose(masked, v[:1], rtol=1e-12)

    def test_m8_swiglu_formula(self):
        gate, up = np.array([0.0, 1.0, -1.0, 20.0]), np.array([1.0, 2.0, 3.0, 0.5])
        sig = lambda z: 1 / (1 + math.exp(-z))  # noqa: E731
        expected = [g * sig(g) * u for g, u in zip(gate, up)]
        np.testing.assert_allclose(R.swiglu(gate, up), expected, rtol=1e-12)

    def test_softmax_stable_for_huge_scores(self):
        out = R.softmax(np.array([[1e4, 1e4 - 1, -np.inf]]))
        self.assertTrue(np.isfinite(out).all())
        self.assertAlmostEqual(float(out.sum()), 1.0)
        self.assertEqual(float(out[0, 2]), 0.0)


class TestGroupedQueryAttention(unittest.TestCase):
    def test_m6_gqa_equals_mha_with_duplicated_kv_heads(self):
        """GQA (4 têtes Q, 2 têtes KV) = attention multi-têtes (4 têtes KV) dont les têtes K/V sont les copies h → h // 2.
        Une correspondance fausse (par exemple h % 2) donnerait un résultat différent."""
        gqa, mha = tiny(n_kv_heads=2), tiny(n_kv_heads=4)
        params = strong_params(gqa)
        mha_params = dict(params)
        hd, group = gqa.head_dim, gqa.n_heads // gqa.n_kv_heads
        for i in range(gqa.n_layers):
            for proj in ("k_proj", "v_proj"):
                name = naming.layer_name(i, f"attn.{proj}.weight")
                mha_params[name] = np.concatenate([params[name][(h // group) * hd:(h // group + 1) * hd] for h in range(gqa.n_heads)], axis=0)
        ids = np.random.default_rng(0).integers(0, 97, size=12)
        np.testing.assert_allclose(R.forward(params, gqa, ids), R.forward(mha_params, mha, ids), atol=1e-12)

    def test_kv_heads_matter(self):
        cfg = tiny()
        params = strong_params(cfg)
        ids = np.random.default_rng(0).integers(0, 97, size=10)
        base = R.forward(params, cfg, ids)
        swapped = dict(params)
        name = naming.layer_name(0, "attn.k_proj.weight")
        half = cfg.head_dim
        swapped[name] = np.concatenate([params[name][half:], params[name][:half]], axis=0)  # on échange les deux têtes KV
        self.assertGreater(np.abs(R.forward(swapped, cfg, ids) - base).max(), 1e-6)


class TestCausalityAndCache(unittest.TestCase):
    cfg = tiny()

    def setUp(self):
        self.params = strong_params(self.cfg)
        self.ids = np.random.default_rng(1).integers(0, 97, size=30)

    def test_m5_causality_exact(self):
        full = R.forward(self.params, self.cfg, self.ids)
        for t in (0, 5, 17, 28):
            changed = self.ids.copy()
            changed[t + 1:] = (changed[t + 1:] + 13) % 97
            out = R.forward(self.params, self.cfg, changed)
            self.assertTrue(np.array_equal(out[: t + 1], full[: t + 1]), t)
            self.assertFalse(np.array_equal(out[t + 1:], full[t + 1:]))
        # T = 1 : formes de matrices différentes → les noyaux BLAS peuvent sommer dans un autre ordre ; l'égalité EXACTE n'est
        # attendue qu'à formes identiques (ci-dessus). Ici : tolérance numérique.
        single = R.forward(self.params, self.cfg, self.ids[:1])
        np.testing.assert_allclose(single, full[:1], atol=1e-12)

    def test_m9_cache_equivalence_all_chunkings(self):
        full = R.forward(self.params, self.cfg, self.ids)
        schedules = {
            "prefill_puis_un_a_un": [(0, 10)] + [(i, i + 1) for i in range(10, 30)],
            "morceaux_irreguliers": [(0, 5), (5, 8), (8, 9), (9, 16), (16, 17), (17, 30)],
            "un_token_a_la_fois": [(i, i + 1) for i in range(30)],
            "deux_morceaux": [(0, 15), (15, 30)],
        }
        for label, bounds in schedules.items():
            cache = R.new_cache(self.cfg)
            out = np.concatenate([R.forward(self.params, self.cfg, self.ids[a:b], cache) for a, b in bounds])
            np.testing.assert_allclose(out, full, atol=1e-10, err_msg=label)
            self.assertEqual(R.cache_length(cache), 30)

    def test_cache_stores_rotated_keys_at_absolute_positions(self):
        cache = R.new_cache(self.cfg)
        R.forward(self.params, self.cfg, self.ids[:6], cache)
        R.forward(self.params, self.cfg, self.ids[6:9], cache)
        fresh = R.new_cache(self.cfg)
        R.forward(self.params, self.cfg, self.ids[:9], fresh)
        for layer in range(self.cfg.n_layers):
            np.testing.assert_allclose(cache[layer]["k"], fresh[layer]["k"], atol=1e-10)

    def test_layer0_cached_keys_are_the_rotated_projections_of_the_token_embeddings(self):
        """Calcul INDÉPENDANT : l'entrée de la couche 0 ne dépend que de l'embedding ; K en cache = RoPE(RMSNorm(E[token])·Wkᵀ) à la position absolue."""
        cfg, params = self.cfg, self.params
        ids = self.ids[:9]
        cache = R.new_cache(cfg)
        R.forward(params, cfg, ids[:6], cache)
        R.forward(params, cfg, ids[6:9], cache)                      # les 3 derniers tokens arrivent à des positions 6, 7, 8
        h = R.rmsnorm(params[naming.EMBEDDING][ids], params[naming.layer_name(0, "attn_norm.weight")], cfg.rms_eps)
        k = (h @ params[naming.layer_name(0, "attn.k_proj.weight")].T).reshape(9, cfg.n_kv_heads, cfg.head_dim)
        for g in range(cfg.n_kv_heads):
            expected = R.apply_rope(k[:, g], np.arange(9), cfg.rope_theta)
            np.testing.assert_allclose(cache[0]["k"][g], expected, atol=1e-10)
        unrotated = k[6:9, 0]
        self.assertGreater(np.abs(cache[0]["k"][0][6:9] - unrotated).max(), 1e-3)   # et ce ne sont PAS les clés non tournées

    def test_context_limits(self):
        cfg = tiny(max_seq_len=16)
        params = strong_params(cfg)
        ids = np.random.default_rng(2).integers(0, 97, size=16)
        cache = R.new_cache(cfg)
        R.forward(params, cfg, ids, cache)  # P + T = 16 : plein, accepté
        with self.assertRaises(ValueError):
            R.forward(params, cfg, ids[:1], cache)  # 17 : refusé
        with self.assertRaises(ValueError):
            R.forward(params, cfg, np.arange(17) % 97)
        with self.assertRaises(ValueError):
            R.forward(params, cfg, np.array([], dtype=int))
        with self.assertRaises(ValueError):
            R.forward(params, cfg, np.array([97]))
        with self.assertRaises(ValueError):
            R.forward(params, cfg, np.array([-1]))


class TestLossShift(unittest.TestCase):
    def test_m12_targets_are_inputs_shifted_by_one(self):
        seq = np.array([5, 6, 7, 8, 9])
        inputs, targets = seq[:-1], seq[1:]
        self.assertEqual(list(targets), [6, 7, 8, 9])
        logits = np.log(np.array([[0.7, 0.1, 0.2], [0.1, 0.8, 0.1]]))
        self.assertAlmostEqual(R.cross_entropy(logits, np.array([0, 1])), -(math.log(0.7) + math.log(0.8)) / 2, places=12)
        self.assertEqual(len(inputs), len(targets))

    def test_m16_extreme_logits_stay_finite(self):
        logits = np.array([[1e4, -1e4, 0.0], [-1e4, 1e4, 3.0]])
        self.assertTrue(math.isfinite(R.cross_entropy(logits, np.array([0, 1]))))
        self.assertTrue(math.isfinite(R.cross_entropy(logits, np.array([1, 0]))))  # grande perte mais finie


if __name__ == "__main__":
    unittest.main()
