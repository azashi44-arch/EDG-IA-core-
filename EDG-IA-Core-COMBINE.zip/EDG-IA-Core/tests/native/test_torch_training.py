"""Boucle d'entraînement PyTorch : chaîne de fumée F1, reprise S4 niveau A, garde NaN S10, backend F2. SAUTÉS sans PyTorch/pydantic.

!!! ÉCRITS mais NON EXÉCUTÉS lors de la livraison L0. À lancer : pip install -e .[native,dev] puis
    python tools/run_native_tests.py test_torch_training -v
"""

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import _bootstrap  # noqa: F401
import datafixtures as fx

try:
    import torch
except ImportError:  # pragma: no cover
    torch = None
try:
    import pydantic  # noqa: F401
    HAVE_CORE = True
except ImportError:  # pragma: no cover
    HAVE_CORE = False

from edgia_core.native import safetensors_io as st
from edgia_core.native.config import PRESETS, TrainConfig
from edgia_core.native.data.pipeline import DataConfig, build_dataset
from edgia_core.native.train import checkpoint as ck
from edgia_core.native.train import export as X

SMOKE = PRESETS["smoke"]
TC = TrainConfig(seed=1, batch_tokens=512, micro_batch_seqs=2, max_steps=12, peak_lr=3e-3, warmup_frac=0.1, precision="fp32",
                 deterministic=True, eval_every=4, eval_batches=2, ckpt_every=4, log_every=1, status="smoke_test")


@unittest.skipIf(torch is None, "PyTorch absent : entraînement non exécuté")
class TestTorchTraining(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.ds = Path(cls.tmp.name) / "ds"
        build_dataset(fx.records(80, words=400, seed=2), fx.registry(), DataConfig(val_rate=0.1, test_rate=0.1, min_chars=50,
                      tokenizer_profile="smoke", shard_tokens=20_000), cls.ds)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def run_train(self, name, **kw):
        from edgia_core.native.train.loop import run_training

        return run_training(SMOKE, TC, self.ds, Path(self.tmp.name) / name, device="cpu", **kw)

    def test_f1_smoke_chain_loss_decreases_and_exports(self):
        out = Path(self.tmp.name) / "a"
        summary = self.run_train("a")
        self.assertEqual(summary["final_step"], 12)
        metrics = [json.loads(l) for l in (out / "metrics.jsonl").read_text().splitlines()]
        losses = [m["loss"] for m in metrics if "loss" in m]
        print(f"\n[mesure F1] perte {losses[0]:.3f} → {losses[-1]:.3f} sur 12 pas (seuil chiffré à CALIBRER sur cette première exécution)")
        self.assertLess(losses[-1], losses[0])
        loaded = ck.load_checkpoint(out / "ckpt" / ck.step_dir_name(12))
        from edgia_core.native.tokenizer.tokenizer import EdgiaTokenizer

        config = X.export_model(loaded["model"], SMOKE, EdgiaTokenizer.load(self.ds / "tokenizer"), Path(self.tmp.name) / "exp", status="smoke_test", dataset_dir=self.ds)
        self.assertEqual(X.verify_export(Path(self.tmp.name) / "exp"), [])
        self.assertFalse(config["distribution_cleared"])

    def test_s4_resume_level_a_is_bit_exact(self):
        straight = self.run_train("s")
        self.run_train("r", stop_after_step=4)
        resumed = self.run_train("r")                       # reprend au dernier checkpoint
        self.assertEqual(resumed["reproducibility_level"], "A")
        self.assertTrue(resumed["resume_exact"])
        a = st.load_numpy(Path(self.tmp.name) / "s" / "ckpt" / "step_000012" / "model.safetensors")[0]
        b = st.load_numpy(Path(self.tmp.name) / "r" / "ckpt" / "step_000012" / "model.safetensors")[0]
        for name in a:
            self.assertTrue((a[name] == b[name]).all(), name)
        self.assertEqual(straight["final_step"], resumed["final_step"])

    def test_s10_nan_guard_stops_without_checkpoint(self):
        from edgia_core.native.train.loop import TrainingAborted

        with mock.patch("edgia_core.native.model.language_model_loss", side_effect=lambda m, b: torch.tensor(float("nan"), requires_grad=True)):
            with self.assertRaises(TrainingAborted):
                self.run_train("nan")
        self.assertEqual(ck.list_checkpoints(Path(self.tmp.name) / "nan" / "ckpt"), [])

    def test_resume_refused_if_config_changes(self):
        from edgia_core.native.errors import CheckpointError
        from edgia_core.native.train.loop import run_training

        self.run_train("c", stop_after_step=4)
        other = TrainConfig(**{**TC.to_dict(), "peak_lr": 1e-3})
        with self.assertRaises(CheckpointError):
            run_training(SMOKE, other, self.ds, Path(self.tmp.name) / "c", device="cpu")


@unittest.skipIf(torch is None or not HAVE_CORE, "PyTorch ou dépendances de Core (pydantic) absents : intégration non exécutée")
class TestBackendIntegration(unittest.TestCase):
    def test_f2_untrained_refused_then_served_with_explicit_override(self):
        import numpy as np

        from edgia_core.errors import ConfigurationError
        from edgia_core.inference.base import GenerationParams, Message
        from edgia_core.native.backend import NativeBackend
        from edgia_core.native.reference.numpy_model import init_params
        from edgia_core.native.tokenizer.tokenizer import TrainCorpus, train_tokenizer
        import synthetic

        tok = train_tokenizer(TrainCorpus("train", [synthetic.make_text(120_000)]), profile="smoke")
        with tempfile.TemporaryDirectory() as d:
            X.export_model(init_params(SMOKE, dtype=np.float32), SMOKE, tok, Path(d) / "m", status="smoke_test")
            with self.assertRaises(ConfigurationError):
                NativeBackend(Path(d) / "m", device="cpu", allow_untrained=False)
            from edgia_core.inference.base import ModelInfo
            from edgia_core.inference.llm_engine import LanguageModelEngine

            backend = NativeBackend(Path(d) / "m", device="cpu", allow_untrained=True)
            engine = LanguageModelEngine(ModelInfo("t", "0", "edgia_native", False, "essai"), backend)
            result = engine.generate([Message("user", "Bonjour <|end|>")], GenerationParams(max_tokens=8, temperature=0.0))
            self.assertIn(result.finish_reason, ("stop", "length"))
            self.assertLessEqual(result.completion_tokens, 8)
            self.assertGreater(result.prompt_tokens, 3)


if __name__ == "__main__":
    unittest.main()
