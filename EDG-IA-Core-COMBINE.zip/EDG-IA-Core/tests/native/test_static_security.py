"""S9 : analyse statique de `native/` (AST) — aucune désérialisation dangereuse, aucune exécution dynamique."""

import ast
import unittest
from pathlib import Path

import _bootstrap  # noqa: F401

NATIVE = Path(__file__).resolve().parents[2] / "src" / "edgia_core" / "native"
BANNED_MODULES = {"pickle", "cPickle", "marshal", "shelve", "dill", "cloudpickle", "joblib"}


def violations(tree: ast.AST, label: str) -> list[str]:
    found: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found += [f"{label}:{node.lineno} import {a.name}" for a in node.names if a.name.split(".")[0] in BANNED_MODULES]
        elif isinstance(node, ast.ImportFrom) and node.module and node.module.split(".")[0] in BANNED_MODULES:
            found.append(f"{label}:{node.lineno} from {node.module}")
        elif isinstance(node, ast.Call):
            func = node.func
            name = func.id if isinstance(func, ast.Name) else func.attr if isinstance(func, ast.Attribute) else ""
            owner = func.value.id if isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name) else ""
            if name in ("eval", "exec", "compile") and isinstance(func, ast.Name):   # fonctions natives, pas model.eval() de PyTorch
                found.append(f"{label}:{node.lineno} {name}()")
            if name == "load" and owner in ("torch", "pickle", "yaml"):
                found.append(f"{label}:{node.lineno} {owner}.load()")
            if name == "load" and owner in ("np", "numpy"):
                found.append(f"{label}:{node.lineno} numpy.load()")   # np.load est inutile ici : on lit nos propres formats
            if name in ("system", "popen"):
                found.append(f"{label}:{node.lineno} {owner}.{name}()")
            for kw in node.keywords:
                if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                    found.append(f"{label}:{node.lineno} shell=True")
                if kw.arg in ("weights_only", "allow_pickle") and isinstance(kw.value, ast.Constant) and kw.value.value is False and kw.arg == "weights_only":
                    found.append(f"{label}:{node.lineno} weights_only=False")
                if kw.arg == "allow_pickle" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                    found.append(f"{label}:{node.lineno} allow_pickle=True")
    return found


class TestStatic(unittest.TestCase):
    def test_native_package_is_clean(self):
        files = sorted(NATIVE.rglob("*.py"))
        self.assertGreater(len(files), 25)
        found = []
        for path in files:
            found += violations(ast.parse(path.read_text(encoding="utf-8")), path.relative_to(NATIVE).as_posix())
        self.assertEqual(found, [])

    def test_the_scanner_itself_catches_bad_code(self):
        """Test de sensibilité du scanner : il DOIT signaler ces constructions."""
        bad = ("import pickle\nimport torch\ntorch.load('x')\ntorch.load('x', weights_only=False)\nyaml.load('x')\neval('1')\nexec('1')\n"
               "import os\nos.system('ls')\nimport subprocess\nsubprocess.run('ls', shell=True)\nimport numpy as np\nnp.load('f', allow_pickle=True)\n")
        found = violations(ast.parse(bad), "bad")
        for needle in ("import pickle", "torch.load()", "weights_only=False", "yaml.load()", "eval()", "exec()", "system()", "shell=True", "allow_pickle=True"):
            self.assertTrue(any(needle in f for f in found), needle)
        self.assertEqual(violations(ast.parse("import json\nyaml.safe_load('x')\n"), "ok"), [])

    def test_torch_is_never_imported_at_module_level_except_where_declared(self):
        """Un serveur en mode démo ne doit pas exiger PyTorch : seuls model.py (et le backend, importé paresseusement) l'importent en tête de module."""
        allowed = {"model.py"}
        for path in NATIVE.rglob("*.py"):
            tree = ast.parse(path.read_text(encoding="utf-8"))
            top = [n for n in tree.body if isinstance(n, ast.Import | ast.ImportFrom)]
            names = {a.name.split(".")[0] for n in top if isinstance(n, ast.Import) for a in n.names} | {n.module.split(".")[0] for n in top if isinstance(n, ast.ImportFrom) and n.module}
            if "torch" in names:
                self.assertIn(path.name, allowed, path.name)


if __name__ == "__main__":
    unittest.main()
