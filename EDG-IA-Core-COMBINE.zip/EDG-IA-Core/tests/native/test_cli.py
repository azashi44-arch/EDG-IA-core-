"""CLI (`python -m edgia_core.native`) : commandes exécutables sans PyTorch — info, selfcheck, sources-check, data-build/verify,
export-random/verify, train-plan, refus d'entraînement sans autorisation."""

import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

import _bootstrap  # noqa: F401
import datafixtures as fx
import synthetic

from edgia_core.native.cli import main

CONFIGS = Path(__file__).resolve().parents[2] / "configs" / "native"


def run(*argv):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        code = main(list(argv))
    return code, out.getvalue(), err.getvalue()


class TestCli(unittest.TestCase):
    def test_info_and_selfcheck(self):
        code, out, _ = run("info")
        self.assertEqual(code, 0)
        info = json.loads(out)
        self.assertEqual(info["presets"]["xs"]["params"], 25_172_352)
        self.assertEqual(info["presets"]["xs"]["params"], info["presets"]["xs"]["expected_in_spec"])
        code, out, _ = run("selfcheck", "--lock", str(CONFIGS / "special_tokens.lock.json"))
        self.assertEqual((code, json.loads(out)["ok"]), (0, True))

    def test_sources_check_example_is_not_approved(self):
        code, out, _ = run("sources-check", "--registry", str(CONFIGS / "sources.example.yaml"))
        self.assertEqual(code, 2)
        self.assertTrue(all(isinstance(v, list) and v for v in json.loads(out).values()))

    def test_full_data_and_export_flow(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "reg.json").write_text(json.dumps({"sources": [fx.source("pd").to_dict()]}))
            (root / "docs.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in fx.records(50, words=300, seed=4)))
            code, out, err = run("data-build", "--registry", str(root / "reg.json"), "--input", str(root / "docs.jsonl"), "--out", str(root / "ds"),
                                 "--profile", "smoke", "--val-rate", "0.1", "--test-rate", "0.1", "--min-chars", "50", "--shard-tokens", "5000")
            self.assertEqual(code, 0, err)
            self.assertEqual(run("data-verify", str(root / "ds"))[0], 0)
            code, out, err = run("export-random", "--model", "smoke", "--tokenizer", str(root / "ds" / "tokenizer"), "--out", str(root / "exp"))
            self.assertEqual(code, 0, err)
            self.assertEqual(json.loads(out)["training_status"], "smoke_test")
            self.assertEqual(run("export-verify", str(root / "exp"))[0], 0)
            (root / "exp" / "model.safetensors").write_bytes(b"corrompu")
            self.assertEqual(run("export-verify", str(root / "exp"))[0], 1)
            raw = (root / "ds" / "train").glob("*.bin")
            first = next(iter(sorted(raw)))
            data = bytearray(first.read_bytes()); data[0] ^= 1; first.write_bytes(bytes(data))
            self.assertEqual(run("data-verify", str(root / "ds"))[0], 1)

    def test_data_build_refuses_unapproved_registry(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "reg.json").write_text(json.dumps({"sources": [fx.source("pd", decision_training="pending").to_dict()]}))
            (root / "docs.jsonl").write_text(json.dumps(fx.records(1)[0]) + "\n")
            code, _, err = run("data-build", "--registry", str(root / "reg.json"), "--input", str(root / "docs.jsonl"), "--out", str(root / "ds"), "--profile", "smoke")
            self.assertEqual(code, 2)
            self.assertIn("aucun document admis", err)

    def test_train_plan_and_refusal_without_confirmation(self):
        code, out, _ = run("train-plan", "--model", "xs")
        plan = json.loads(out)
        self.assertEqual((code, plan["params"], plan["accumulation_steps"]), (0, 25_172_352, 32))
        self.assertEqual(plan["logits_gib_per_microbatch_fp32"], 1.0)
        self.assertIn("aucun entraînement", plan["note"])
        code, _, err = run("train-run", "--model", "xs", "--data", "x", "--out", "y")
        self.assertEqual(code, 3)
        self.assertIn("--confirm-training", err)
        code, _, err = run("export", "--model", "xs", "--ckpt-dir", "absent", "--data", "x", "--out", "y", "--status", "trained")
        self.assertEqual(code, 1)

    def test_unknown_command_exits(self):
        with self.assertRaises(SystemExit), contextlib.redirect_stderr(io.StringIO()):
            main(["nimportequoi"])


if __name__ == "__main__":
    unittest.main()
