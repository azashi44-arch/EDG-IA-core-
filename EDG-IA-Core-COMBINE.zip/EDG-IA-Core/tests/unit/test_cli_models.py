"""Tests de la commande `models` (registre) via la fonction `main`."""

from __future__ import annotations

import contextlib
import hashlib
import io
import tempfile
import unittest
from pathlib import Path

import yaml

from edgia_core.cli import main


class CliModelsTest(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.registry = str(self.root / "registry.sqlite3")

    def descriptor_file(self, version: str, *, reviewed: bool = True) -> Path:
        directory = self.root / version
        (directory / "tok").mkdir(parents=True)
        (directory / "model.safetensors").write_bytes(version.encode())
        path = directory / "model.yaml"
        path.write_text(
            yaml.safe_dump(
                {
                    "model_id": "edgia-test",
                    "version": version,
                    "weights_path": "model.safetensors",
                    "tokenizer_path": "tok",
                    "weights_format": "safetensors",
                    "runtime": "transformers",
                    "license": {"name": "t", "commercial_use_allowed": True, "reviewed": reviewed},
                    "sha256": {"model.safetensors": hashlib.sha256(version.encode()).hexdigest()},
                }
            ),
            encoding="utf-8",
        )
        return path

    def run_cli(self, *args: str) -> tuple[int, str]:
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            code = main(["models", "--registry", self.registry, *args])
        return code, out.getvalue()

    def test_full_workflow(self) -> None:
        for version in ("1.0.0", "2.0.0"):
            self.assertEqual(self.run_cli("register", str(self.descriptor_file(version)))[0], 0)
            self.assertEqual(self.run_cli("validate", "edgia-test", version)[0], 0)
        self.assertEqual(self.run_cli("activate", "edgia-test", "1.0.0")[0], 0)
        self.assertEqual(self.run_cli("activate", "edgia-test", "2.0.0")[0], 0)
        code, out = self.run_cli("list")
        self.assertEqual(code, 0)
        self.assertIn("edgia-test 2.0.0 : active", out)
        self.assertIn("edgia-test 1.0.0 : retired", out)
        code, out = self.run_cli("rollback")
        self.assertEqual((code, out.strip()), (0, "edgia-test 1.0.0 : active"))
        self.assertIn("rollback", self.run_cli("history")[1])

    def test_unreviewed_license_fails_validation_and_blocks_activation(self) -> None:
        self.run_cli("register", str(self.descriptor_file("1.0.0", reviewed=False)))
        code, out = self.run_cli("validate", "edgia-test", "1.0.0")
        self.assertEqual(code, 2)
        self.assertIn("Licence non vérifiée", out)
        code, out = self.run_cli("activate", "edgia-test", "1.0.0")
        self.assertEqual(code, 2)
        self.assertIn("Refusé", out)

    def test_duplicate_registration_and_unknown_version_are_refused(self) -> None:
        path = self.descriptor_file("1.0.0")
        self.assertEqual(self.run_cli("register", str(path))[0], 0)
        self.assertEqual(self.run_cli("register", str(path))[0], 2)
        self.assertEqual(self.run_cli("activate", "edgia-test", "9.9.9")[0], 2)

    def test_invalid_descriptor_is_refused(self) -> None:
        bad = self.root / "bad.yaml"
        bad.write_text("model_id: x\n", encoding="utf-8")
        self.assertEqual(self.run_cli("register", str(bad))[0], 2)

    def test_empty_registry_lists_nothing(self) -> None:
        code, out = self.run_cli("list")
        self.assertEqual((code, out.strip()), (0, "Registre vide."))


if __name__ == "__main__":
    unittest.main()
