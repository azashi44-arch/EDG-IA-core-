"""Tests unitaires de l'authentification, de la limitation de débit et du verrou de concurrence."""

from __future__ import annotations

import threading
import unittest

from edgia_core.inference.gate import ConcurrencyGate
from edgia_core.security.auth import MAX_TOKEN_LENGTH, ApiKeyAuthenticator
from edgia_core.security.ratelimit import SlidingWindowRateLimiter

KEY_1 = "premiere-cle-de-test-123456"
KEY_2 = "seconde-cle-de-test-7890123"


class AuthenticatorTest(unittest.TestCase):
    def setUp(self) -> None:
        self.auth = ApiKeyAuthenticator([KEY_1, KEY_2])

    def test_valid_keys_identify_by_position(self) -> None:
        self.assertEqual(self.auth.authenticate(f"Bearer {KEY_1}").key_id, "key-1")
        self.assertEqual(self.auth.authenticate(f"Bearer {KEY_2}").key_id, "key-2")

    def test_scheme_is_case_insensitive(self) -> None:
        self.assertIsNotNone(self.auth.authenticate(f"bearer {KEY_1}"))
        self.assertIsNotNone(self.auth.authenticate(f"BEARER {KEY_1}"))

    def test_invalid_inputs_are_refused(self) -> None:
        for header in (
            None,
            "",
            "Bearer",
            "Bearer ",
            KEY_1,
            f"Basic {KEY_1}",
            "Bearer mauvaise-cle",
            f"Bearer {KEY_1}x",
            f"Bearer {KEY_1} extra",
            f"Bearer {'x' * (MAX_TOKEN_LENGTH + 1)}",
        ):
            self.assertIsNone(self.auth.authenticate(header), header)

    def test_identity_never_contains_the_key(self) -> None:
        principal = self.auth.authenticate(f"Bearer {KEY_1}")
        self.assertNotIn(KEY_1, repr(principal))
        self.assertNotIn(KEY_1, repr(self.auth.__dict__))

    def test_at_least_one_key_is_required(self) -> None:
        with self.assertRaises(ValueError):
            ApiKeyAuthenticator([])


class FakeClock:
    def __init__(self) -> None:
        self.now = 1000.0

    def __call__(self) -> float:
        return self.now


class RateLimiterTest(unittest.TestCase):
    def setUp(self) -> None:
        self.clock = FakeClock()
        self.limiter = SlidingWindowRateLimiter(3, 60.0, clock=self.clock)

    def test_allows_up_to_the_limit_then_blocks(self) -> None:
        for _ in range(3):
            self.assertTrue(self.limiter.hit("a").allowed)
        decision = self.limiter.hit("a")
        self.assertFalse(decision.allowed)
        self.assertGreater(decision.retry_after, 0)
        self.assertLessEqual(decision.retry_after, 60.0)

    def test_window_slides(self) -> None:
        for _ in range(3):
            self.limiter.hit("a")
            self.clock.now += 10
        # 30 s écoulées : toujours bloqué ; après 60 s depuis le premier événement : libre
        self.assertFalse(self.limiter.hit("a").allowed)
        self.clock.now += 31
        self.assertTrue(self.limiter.hit("a").allowed)

    def test_identities_are_independent(self) -> None:
        for _ in range(3):
            self.limiter.hit("a")
        self.assertFalse(self.limiter.hit("a").allowed)
        self.assertTrue(self.limiter.hit("b").allowed)

    def test_peek_does_not_record(self) -> None:
        for _ in range(10):
            self.assertTrue(self.limiter.peek("a").allowed)
        for _ in range(3):
            self.assertTrue(self.limiter.hit("a").allowed)
        self.assertFalse(self.limiter.peek("a").allowed)

    def test_blocked_hits_are_not_recorded(self) -> None:
        for _ in range(3):
            self.limiter.hit("a")
        for _ in range(50):
            self.limiter.hit("a")
        self.clock.now += 61
        self.assertTrue(self.limiter.hit("a").allowed)

    def test_memory_is_bounded(self) -> None:
        limiter = SlidingWindowRateLimiter(1, 60.0, clock=self.clock, max_identities=5)
        for i in range(100):
            limiter.hit(f"id-{i}")
        self.assertLessEqual(len(limiter._events), 5)

    def test_invalid_arguments_are_refused(self) -> None:
        for kwargs in ({"limit": 0}, {"limit": 1, "window_seconds": 0}, {"limit": 1, "max_identities": 0}):
            with self.assertRaises(ValueError):
                SlidingWindowRateLimiter(**kwargs)


class GateTest(unittest.TestCase):
    def test_capacity_is_enforced_without_queueing(self) -> None:
        gate = ConcurrencyGate(2)
        first, second = gate.try_acquire(), gate.try_acquire()
        self.assertIsNotNone(first)
        self.assertIsNotNone(second)
        self.assertIsNone(gate.try_acquire())
        self.assertEqual(gate.in_flight, 2)

    def test_release_is_idempotent(self) -> None:
        gate = ConcurrencyGate(1)
        slot = gate.try_acquire()
        slot.release()
        slot.release()
        self.assertEqual(gate.in_flight, 0)
        self.assertIsNotNone(gate.try_acquire())

    def test_release_from_another_thread(self) -> None:
        gate = ConcurrencyGate(1)
        slot = gate.try_acquire()
        worker = threading.Thread(target=slot.release)
        worker.start()
        worker.join()
        self.assertEqual(gate.in_flight, 0)

    def test_invalid_capacity_is_refused(self) -> None:
        with self.assertRaises(ValueError):
            ConcurrencyGate(0)


if __name__ == "__main__":
    unittest.main()
