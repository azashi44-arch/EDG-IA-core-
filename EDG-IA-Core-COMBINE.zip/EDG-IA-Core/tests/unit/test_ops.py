"""Tests des outils d'exploitation : doctor, backup, et cohérence de la documentation de configuration."""

from __future__ import annotations

import contextlib
import io
import json
import re
import sqlite3
import tempfile
import unittest
from pathlib import Path

from edgia_core.cli import main
from edgia_core.config import Settings
from edgia_core.errors import ConfigurationError
from edgia_core.knowledge.store import KnowledgeBase
from edgia_core.model.registry import ModelRegistry
from edgia_core.ops.backup import backup, verify_backup
from edgia_core.ops.doctor import FAIL, OK, WARN, Probes, exit_code, run_doctor
from tests.helpers import API_KEY

ROOT = Path(__file__).resolve().parents[2]
VERSIONS = {"pydantic": "2", "PyYAML": "6", "starlette": "1", "uvicorn": "0"}


def probes(**overrides) -> Probes:
    values = dict(
        memory_gb=lambda: 16.0,
        free_disk_gb=lambda p: 100.0,
        port_is_free=lambda h, p: True,
        version=lambda name: VERSIONS.get(name),
        cuda_summary=lambda: None,
        cpu_count=lambda: 4,
        python_version=(3, 13, 0),
    )
    values.update(overrides)
    return Probes(**values)


def by_name(checks, name):
    return [c for c in checks if c.name == name]


class DoctorTest(unittest.TestCase):
    ENV = {"EDGIA_API_KEYS": API_KEY}

    def test_healthy_demo_setup_has_no_failure(self) -> None:
        checks = run_doctor(self.ENV, probes=probes())
        self.assertEqual(exit_code(checks), 0, checks)
        self.assertEqual(by_name(checks, "Mode")[0].status, WARN)  # la démonstration est toujours signalée
        self.assertEqual(by_name(checks, "Bibliothèques d'IA")[0].status, OK)

    def test_missing_api_key_old_python_and_missing_packages_fail(self) -> None:
        checks = run_doctor({}, probes=probes(python_version=(3, 9, 0), version=lambda n: None))
        self.assertEqual(by_name(checks, "Python")[0].status, FAIL)
        self.assertEqual(by_name(checks, "Dépendances de base")[0].status, FAIL)
        self.assertEqual(exit_code(checks), 2)
        checks = run_doctor({}, probes=probes())
        self.assertEqual(by_name(checks, "Démarrage")[0].status, FAIL)

    def test_invalid_configuration_is_reported(self) -> None:
        checks = run_doctor({"EDGIA_INCONNUE": "1"}, probes=probes())
        self.assertEqual(by_name(checks, "Configuration")[0].status, FAIL)
        self.assertEqual(exit_code(checks), 2)

    def test_real_mode_without_ml_libraries_or_model_fails(self) -> None:
        checks = run_doctor({**self.ENV, "EDGIA_MODE": "real", "EDGIA_MODEL_DESCRIPTOR": "/absent.yaml"}, probes=probes())
        self.assertEqual(by_name(checks, "Bibliothèques d'IA")[0].status, FAIL)
        self.assertEqual(exit_code(checks), 2)

    def test_warnings_for_risky_settings(self) -> None:
        env = {
            **self.ENV, "EDGIA_HOST": "0.0.0.0", "EDGIA_ALLOWED_ORIGINS": "*",
            "EDGIA_RATE_LIMIT_ENABLED": "false", "EDGIA_LOG_REDACT_CONTENT": "false",
        }
        checks = run_doctor(env, probes=probes(port_is_free=lambda h, p: False, free_disk_gb=lambda p: 0.5))
        for name in ("Exposition", "CORS", "Limite de débit", "Journaux", "Port", "Disque (dossier courant)"):
            self.assertEqual(by_name(checks, name)[0].status, WARN, name)
        self.assertEqual(exit_code(checks), 0)  # des attentions, pas un blocage

    def test_world_readable_env_file_is_flagged(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            env_file = Path(tmp) / ".env"
            env_file.write_text(f"EDGIA_API_KEYS={API_KEY}\n")
            env_file.chmod(0o644)
            self.assertEqual(by_name(run_doctor({}, env_file=env_file, probes=probes()), "Fichier .env")[0].status, WARN)
            env_file.chmod(0o600)
            self.assertEqual(by_name(run_doctor({}, env_file=env_file, probes=probes()), "Fichier .env"), [])

    def test_oversized_model_without_gpu_fails(self) -> None:
        import hashlib

        import yaml

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "w").mkdir()
            (root / "w" / "model.safetensors").write_bytes(b"x" * 1000)
            (root / "tok").mkdir()
            descriptor = root / "m.yaml"
            descriptor.write_text(yaml.safe_dump({
                "model_id": "m", "version": "1", "weights_path": "w", "tokenizer_path": "tok", "weights_format": "safetensors",
                "runtime": "transformers", "license": {"name": "x", "commercial_use_allowed": True, "reviewed": True},
                "sha256": {"model.safetensors": hashlib.sha256(b"x" * 1000).hexdigest()},
            }))
            env = {**self.ENV, "EDGIA_MODE": "real", "EDGIA_MODEL_DESCRIPTOR": str(descriptor)}
            all_ml = probes(version=lambda n: "1" if n in ("torch", "transformers", "peft", "safetensors") else VERSIONS.get(n))
            import edgia_core.ops.doctor as doctor

            original = doctor._weights_gb
            doctor._weights_gb = lambda settings, report: 40.0  # modèle de 40 Go simulé, sans fichier de 40 Go
            self.addCleanup(setattr, doctor, "_weights_gb", original)
            checks = run_doctor(env, probes=Probes(**{**all_ml.__dict__, "memory_gb": lambda: 16.0}))
            self.assertEqual(by_name(checks, "Taille du modèle")[0].status, FAIL)
            checks = run_doctor(env, probes=Probes(**{**all_ml.__dict__, "memory_gb": lambda: 128.0}))
            self.assertEqual(by_name(checks, "Taille du modèle")[0].status, WARN)
            checks = run_doctor(env, probes=Probes(**{**all_ml.__dict__, "cuda_summary": lambda: "GPU 0: Test (80 Go)"}))
            self.assertEqual(by_name(checks, "Taille du modèle")[0].status, OK)


class BackupTest(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.registry = self.root / "registry.sqlite3"
        self.knowledge = self.root / "kb.sqlite3"
        ModelRegistry(self.registry)
        kb = KnowledgeBase(self.knowledge)
        kb.add_document("c.md", b"# T\n\nLa capitale du Cameroun est Yaounde.", title="Cours", source="s", rights="CC0")
        kb.close()

    def test_backup_is_consistent_verifiable_and_searchable(self) -> None:
        out = self.root / "sauvegarde"
        manifest = backup(out, registry=self.registry, knowledge=self.knowledge)
        self.assertEqual(set(manifest["files"]), {"registry.sqlite3", "knowledge.sqlite3"})
        self.assertEqual(verify_backup(out), [])
        restored = KnowledgeBase(out / "knowledge.sqlite3")
        self.assertTrue(restored.search("capitale Cameroun"))

    def test_backup_while_database_is_open_for_writing(self) -> None:
        writer = sqlite3.connect(self.knowledge)
        writer.execute("BEGIN")
        writer.execute("CREATE TABLE IF NOT EXISTS essai (x)")
        try:
            manifest = backup(self.root / "b", knowledge=self.knowledge)
        finally:
            writer.rollback()
            writer.close()
        self.assertEqual(verify_backup(self.root / "b"), [])
        self.assertIn("knowledge.sqlite3", manifest["files"])

    def test_corruption_and_tampering_are_detected(self) -> None:
        out = self.root / "b"
        backup(out, knowledge=self.knowledge)
        with (out / "knowledge.sqlite3").open("ab") as handle:
            handle.write(b"\0\0\0")
        self.assertTrue(any("SHA-256" in p for p in verify_backup(out)))
        (out / "knowledge.sqlite3").unlink()
        self.assertTrue(any("manquant" in p for p in verify_backup(out)))
        self.assertTrue(verify_backup(self.root / "absent"))

    def test_refusals(self) -> None:
        with self.assertRaises(ConfigurationError):
            backup(self.root / "x")  # rien à sauvegarder
        with self.assertRaises(ConfigurationError):
            backup(self.root / "x", registry=self.root / "absent.sqlite3")
        not_a_db = self.root / "bad.sqlite3"
        not_a_db.write_text("ceci n'est pas une base")
        with self.assertRaises(ConfigurationError):
            backup(self.root / "y", knowledge=not_a_db)
        out = self.root / "z"
        backup(out, knowledge=self.knowledge)
        with self.assertRaises(ConfigurationError):
            backup(out, knowledge=self.knowledge)  # n'écrase rien

    def test_cli(self) -> None:
        def run(*argv: str) -> tuple[int, str]:
            buffer = io.StringIO()
            with contextlib.redirect_stdout(buffer):
                return main(list(argv)), buffer.getvalue()

        out = str(self.root / "cli")
        code, text = run("backup", "--registry", str(self.registry), "--knowledge", str(self.knowledge), "--out", out)
        self.assertEqual(code, 0, text)
        self.assertEqual(run("backup", "--verify", out)[0], 0)
        self.assertEqual(run("backup", "--knowledge", str(self.knowledge), "--out", out)[0], 2)
        self.assertEqual(run("backup", "--registry", str(self.registry))[0], 2)  # --out manquant
        (Path(out) / "registry.sqlite3").write_bytes(b"corrompu")
        self.assertEqual(run("backup", "--verify", out)[0], 2)


class DocumentationConsistencyTest(unittest.TestCase):
    def test_every_setting_is_documented_in_env_example(self) -> None:
        text = (ROOT / ".env.example").read_text(encoding="utf-8")
        documented = set(re.findall(r"^#?\s*EDGIA_([A-Z0-9_]+)=", text, re.MULTILINE))
        expected = {name.upper() for name in Settings.model_fields}
        self.assertEqual(expected - documented, set(), "variables absentes de .env.example")
        self.assertEqual(documented - expected, set(), "variables de .env.example inconnues de la configuration")


if __name__ == "__main__":
    unittest.main()
