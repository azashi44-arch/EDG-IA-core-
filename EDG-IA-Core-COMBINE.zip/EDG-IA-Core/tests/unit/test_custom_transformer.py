import pytest
from edgia_core.custom_model.tokenizer import ByteTokenizer


def test_byte_tokenizer_roundtrip_french_and_emoji():
    tokenizer = ByteTokenizer()
    text = "EDG-IA — modèle français 🤖"
    assert tokenizer.decode(tokenizer.encode(text)) == text


def test_byte_tokenizer_rejects_invalid_ids():
    with pytest.raises(ValueError):
        ByteTokenizer().decode([256])


def test_transformer_shapes_and_causal_generation():
    torch = pytest.importorskip("torch")
    from edgia_core.custom_model.transformer import EDGIAConfig, EDGIATransformer
    config = EDGIAConfig(vocab_size=256, context_length=16, d_model=32, n_heads=4, n_layers=2)
    model = EDGIATransformer(config)
    x = torch.randint(0, 256, (2, 8))
    assert model(x).shape == (2, 8, 256)
    assert model.generate(x[:1], max_new_tokens=2, top_k=5).shape == (1, 10)


def test_transformer_rejects_bad_dimensions():
    pytest.importorskip("torch")
    from edgia_core.custom_model.transformer import EDGIAConfig
    with pytest.raises(ValueError):
        EDGIAConfig(d_model=30, n_heads=4)
