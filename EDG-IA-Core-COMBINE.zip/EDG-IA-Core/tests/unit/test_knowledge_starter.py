from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from edgia_core.knowledge.starter import STARTER_DOCUMENTS, seed_starter_library
from edgia_core.knowledge.store import KnowledgeBase


class StarterLibraryTest(unittest.TestCase):
    def test_seed_is_complete_searchable_and_idempotent(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db = KnowledgeBase(Path(tmp) / "knowledge.sqlite3")
            first = seed_starter_library(db)
            self.assertEqual(len(first["added"]), len(STARTER_DOCUMENTS))
            self.assertEqual(first["skipped"], [])
            self.assertEqual(first["stats"]["documents"], len(STARTER_DOCUMENTS))
            self.assertIn("programmation", first["stats"]["collections"])

            hits = db.search("Python langage", top_k=3, collection="programmation")
            self.assertTrue(hits)
            self.assertIn("Python", " ".join(hit.text for hit in hits))

            second = seed_starter_library(db)
            self.assertEqual(second["added"], [])
            self.assertEqual(len(second["skipped"]), len(STARTER_DOCUMENTS))
            self.assertEqual(second["stats"]["documents"], len(STARTER_DOCUMENTS))
            db.close()
