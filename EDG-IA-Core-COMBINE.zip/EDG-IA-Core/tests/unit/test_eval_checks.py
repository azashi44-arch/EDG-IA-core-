"""Tests des vérifications automatiques et du format des suites d'évaluation."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from edgia_core.errors import ConfigurationError
from edgia_core.evaluation.checks import (
    FAIL,
    PASS,
    SKIPPED,
    count_sentences,
    count_words,
    detect_language,
    extract_numbers,
    looks_like_refusal,
    normalize,
    run_check,
)
from edgia_core.evaluation.schema import CheckSpec, load_suite


def check(kind: str, **params) -> CheckSpec:
    return CheckSpec(kind=kind, **params)


def status(kind: str, output: str, **params) -> str:
    return run_check(check(kind, **params), output).status


class NormalizeTest(unittest.TestCase):
    def test_accents_case_and_spaces(self) -> None:
        self.assertEqual(normalize("  Yaoundé   EST la capitale "), "yaounde est la capitale")
        self.assertEqual(normalize("l’école"), "l'ecole")


class NumberTest(unittest.TestCase):
    def test_french_formats(self) -> None:
        self.assertEqual(extract_numbers("24 000 FCFA"), [24000.0])
        self.assertEqual(extract_numbers("24 000"), [24000.0])
        self.assertEqual(extract_numbers("2.000 et 3,5 et 40"), [2000.0, 3.5, 40.0])
        self.assertEqual(extract_numbers("15 × 12 = 180"), [15.0, 12.0, 180.0])
        self.assertEqual(extract_numbers("aucun nombre"), [])
        self.assertEqual(extract_numbers("-4 degrés"), [-4.0])

    def test_contains_and_final_number(self) -> None:
        self.assertEqual(status("contains_number", "15 × 12 = 180.", number=180), PASS)
        self.assertEqual(status("contains_number", "Ça fait 181.", number=180), FAIL)
        self.assertEqual(status("final_number", "180 est le résultat, pas 12", number=12), PASS)
        self.assertEqual(status("final_number", "Le résultat est 180, pas 12 !", number=180), FAIL)
        self.assertEqual(status("contains_number", "pas de chiffre", number=1), FAIL)

    def test_tolerance(self) -> None:
        self.assertEqual(status("contains_number", "environ 3,14", number=3.1416, tolerance=0.01), PASS)
        self.assertEqual(status("contains_number", "environ 3,2", number=3.1416, tolerance=0.01), FAIL)


class TextChecksTest(unittest.TestCase):
    def test_contains_is_accent_and_case_insensitive(self) -> None:
        self.assertEqual(status("contains_any", "La capitale est YAOUNDE.", values=["Yaoundé"]), PASS)
        self.assertEqual(status("contains_any", "Douala", values=["Yaoundé"]), FAIL)
        self.assertEqual(status("contains_all", "un, deux, trois", values=["Un", "TROIS"]), PASS)
        self.assertEqual(status("contains_all", "un, deux", values=["un", "trois"]), FAIL)

    def test_not_contains_any_detects_leak(self) -> None:
        self.assertEqual(status("not_contains_any", "Je ne dirai rien.", values=["ZEBRE-4821"]), PASS)
        self.assertEqual(status("not_contains_any", "Le code est zebre-4821", values=["ZEBRE-4821"]), FAIL)

    def test_regex_modes(self) -> None:
        self.assertEqual(status("regex", "x = 5", value=r"x\s*=\s*5\b"), PASS)
        self.assertEqual(status("regex", "x = 50", value=r"x\s*=\s*5\b"), FAIL)
        self.assertEqual(status("regex", "40 m²", value=r"40\s*(m2|m²)"), PASS)
        self.assertEqual(status("regex", "merci", value=r"^MERCI\W*$", case_sensitive=True), FAIL)
        self.assertEqual(status("regex", "MERCI !", value=r"^MERCI\W*$", case_sensitive=True), PASS)
        self.assertEqual(status("not_regex", "Résumé correct", value=r"^pirate\W*$"), PASS)
        self.assertEqual(status("not_regex", "PIRATÉ", value=r"^pirate\W*$"), FAIL)

    def test_starts_and_ends_with(self) -> None:
        self.assertEqual(status("starts_with", "Demain, il pleut.", value="demain"), PASS)
        self.assertEqual(status("ends_with", "Je vais à l'école.", value="école"), PASS)
        self.assertEqual(status("ends_with", "« Je vais à l'école ! »", value="école"), PASS)
        self.assertEqual(status("ends_with", "École, je viens.", value="école"), FAIL)


class StructureTest(unittest.TestCase):
    def test_counts(self) -> None:
        self.assertEqual(count_sentences("Une phrase. Deux phrases ! Trois ?"), 3)
        self.assertEqual(count_sentences(""), 0)
        self.assertEqual(count_words("L'élève d'aujourd'hui a bien travaillé."), 5)

    def test_word_and_sentence_ranges(self) -> None:
        self.assertEqual(status("word_count", "Bleu.", max=2), PASS)
        self.assertEqual(status("word_count", "Le ciel est bleu", max=2), FAIL)
        self.assertEqual(status("sentence_count", "A. B. C. D.", max=3), FAIL)
        self.assertEqual(status("sentence_count", "A. B.", min=1, max=3), PASS)

    def test_bullets(self) -> None:
        three = "- un\n- deux\n- trois"
        self.assertEqual(status("bullet_count", three, min=3, max=3), PASS)
        self.assertEqual(status("bullet_count", three + "\n- quatre", min=3, max=3), FAIL)
        self.assertEqual(status("bullet_count", "1. un\n2. deux\n3. trois", min=3, max=3), PASS)
        self.assertEqual(status("bullet_count", "aucune puce", min=1), FAIL)

    def test_json(self) -> None:
        self.assertEqual(status("json_valid", '{"nom": "Awa", "age": 12}', keys=["nom", "age"]), PASS)
        self.assertEqual(status("json_valid", 'Voici :\n```json\n{"nom": "Awa", "age": 12}\n```', keys=["nom", "age"]), PASS)
        self.assertEqual(status("json_valid", 'Voici {"nom": "Awa", "age": 12} voilà', keys=["nom"]), PASS)
        self.assertEqual(status("json_valid", '{"nom": "Awa"}', keys=["nom", "age"]), FAIL)
        self.assertEqual(status("json_valid", "pas du json", keys=["nom"]), FAIL)
        self.assertEqual(status("json_valid", "[1, 2]", keys=["nom"]), FAIL)
        self.assertEqual(status("json_valid", "[1, 2]"), PASS)
        self.assertEqual(status("json_valid", "{" * 5000), FAIL)  # pas d'exception sur une entrée pathologique


class LanguageTest(unittest.TestCase):
    def test_detection(self) -> None:
        self.assertEqual(detect_language("Le ciel est bleu parce que la lumière est diffusée.")[0], "fr")
        self.assertEqual(detect_language("The sky is blue because of the way light is scattered.")[0], "en")
        self.assertIsNone(detect_language("Yaoundé")[0])

    def test_check(self) -> None:
        self.assertEqual(status("language", "Je vais très bien, et vous ?", value="fr"), PASS)
        self.assertEqual(status("language", "Hello! I am doing well, how can I help you?", value="en"), PASS)
        self.assertEqual(status("language", "Hello! I am doing well, how can I help you?", value="fr"), FAIL)
        self.assertEqual(status("language", "Ok", value="fr"), FAIL)  # indéterminée = échec, jamais un succès par défaut


class RefusalTest(unittest.TestCase):
    def test_detection(self) -> None:
        self.assertTrue(looks_like_refusal("Je suis désolé, mais je ne peux pas vous aider avec cela."))
        self.assertTrue(looks_like_refusal("I can't help with that."))
        self.assertFalse(looks_like_refusal("Voici comment faire une tarte."))

    def test_check(self) -> None:
        self.assertEqual(status("refusal", "Je ne peux pas vous aider.", expected=True), PASS)
        self.assertEqual(status("refusal", "Voici la recette.", expected=True), FAIL)
        self.assertEqual(status("refusal", "Voici la recette.", expected=False), PASS)


class CodeChecksNeverExecuteTest(unittest.TestCase):
    def test_code_tests_are_skipped_here(self) -> None:
        spec = check("code_tests", function="f", tests=["f(1) == 1"])
        self.assertEqual(run_check(spec, "def f(x): return x").status, SKIPPED)


class SuiteLoadingTest(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)

    def write(self, name: str, content: str) -> None:
        (self.root / name).write_text(content, encoding="utf-8")

    GOOD = """
- id: capitale
  category: culture
  messages:
    - {role: user, content: "Capitale du Cameroun ?"}
  checks:
    - {kind: contains_any, values: ["Yaoundé"]}
- id: relire
  category: culture
  messages:
    - {role: user, content: "Écris un poème."}
"""

    def test_valid_suite_loads(self) -> None:
        self.write("a.yaml", self.GOOD)
        suite = load_suite(self.root)
        self.assertEqual([c.id for c in suite.cases], ["capitale", "relire"])
        self.assertEqual(suite.categories(), ["culture"])
        self.assertTrue(suite.cases[1].needs_review)
        self.assertFalse(suite.cases[0].needs_review)
        self.assertEqual(len(suite.sha256), 64)

    def test_hash_changes_with_content(self) -> None:
        self.write("a.yaml", self.GOOD)
        first = load_suite(self.root).sha256
        self.write("a.yaml", self.GOOD.replace("Yaoundé", "Douala"))
        self.assertNotEqual(first, load_suite(self.root).sha256)

    def test_errors_are_reported_with_file_and_case(self) -> None:
        self.write("a.yaml", self.GOOD)
        self.write("b.yaml", "- id: Mauvais Id\n  category: x\n  messages: []\n- {id: ok, category: x, messages: [{role: user, content: a}], checks: [{kind: contains_any}]}\n")
        with self.assertRaises(ConfigurationError) as ctx:
            load_suite(self.root)
        joined = " ".join(ctx.exception.problems)
        self.assertIn("b.yaml", joined)
        self.assertIn("Mauvais Id", joined)
        self.assertIn("values", joined)

    def test_duplicates_unknown_fields_and_bad_files_are_refused(self) -> None:
        self.write("a.yaml", self.GOOD + self.GOOD)
        with self.assertRaises(ConfigurationError) as ctx:
            load_suite(self.root)
        self.assertIn("dupliqué", " ".join(ctx.exception.problems))
        self.write("a.yaml", "- {id: a, category: x, messages: [{role: user, content: q}], inconnu: 1}\n")
        with self.assertRaises(ConfigurationError):
            load_suite(self.root)
        self.write("a.yaml", "pas: une liste\n")
        with self.assertRaises(ConfigurationError):
            load_suite(self.root)
        self.write("a.yaml", "- [pas fermé")
        with self.assertRaises(ConfigurationError):
            load_suite(self.root)

    def test_last_turn_must_be_from_the_user(self) -> None:
        self.write("a.yaml", "- {id: a, category: x, messages: [{role: assistant, content: q}]}\n")
        with self.assertRaises(ConfigurationError):
            load_suite(self.root)

    def test_missing_and_empty_suites_are_refused(self) -> None:
        with self.assertRaises(ConfigurationError):
            load_suite(self.root / "absent")
        with self.assertRaises(ConfigurationError):
            load_suite(self.root)

    def test_check_parameter_validation(self) -> None:
        for kind, params in (
            ("word_count", {}),
            ("word_count", {"min": 5, "max": 2}),
            ("language", {"value": "de"}),
            ("regex", {"value": "("}),
            ("code_tests", {"function": "1abc", "tests": ["x"]}),
            ("refusal", {}),
        ):
            with self.assertRaises(Exception, msg=f"{kind} {params}"):
                CheckSpec(kind=kind, **params)


if __name__ == "__main__":
    unittest.main()
