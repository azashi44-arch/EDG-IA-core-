"""Tests de la logique du moteur de langage (arrêts, annulation, streaming) avec un backend factice."""

from __future__ import annotations

import asyncio
import threading
import time
import unittest
from collections.abc import Iterator, Sequence

from edgia_core.inference.base import EngineError, GenerationParams, Message, ModelInfo
from edgia_core.inference.llm_engine import Backend, Done, LanguageModelEngine, Piece
from edgia_core.inference.stops import StopMatcher

MESSAGES = [Message("user", "Bonjour")]
INFO = ModelInfo(id="edgia-test", version="1", runtime="fake", is_demo=False)


class ScriptedBackend(Backend):
    """Produit des morceaux fixes ; garde la trace de ce qui s'est passé."""

    def __init__(self, pieces: Sequence[str], *, finish: str = "stop", delay: float = 0.0, forget_done: bool = False) -> None:
        self.pieces = list(pieces)
        self.finish = finish
        self.delay = delay
        self.forget_done = forget_done
        self.produced = 0
        self.closed_stream = False
        self.closed = False
        self.seen_cancel = False

    def count_prompt_tokens(self, messages: Sequence[Message]) -> int:
        return 7

    def stream(self, messages, params, cancel) -> Iterator[Piece | Done]:
        try:
            for piece in self.pieces:
                if cancel.is_set():
                    self.seen_cancel = True
                    return
                if self.delay:
                    time.sleep(self.delay)
                self.produced += 1
                yield Piece(piece)
            if not self.forget_done:
                yield Done(self.finish, len(self.pieces))
        finally:
            self.closed_stream = True

    def close(self) -> None:
        self.closed = True


PARAMS = GenerationParams(max_tokens=50)


class StopMatcherTest(unittest.TestCase):
    def collect(self, stops: tuple[str, ...], chunks: Sequence[str]) -> tuple[str, bool]:
        matcher = StopMatcher(stops)
        out = "".join(matcher.feed(c) for c in chunks) + matcher.flush()
        return out, matcher.stopped

    def test_no_stops_passes_text_through(self) -> None:
        self.assertEqual(self.collect((), ["ab", "cd"]), ("abcd", False))

    def test_stop_inside_one_chunk(self) -> None:
        self.assertEqual(self.collect(("STOP",), ["avant STOP après"]), ("avant ", True))

    def test_stop_split_across_chunks(self) -> None:
        self.assertEqual(self.collect(("STOP",), ["avant ST", "OP après"]), ("avant ", True))
        self.assertEqual(self.collect(("STOP",), list("avantSTOP")), ("avant", True))

    def test_partial_stop_at_end_is_flushed(self) -> None:
        self.assertEqual(self.collect(("STOP",), ["fin ST"]), ("fin ST", False))

    def test_earliest_of_several_stops_wins(self) -> None:
        self.assertEqual(self.collect(("BB", "A"), ["xxAxxBB"]), ("xx", True))

    def test_nothing_is_emitted_after_stop(self) -> None:
        matcher = StopMatcher(("X",))
        self.assertEqual(matcher.feed("aXb"), "a")
        self.assertEqual(matcher.feed("suite"), "")
        self.assertEqual(matcher.flush(), "")

    def test_stop_sequence_is_never_emitted(self) -> None:
        for chunks in (["a", "b", "STOP"], ["abS", "TOP"], ["abSTOP"]):
            self.assertNotIn("STOP", self.collect(("STOP",), chunks)[0])


class GenerateTest(unittest.TestCase):
    def test_collects_text_and_counts(self) -> None:
        backend = ScriptedBackend(["Bon", "jour", " !"])
        result = LanguageModelEngine(INFO, backend).generate(MESSAGES, PARAMS)
        self.assertEqual(result.text, "Bonjour !")
        self.assertEqual(result.finish_reason, "stop")
        self.assertEqual(result.prompt_tokens, 7)
        self.assertEqual(result.completion_tokens, 3)
        self.assertTrue(backend.closed_stream)

    def test_length_finish_is_forwarded(self) -> None:
        result = LanguageModelEngine(INFO, ScriptedBackend(["a", "b"], finish="length")).generate(MESSAGES, PARAMS)
        self.assertEqual(result.finish_reason, "length")

    def test_stop_sequence_cuts_text_and_closes_backend_stream(self) -> None:
        backend = ScriptedBackend(["Réponse", " finale", "<fin>", " ignoré", " aussi"])
        result = LanguageModelEngine(INFO, backend).generate(MESSAGES, GenerationParams(max_tokens=50, stop=("<fin>",)))
        self.assertEqual(result.text, "Réponse finale")
        self.assertEqual(result.finish_reason, "stop")
        self.assertTrue(backend.closed_stream)
        self.assertEqual(backend.produced, 3)  # le backend n'a pas été sollicité après l'arrêt

    def test_backend_without_done_is_an_error(self) -> None:
        with self.assertRaises(EngineError):
            LanguageModelEngine(INFO, ScriptedBackend(["a"], forget_done=True)).generate(MESSAGES, PARAMS)

    def test_cancel_stops_generation(self) -> None:
        backend = ScriptedBackend(["x"] * 100, delay=0.01)
        engine = LanguageModelEngine(INFO, backend)
        cancel = threading.Event()
        threading.Timer(0.05, cancel.set).start()
        started = time.monotonic()
        with self.assertRaises(EngineError):
            engine.generate(MESSAGES, PARAMS, cancel)
        self.assertLess(time.monotonic() - started, 0.8)
        self.assertLess(backend.produced, 100)

    def test_closed_engine_refuses_and_is_not_ready(self) -> None:
        backend = ScriptedBackend(["a"])
        engine = LanguageModelEngine(INFO, backend)
        self.assertTrue(engine.is_ready())
        engine.close()
        engine.close()  # idempotent
        self.assertFalse(engine.is_ready())
        self.assertTrue(backend.closed)
        with self.assertRaises(EngineError):
            engine.generate(MESSAGES, PARAMS)


class StreamTest(unittest.IsolatedAsyncioTestCase):
    async def test_streams_pieces_then_final_chunk(self) -> None:
        backend = ScriptedBackend(["Bon", "jour"])
        chunks = [c async for c in LanguageModelEngine(INFO, backend).stream(MESSAGES, PARAMS)]
        self.assertEqual("".join(c.text for c in chunks), "Bonjour")
        self.assertEqual(chunks[-1].finish_reason, "stop")
        self.assertEqual(chunks[-1].completion_tokens, 2)
        self.assertTrue(all(c.finish_reason is None for c in chunks[:-1]))

    async def test_stream_applies_stop_sequences(self) -> None:
        backend = ScriptedBackend(["a", "b", "ST", "OP", "c"])
        chunks = [c async for c in LanguageModelEngine(INFO, backend).stream(MESSAGES, GenerationParams(max_tokens=9, stop=("STOP",)))]
        self.assertEqual("".join(c.text for c in chunks), "ab")

    async def test_consumer_leaving_cancels_the_worker(self) -> None:
        backend = ScriptedBackend(["x"] * 200, delay=0.01)
        engine = LanguageModelEngine(INFO, backend)
        iterator = engine.stream(MESSAGES, PARAMS).__aiter__()
        await iterator.__anext__()
        await iterator.aclose()
        await asyncio.sleep(0.2)
        self.assertTrue(backend.seen_cancel or backend.closed_stream)
        self.assertLess(backend.produced, 200)

    async def test_backend_error_is_raised_to_the_consumer(self) -> None:
        class Boom(ScriptedBackend):
            def stream(self, messages, params, cancel):
                yield Piece("début")
                raise RuntimeError("panne")

        with self.assertRaises(RuntimeError):
            _ = [c async for c in LanguageModelEngine(INFO, Boom([])).stream(MESSAGES, PARAMS)]


if __name__ == "__main__":
    unittest.main()
