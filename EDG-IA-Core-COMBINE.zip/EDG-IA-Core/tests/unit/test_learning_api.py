"""Tests de l'API d'apprentissage : POST/GET /v1/learning/lessons, DELETE /v1/learning/lessons/{id} (aucun modèle réel)."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import yaml

from edgia_core.api.app import create_app
from edgia_core.api.schemas import LessonRequest
from edgia_core.knowledge.store import KnowledgeBase
from edgia_core.learning import LearningStore
from tests.helpers import OTHER_KEY, auth, make_settings, request

LESSONS = "/v1/learning/lessons"
FACT = "La capitale politique du Cameroun est Yaoundé et sa capitale économique est Douala."
EXAMPLE = [
    {"role": "user", "content": "Quelle est la capitale du Cameroun ?"},
    {"role": "assistant", "content": "La capitale politique du Cameroun est Yaoundé."},
]
ROOT = Path(__file__).resolve().parents[2]


class LearningApiCase(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        root = Path(self._tmp.name)
        self.learning_db, self.kb_db = root / "l.sqlite3", root / "k.sqlite3"
        LearningStore(self.learning_db)
        KnowledgeBase(self.kb_db).close()

    def build(self, **extra: str):
        settings = {"learning_db": str(self.learning_db), "knowledge_db": str(self.kb_db), **extra}
        app = create_app(make_settings(**settings))
        self.addCleanup(app.state.ctx.close)
        return app

    async def post(self, app, body, key=None):
        return await request(app, "POST", LESSONS, headers=auth(*([key] if key else [])), json_body=body)


class CreateTest(LearningApiCase):
    async def test_fact_is_accepted_as_pending_and_content_is_not_echoed(self) -> None:
        response = await self.post(self.build(), {"kind": "fact", "consent": True, "text": FACT})
        self.assertEqual(response.status, 201, response.text)
        body = response.json()
        self.assertEqual((body["object"], body["kind"], body["status"], body["indexed"]), ("lesson", "fact", "pending", False))
        self.assertNotIn("Yaoundé", response.text)

    async def test_example_from_a_chat(self) -> None:
        response = await self.post(self.build(), {"kind": "example", "consent": True, "messages": EXAMPLE})
        self.assertEqual(response.status, 201, response.text)

    async def test_consent_is_mandatory(self) -> None:
        response = await self.post(self.build(), {"kind": "fact", "consent": False, "text": FACT})
        self.assertEqual((response.status, response.json()["error"]["code"]), (422, "consent_required"))
        missing = await self.post(self.build(), {"kind": "fact", "text": FACT})
        self.assertEqual((missing.status, missing.json()["error"]["code"]), (422, "invalid_request"))

    async def test_invalid_requests(self) -> None:
        app = self.build()
        for body in (
            {"kind": "fact", "consent": True, "text": FACT, "extra": 1},
            {"kind": "inconnu", "consent": True, "text": FACT},
            {"kind": "example", "consent": True, "messages": [{"role": "system", "content": "x"}]},
        ):
            self.assertEqual((await self.post(app, body)).status, 422, body)
        wrong_type = await request(app, "POST", LESSONS, headers={**auth(), "Content-Type": "text/plain"}, body=b"{}")
        self.assertEqual(wrong_type.status, 415)
        bad_json = await request(app, "POST", LESSONS, headers=auth(), body=b"{", )
        self.assertEqual(bad_json.status, 400)

    async def test_duplicate_is_conflict(self) -> None:
        app = self.build()
        body = {"kind": "fact", "consent": True, "text": FACT}
        await self.post(app, body)
        again = await self.post(app, body)
        self.assertEqual((again.status, again.json()["error"]["code"]), (409, "lesson_duplicate"))
        self.assertEqual(again.json()["error"]["type"], "invalid_request_error")

    async def test_quota_per_key(self) -> None:
        app = self.build(learning_max_pending_per_key="1")
        self.assertEqual((await self.post(app, {"kind": "fact", "consent": True, "text": FACT})).status, 201)
        full = await self.post(app, {"kind": "fact", "consent": True, "text": FACT + " Autre fait."})
        self.assertEqual((full.status, full.json()["error"]["code"]), (429, "lesson_quota_exceeded"))

    async def test_requires_authentication_and_configuration(self) -> None:
        self.assertEqual((await request(self.build(), "POST", LESSONS, json_body={})).status, 401)
        app = create_app(make_settings())
        self.addCleanup(app.state.ctx.close)
        response = await self.post(app, {"kind": "fact", "consent": True, "text": FACT})
        self.assertEqual((response.status, response.json()["error"]["code"]), (404, "learning_disabled"))


class AutoApproveTest(LearningApiCase):
    async def test_fact_is_indexed_at_once_when_enabled(self) -> None:
        app = self.build(learning_auto_approve_facts="true")
        body = (await self.post(app, {"kind": "fact", "consent": True, "text": FACT})).json()
        self.assertEqual((body["status"], body["indexed"]), ("approved", True))
        self.assertTrue(app.state.ctx.knowledge.search("capitale politique du Cameroun", collection="appris-chat"))
        example = (await self.post(app, {"kind": "example", "consent": True, "messages": EXAMPLE})).json()
        self.assertEqual(example["status"], "pending")  # un exemple n'est jamais validé automatiquement

    async def test_requires_both_databases(self) -> None:
        with self.assertRaises(Exception):
            create_app(make_settings(learning_db=str(self.learning_db), learning_auto_approve_facts="true"))


class ListAndDeleteTest(LearningApiCase):
    async def test_each_key_sees_and_deletes_only_its_own_lessons(self) -> None:
        app = self.build(api_keys=f"{'a' * 24},{'b' * 24}")
        key_a, key_b = "a" * 24, "b" * 24
        created = (await self.post(app, {"kind": "fact", "consent": True, "text": FACT}, key_a)).json()
        listing = await request(app, "GET", LESSONS, headers=auth(key_a))
        self.assertEqual([item["id"] for item in listing.json()["data"]], [created["id"]])
        self.assertEqual((await request(app, "GET", LESSONS, headers=auth(key_b))).json()["data"], [])
        path = f"{LESSONS}/{created['id']}"
        self.assertEqual((await request(app, "DELETE", path, headers=auth(key_b))).status, 404)
        self.assertEqual((await request(app, "DELETE", path, headers=auth(key_a))).json()["deleted"], True)
        self.assertEqual((await request(app, "DELETE", path, headers=auth(key_a))).status, 404)

    async def test_status_filter_and_bad_id(self) -> None:
        app = self.build()
        self.assertEqual((await request(app, "GET", LESSONS + "?status=nimporte", headers=auth())).status, 422)
        self.assertEqual((await request(app, "GET", LESSONS + "?status=pending", headers=auth())).status, 200)
        self.assertEqual((await request(app, "DELETE", LESSONS + "/pas-un-id", headers=auth())).status, 404)

    async def test_withdrawing_an_indexed_lesson_removes_it_from_answers(self) -> None:
        app = self.build(learning_auto_approve_facts="true")
        created = (await self.post(app, {"kind": "fact", "consent": True, "text": FACT})).json()
        kb = app.state.ctx.knowledge
        self.assertTrue(kb.search("capitale politique du Cameroun"))
        await request(app, "DELETE", f"{LESSONS}/{created['id']}", headers=auth())
        self.assertEqual(kb.search("capitale politique du Cameroun"), [])


class ContractTest(unittest.TestCase):
    def test_openapi_describes_the_lesson_routes_and_schema(self) -> None:
        spec = yaml.safe_load((ROOT / "docs" / "openapi.yaml").read_text(encoding="utf-8"))
        self.assertEqual(set(spec["paths"]["/v1/learning/lessons"]), {"get", "post"})
        self.assertEqual(set(spec["paths"]["/v1/learning/lessons/{lesson_id}"]), {"delete"})
        self.assertEqual(set(spec["components"]["schemas"]["LessonRequest"]["properties"]), set(LessonRequest.model_fields))


if __name__ == "__main__":
    unittest.main()
