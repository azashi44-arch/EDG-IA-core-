"""Tests du contrat d'API : cohérence de la spécification OpenAPI avec le code, et du vérificateur de contrat."""

from __future__ import annotations

import http.server
import json
import re
import threading
import unittest
from pathlib import Path

import yaml

from edgia_core.api.app import create_app
from edgia_core.integration.contract_check import MARKER, run_contract_check
from tests.helpers import API_KEY, make_settings

ROOT = Path(__file__).resolve().parents[2]
SPEC = yaml.safe_load((ROOT / "docs" / "openapi.yaml").read_text(encoding="utf-8"))


class OpenApiConsistencyTest(unittest.TestCase):
    def test_spec_routes_match_the_application_routes(self) -> None:
        app = create_app(make_settings())
        self.addCleanup(app.state.ctx.close)
        in_app = {(m.lower(), r.path) for r in app.routes for m in (r.methods or ()) if m not in ("HEAD", "OPTIONS")}
        in_spec = {(m, path) for path, ops in SPEC["paths"].items() for m in ops}
        self.assertEqual(in_app, in_spec)

    def test_every_error_code_in_the_code_is_in_the_spec_and_in_api_md(self) -> None:
        codes = set()
        for file in (ROOT / "src" / "edgia_core").rglob("*.py"):
            codes.update(re.findall(r'ApiError\(\s*\d+,\s*"([a-z_]+)"', file.read_text(encoding="utf-8")))
        codes.update({"not_found", "method_not_allowed", "rate_limited", "context_length_exceeded", "internal_error"})  # levés hors de ApiError(…) littéral
        enum = set(SPEC["components"]["schemas"]["Error"]["properties"]["error"]["properties"]["code"]["enum"])
        api_md = (ROOT / "docs" / "API.md").read_text(encoding="utf-8")
        self.assertEqual(codes - enum, set(), "codes d'erreur absents de openapi.yaml")
        for code in enum:
            self.assertIn(f"`{code}`", api_md, f"{code} absent de API.md")

    def test_request_schema_matches_the_pydantic_models(self) -> None:
        from edgia_core.api.schemas import ChatCompletionRequest, KnowledgeOptions, KnowledgeSearchRequest

        chat = set(SPEC["components"]["schemas"]["ChatRequest"]["properties"])
        self.assertEqual(chat, set(ChatCompletionRequest.model_fields))
        self.assertEqual(set(SPEC["components"]["schemas"]["KnowledgeOptions"]["properties"]), set(KnowledgeOptions.model_fields))
        self.assertEqual(set(SPEC["components"]["schemas"]["KnowledgeSearchRequest"]["properties"]), set(KnowledgeSearchRequest.model_fields))


class _Fake(http.server.BaseHTTPRequestHandler):
    """Serveur défectueux : renvoie des formes non conformes, et recopie le contenu dans ses erreurs."""

    def log_message(self, *args) -> None:  # silence
        pass

    def _send(self, status: int, body: object, headers: dict | None = None) -> None:
        data = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        if self.path == "/health":
            self._send(200, {"status": "ok"})
        elif self.path == "/ready":
            self._send(200, {"status": "ready", "demo": False, "model": "x"})
        elif self.path == "/v1/models":
            self._send(200, {"data": [{"id": "x"}]})  # edgia.demo absent
        else:
            self._send(404, {"detail": "pas le bon format"})

    def do_POST(self) -> None:
        body = self.rfile.read(int(self.headers.get("Content-Length", 0))).decode()
        self._send(422, {"error": {"type": "t", "code": "invalid_request", "message": "reçu : " + body}})


class ContractCheckTest(unittest.TestCase):
    def test_conforming_server_passes_every_check(self) -> None:
        import socket
        import subprocess
        import sys
        import time

        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        env = {"PATH": "/usr/bin:/bin", "PYTHONPATH": str(ROOT / "src"), "EDGIA_PORT": str(port), "EDGIA_API_KEYS": API_KEY}
        process = subprocess.Popen([sys.executable, "-m", "edgia_core", "serve"], env=env, cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.addCleanup(process.wait)
        self.addCleanup(process.terminate)
        url = f"http://127.0.0.1:{port}"
        for _ in range(100):
            try:
                if run_contract_check(url, API_KEY, timeout=2)[0].ok:
                    break
            except OSError:
                pass
            time.sleep(0.1)
        results = run_contract_check(url, API_KEY)
        self.assertEqual([r for r in results if not r.ok], [], results)
        self.assertEqual(len(results), 10)
        real = {r.name: r for r in run_contract_check(url, API_KEY, expect_real=True)}
        self.assertFalse(real["GET /ready (et mode démonstration)"].ok)  # la démonstration n'est jamais prise pour le vrai modèle
        self.assertIn("DÉMONSTRATION", real["GET /ready (et mode démonstration)"].detail)
        wrong_key = run_contract_check(url, "z" * 30)
        self.assertFalse(next(r for r in wrong_key if r.name == "GET /v1/models").ok)

    def test_non_conforming_server_fails_and_leaking_errors_are_caught(self) -> None:
        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Fake)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        results = {r.name: r for r in run_contract_check(f"http://127.0.0.1:{server.server_address[1]}", API_KEY, timeout=5)}
        self.assertTrue(results["GET /health"].ok)
        self.assertFalse(results["401 sans clé, avec WWW-Authenticate"].ok)
        self.assertFalse(results["GET /v1/models"].ok)
        self.assertFalse(results["POST /v1/chat/completions"].ok)
        leak = results["422 champ inconnu, sans recopier le contenu"]
        self.assertFalse(leak.ok)
        self.assertIn("recopie", leak.detail)
        self.assertNotIn(MARKER, leak.detail)

    def test_unreachable_server_and_bad_url(self) -> None:
        results = run_contract_check("http://127.0.0.1:1", API_KEY, timeout=1)
        self.assertTrue(all(not r.ok for r in results))
        with self.assertRaises(ValueError):
            run_contract_check("ftp://x", API_KEY)


if __name__ == "__main__":
    unittest.main()
