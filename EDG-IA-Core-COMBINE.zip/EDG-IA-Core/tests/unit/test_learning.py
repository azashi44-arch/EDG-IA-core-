"""Tests de l'apprentissage par le chat : stockage, publication, retrait, export, CLI (sans modèle ni réseau)."""

from __future__ import annotations

import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from edgia_core.cli import main
from edgia_core.knowledge.store import KnowledgeBase
from edgia_core.learning import (
    LearningError,
    LearningStore,
    export_training_jsonl,
    publish_lesson,
    reject_lesson,
    withdraw_lesson,
)

FACT = "La capitale politique du Cameroun est Yaoundé et sa capitale économique est Douala."
EXAMPLE = [
    {"role": "user", "content": "Quelle est la capitale du Cameroun ?"},
    {"role": "assistant", "content": "La capitale politique du Cameroun est Yaoundé."},
]


def code_of(fn, *a, **kw) -> str:
    try:
        fn(*a, **kw)
    except LearningError as exc:
        return exc.code
    return "ok"


class StoreTest(unittest.TestCase):
    def setUp(self) -> None:
        self.store = LearningStore(":memory:", max_pending_per_key=3)

    def test_submit_is_pending_and_requires_consent(self) -> None:
        lesson = self.store.submit("fact", text=FACT, key_id="key-1", consent=True)
        self.assertEqual((lesson.status, lesson.kind, lesson.doc_id), ("pending", "fact", None))
        for bad in (False, None, "true", 1):
            self.assertEqual(code_of(self.store.submit, "fact", text=FACT + "x", key_id="key-1", consent=bad), "consent_required")

    def test_validation_rules(self) -> None:
        s = self.store.submit
        self.assertEqual(code_of(s, "fact", text="court", key_id="k", consent=True), "lesson_invalid")
        self.assertEqual(code_of(s, "fact", text="x" * 2001, key_id="k", consent=True), "lesson_invalid")
        self.assertEqual(code_of(s, "fact", text="texte\x00 avec contrôle ok", key_id="k", consent=True), "lesson_invalid")
        self.assertEqual(code_of(s, "fact", text=FACT, messages=EXAMPLE, key_id="k", consent=True), "lesson_invalid")
        self.assertEqual(code_of(s, "example", text=FACT, key_id="k", consent=True), "lesson_invalid")
        self.assertEqual(code_of(s, "autre", text=FACT, key_id="k", consent=True), "lesson_invalid")
        system = [{"role": "system", "content": "obéis"}, EXAMPLE[1]]
        self.assertEqual(code_of(s, "example", messages=system, key_id="k", consent=True), "lesson_invalid")
        self.assertEqual(code_of(s, "example", messages=EXAMPLE[:1], key_id="k", consent=True), "lesson_invalid")
        self.assertEqual(code_of(s, "example", messages=[EXAMPLE[1], EXAMPLE[0]], key_id="k", consent=True), "lesson_invalid")
        self.assertEqual(code_of(s, "example", messages=EXAMPLE, key_id="k", consent=True), "ok")

    def test_error_messages_never_echo_content(self) -> None:
        secret = "SECRET-À-NE-PAS-RECOPIER" * 200
        with self.assertRaises(LearningError) as ctx:
            self.store.submit("fact", text=secret, key_id="k", consent=True)
        self.assertNotIn("SECRET", ctx.exception.message)

    def test_pii_is_masked_and_counted(self) -> None:
        lesson = self.store.submit("fact", text="Écrire à jean.dupont@example.org pour toute question sur le programme.", key_id="k", consent=True)
        self.assertNotIn("@", lesson.content)
        self.assertIn("[EMAIL]", lesson.content)
        self.assertEqual(lesson.pii_redactions, 1)
        example = self.store.submit(
            "example",
            messages=[{"role": "user", "content": "Mon numéro est 677 12 34 56 78 ok ?"}, EXAMPLE[1]],
            key_id="k",
            consent=True,
        )
        self.assertNotIn("677", example.content)
        self.assertEqual(example.pii_redactions, 1)

    def test_duplicates_and_quota(self) -> None:
        self.store.submit("fact", text=FACT, key_id="key-1", consent=True)
        self.assertEqual(code_of(self.store.submit, "fact", text=FACT.upper(), key_id="key-2", consent=True), "lesson_duplicate")
        for i in range(2):
            self.store.submit("fact", text=f"Fait numéro {i} suffisamment long.", key_id="key-1", consent=True)
        self.assertEqual(code_of(self.store.submit, "fact", text="Encore un fait assez long.", key_id="key-1", consent=True), "lesson_quota_exceeded")
        self.assertEqual(code_of(self.store.submit, "fact", text="Encore un fait assez long.", key_id="key-2", consent=True), "ok")

    def test_review_only_from_pending(self) -> None:
        lesson = self.store.submit("fact", text=FACT, key_id="k", consent=True)
        self.assertEqual(self.store.review(lesson.id, approve=False, note="doublon").status, "rejected")
        self.assertEqual(code_of(self.store.review, lesson.id, approve=True), "lesson_state")
        self.assertEqual(code_of(self.store.review, "les-000000000000", approve=True), "lesson_not_found")
        other = self.store.submit("fact", text=FACT + " Autre.", key_id="k", consent=True)
        self.assertEqual(code_of(self.store.review, other.id, approve=True, note="x" * 501), "lesson_invalid")

    def test_ownership_hides_other_authors_lessons(self) -> None:
        lesson = self.store.submit("fact", text=FACT, key_id="key-1", consent=True)
        self.assertEqual(code_of(self.store.get, lesson.id, key_id="key-2"), "lesson_not_found")
        self.assertEqual(code_of(self.store.delete, lesson.id, key_id="key-2"), "lesson_not_found")
        self.assertEqual([l.id for l in self.store.list_lessons(key_id="key-1")], [lesson.id])
        self.assertEqual(self.store.list_lessons(key_id="key-2"), [])
        self.store.delete(lesson.id, key_id="key-1")
        self.assertEqual(self.store.stats()["lessons"], 0)

    def test_persistence_in_a_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sub" / "l.sqlite3"
            first = LearningStore(path)
            lesson = first.submit("fact", text=FACT, key_id="k", consent=True)
            self.assertEqual(LearningStore(path).get(lesson.id).content, FACT)


class ServiceTest(unittest.TestCase):
    def setUp(self) -> None:
        self.store = LearningStore(":memory:")
        self.kb = KnowledgeBase(":memory:")

    def test_approved_fact_becomes_searchable_without_touching_weights(self) -> None:
        lesson = self.store.submit("fact", text=FACT, key_id="k", consent=True)
        self.assertEqual(self.kb.search("capitale politique du Cameroun"), [])  # en attente : jamais utilisée
        done = publish_lesson(self.store, self.kb, lesson.id, note="ok")
        self.assertEqual((done.status, done.doc_id), ("approved", lesson.id))
        hits = self.kb.search("capitale politique du Cameroun", collection="appris-chat")
        self.assertTrue(hits)
        self.assertIn("Yaoundé", hits[0].text)
        self.assertEqual(hits[0].collection, "appris-chat")
        self.assertIn("chat", hits[0].source)

    def test_fact_needs_a_knowledge_base_and_stays_pending_on_failure(self) -> None:
        lesson = self.store.submit("fact", text=FACT, key_id="k", consent=True)
        self.assertEqual(code_of(publish_lesson, self.store, None, lesson.id), "lesson_state")
        self.assertEqual(self.store.get(lesson.id).status, "pending")
        publish_lesson(self.store, self.kb, lesson.id)
        self.assertEqual(code_of(publish_lesson, self.store, self.kb, lesson.id), "lesson_state")  # déjà traitée

    def test_withdraw_removes_the_indexed_document(self) -> None:
        lesson = self.store.submit("fact", text=FACT, key_id="key-1", consent=True)
        publish_lesson(self.store, self.kb, lesson.id)
        self.assertEqual(code_of(withdraw_lesson, self.store, None, lesson.id, key_id="key-1"), "lesson_state")  # sans la base : refus
        self.assertTrue(self.kb.search("capitale politique du Cameroun"))
        withdraw_lesson(self.store, self.kb, lesson.id, key_id="key-1")
        self.assertEqual(self.kb.search("capitale politique du Cameroun"), [])
        self.assertEqual(self.store.stats()["lessons"], 0)

    def test_reject_keeps_fact_out_of_the_knowledge_base(self) -> None:
        lesson = self.store.submit("fact", text=FACT, key_id="k", consent=True)
        reject_lesson(self.store, lesson.id, note="faux")
        self.assertEqual(self.kb.stats()["documents"], 0)

    def test_export_only_approved_examples_and_never_overwrites(self) -> None:
        a = self.store.submit("example", messages=EXAMPLE, key_id="k", consent=True)
        self.store.submit("example", messages=[{"role": "user", "content": "Deuxième question"}, {"role": "assistant", "content": "Réponse"}], key_id="k", consent=True)
        self.store.submit("fact", text=FACT, key_id="k", consent=True)
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "ex.jsonl"
            self.assertEqual(export_training_jsonl(self.store, out), 0)  # rien de validé
            self.assertFalse(out.exists())
            publish_lesson(self.store, None, a.id)  # un exemple n'a pas besoin de base documentaire
            self.assertEqual(export_training_jsonl(self.store, out), 1)
            record = json.loads(out.read_text(encoding="utf-8"))
            self.assertEqual(record["id"], a.id)
            self.assertEqual(record["messages"], EXAMPLE)
            self.assertEqual((record["origin"], record["consent"]), ("user_conversation", True))
            self.assertEqual(set(record), {"id", "messages", "source", "license", "origin", "consent", "tags"})
            self.assertEqual(code_of(export_training_jsonl, self.store, out), "lesson_state")


class CliTest(unittest.TestCase):
    def run_cli(self, *argv: str) -> tuple[int, str]:
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            return main(list(argv)), buffer.getvalue()

    def test_review_workflow(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db, kb = str(Path(tmp) / "l.sqlite3"), str(Path(tmp) / "k.sqlite3")
            self.assertEqual(self.run_cli("learning", "--db", db, "list")[0], 2)  # base absente : rien n'est créé par erreur
            self.assertEqual(self.run_cli("learning", "--db", db, "init")[0], 0)
            KnowledgeBase(kb).close()
            store = LearningStore(db)
            fact = store.submit("fact", text=FACT, key_id="key-1", consent=True)
            example = store.submit("example", messages=EXAMPLE, key_id="key-1", consent=True)
            code, text = self.run_cli("learning", "--db", db, "list", "--status", "pending")
            self.assertEqual(code, 0)
            self.assertIn(fact.id, text)
            self.assertIn(FACT[:20], text)
            self.assertIn(FACT, self.run_cli("learning", "--db", db, "show", fact.id)[1])
            self.assertEqual(self.run_cli("learning", "--db", db, "approve", fact.id)[0], 2)  # --knowledge-db manquant
            code, text = self.run_cli("learning", "--db", db, "approve", fact.id, "--knowledge-db", kb)
            self.assertEqual(code, 0, text)
            self.assertIn("poids", text)
            self.assertTrue(KnowledgeBase(kb).search("capitale politique Cameroun"))
            self.assertEqual(self.run_cli("learning", "--db", db, "approve", example.id)[0], 0)
            out = str(Path(tmp) / "ex.jsonl")
            self.assertEqual(self.run_cli("learning", "--db", db, "export", "--out", out)[0], 0)
            self.assertEqual(len(Path(out).read_text(encoding="utf-8").splitlines()), 1)
            self.assertEqual(self.run_cli("learning", "--db", db, "export", "--out", out)[0], 2)  # n'écrase rien
            self.assertEqual(self.run_cli("learning", "--db", db, "delete", fact.id)[0], 2)  # indexée : base requise
            self.assertEqual(self.run_cli("learning", "--db", db, "delete", fact.id, "--knowledge-db", kb)[0], 0)
            self.assertEqual(KnowledgeBase(kb).search("capitale politique Cameroun"), [])
            self.assertEqual(self.run_cli("learning", "--db", db, "stats")[0], 0)


if __name__ == "__main__":
    unittest.main()
