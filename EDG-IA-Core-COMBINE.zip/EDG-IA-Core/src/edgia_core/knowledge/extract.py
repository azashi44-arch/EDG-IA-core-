"""Extraction de texte de documents : .txt, .md, .html, .docx (bibliothèque standard) et .pdf (pypdf, facultatif).

Chaque extracteur retourne une liste de blocs `(section, texte)`. Un document sans texte extractible est refusé : on
n'indexe jamais « rien » en laissant croire que le document est consultable (PDF scanné sans texte, par exemple).
"""

from __future__ import annotations

import io
import re
import zipfile
from html.parser import HTMLParser
from pathlib import Path
from xml.etree import ElementTree

from edgia_core.errors import ConfigurationError

SUPPORTED = (".txt", ".md", ".html", ".htm", ".docx", ".pdf")
MAX_FILE_BYTES = 20 * 1024 * 1024
MAX_DOCX_XML_BYTES = 30 * 1024 * 1024
_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _decode(raw: bytes) -> str:
    for encoding in ("utf-8-sig", "utf-16"):
        try:
            return raw.decode(encoding)
        except UnicodeError:
            continue
    return raw.decode("latin-1")  # dernier recours : ne lève jamais d'erreur ; les accents peuvent être faux


def _blocks_from_text(text: str, markdown: bool) -> list[tuple[str, str]]:
    blocks: list[tuple[str, str]] = []
    section = ""
    buffer: list[str] = []

    def flush() -> None:
        body = "\n".join(buffer).strip()
        if body:
            blocks.append((section, body))
        buffer.clear()

    for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        heading = re.match(r"^\s{0,3}#{1,6}\s+(.*\S)\s*#*\s*$", line) if markdown else None
        if heading:
            flush()
            section = heading.group(1).strip()
        else:
            buffer.append(line)
    flush()
    return blocks


class _HtmlText(HTMLParser):
    _SKIP = {"script", "style", "noscript", "template"}
    _BREAK = {"p", "div", "br", "li", "tr", "section", "article", "h1", "h2", "h3", "h4", "h5", "h6", "table"}
    _HEADINGS = {"h1", "h2", "h3"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.blocks: list[tuple[str, str]] = []
        self._section = ""
        self._buffer: list[str] = []
        self._skip = 0
        self._heading = False
        self._heading_text: list[str] = []

    def _flush(self) -> None:
        body = re.sub(r"[ \t]+", " ", "".join(self._buffer)).strip()
        if body:
            self.blocks.append((self._section, body))
        self._buffer = []

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag in self._SKIP:
            self._skip += 1
        elif tag in self._BREAK:
            self._flush()
            if tag in self._HEADINGS:
                self._heading, self._heading_text = True, []

    def handle_endtag(self, tag: str) -> None:
        if tag in self._SKIP:
            self._skip = max(0, self._skip - 1)
        elif tag in self._HEADINGS and self._heading:
            self._section = " ".join("".join(self._heading_text).split())
            self._heading = False
            self._buffer = []
        elif tag in self._BREAK:
            self._flush()

    def handle_data(self, data: str) -> None:
        if self._skip:
            return
        if self._heading:
            self._heading_text.append(data)
        else:
            self._buffer.append(data)

    def close(self) -> None:
        super().close()
        self._flush()


def _from_docx(raw: bytes) -> list[tuple[str, str]]:
    try:
        archive = zipfile.ZipFile(io.BytesIO(raw))
        info = archive.getinfo("word/document.xml")
    except (zipfile.BadZipFile, KeyError):
        raise ConfigurationError("Fichier .docx invalide (archive ou document.xml absent).") from None
    if info.file_size > MAX_DOCX_XML_BYTES:
        raise ConfigurationError("Fichier .docx refusé : contenu décompressé trop volumineux.")
    xml = archive.read(info)
    if b"<!DOCTYPE" in xml[:2048].upper() or b"<!ENTITY" in xml.upper():
        raise ConfigurationError("Fichier .docx refusé : déclaration DOCTYPE/ENTITY interdite.")
    try:
        root = ElementTree.fromstring(xml)
    except ElementTree.ParseError:
        raise ConfigurationError("Fichier .docx invalide (XML illisible).") from None
    blocks: list[tuple[str, str]] = []
    section = ""
    for paragraph in root.iter(f"{_W}p"):
        text = "".join(node.text or "" for node in paragraph.iter(f"{_W}t")).strip()
        if not text:
            continue
        style = paragraph.find(f"{_W}pPr/{_W}pStyle")
        style_name = (style.get(f"{_W}val") or "") if style is not None else ""
        if re.match(r"^(Heading|Titre)\s*\d", style_name, re.IGNORECASE):
            section = text
        else:
            blocks.append((section, text))
    return blocks


def _from_pdf(raw: bytes) -> list[tuple[str, str]]:
    try:
        from pypdf import PdfReader  # noqa: PLC0415
    except ImportError:
        raise ConfigurationError("Lecture des PDF indisponible : installez « pypdf » (non testé dans ce projet).") from None
    try:
        reader = PdfReader(io.BytesIO(raw))
        pages = [(f"page {i}", (page.extract_text() or "").strip()) for i, page in enumerate(reader.pages, start=1)]
    except Exception as exc:  # noqa: BLE001 - pypdf lève des erreurs variées sur des fichiers abîmés
        raise ConfigurationError(f"PDF illisible ({type(exc).__name__}).") from None
    return [(label, text) for label, text in pages if text]


def extract_blocks(filename: str, raw: bytes) -> list[tuple[str, str]]:
    if len(raw) > MAX_FILE_BYTES:
        raise ConfigurationError(f"Fichier trop volumineux (> {MAX_FILE_BYTES // (1024 * 1024)} Mo).")
    suffix = Path(filename).suffix.lower()
    if suffix not in SUPPORTED:
        raise ConfigurationError(f"Type de fichier non pris en charge : « {suffix or '(aucun)'} ». Types : {', '.join(SUPPORTED)}.")
    if suffix in (".txt", ".md"):
        blocks = _blocks_from_text(_decode(raw), markdown=suffix == ".md")
    elif suffix in (".html", ".htm"):
        parser = _HtmlText()
        parser.feed(_decode(raw))
        parser.close()
        blocks = parser.blocks
    elif suffix == ".docx":
        blocks = _from_docx(raw)
    else:
        blocks = _from_pdf(raw)
    if not blocks:
        raise ConfigurationError("Aucun texte extractible dans ce document (document vide, scanné ou protégé).")
    return blocks
