# Mathématiques : nombres, calcul et algèbre

## Priorités opératoires

Dans une expression, traiter les parenthèses, les puissances, les multiplications et divisions, puis les additions et soustractions. À priorité égale, calculer de gauche à droite. Une fraction a/b est définie lorsque b est non nul.

## Propriétés

La commutativité vaut pour l'addition et la multiplication : a+b=b+a et ab=ba. L'associativité vaut aussi pour ces deux opérations. La distributivité donne a(b+c)=ab+ac. Elle permet notamment de développer et de factoriser des expressions.

## Équation du premier degré

Pour résoudre ax+b=c avec a différent de zéro, isoler x : x=(c-b)/a. Toute transformation doit préserver l'égalité, par exemple en ajoutant ou soustrayant la même quantité aux deux membres, ou en multipliant/divisant les deux membres par un nombre non nul.

## Pourcentages et proportions

p pour cent signifie p/100. Une augmentation de p % multiplie une valeur initiale par 1+p/100. Une diminution de p % la multiplie par 1-p/100. Pour une proportion a/b=c/d, avec les dénominateurs non nuls, le produit en croix donne ad=bc.

## Géométrie plane

Le périmètre d'un rectangle de côtés L et l vaut 2(L+l), et son aire vaut L×l. L'aire d'un triangle vaut base×hauteur/2. L'aire d'un disque de rayon r vaut πr² et sa circonférence vaut 2πr. Le théorème de Pythagore s'applique aux triangles rectangles : le carré de l'hypoténuse égale la somme des carrés des deux autres côtés.

## Vérification

Contrôler les unités, l'ordre de grandeur, les signes et le résultat par substitution ou par une méthode indépendante. Un calcul complexe doit être effectué avec un outil fiable plutôt que deviné.
