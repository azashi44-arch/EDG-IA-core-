# Biologie : notions fondamentales

La cellule est l'unité de base du vivant. Les cellules peuvent être procaryotes ou eucaryotes. Les cellules eucaryotes possèdent un noyau ; les procaryotes n'ont pas de noyau délimité par une membrane. Les organismes peuvent être unicellulaires ou pluricellulaires.

L'ADN porte une information génétique organisée en séquences de nucléotides. Un gène est une région d'ADN contribuant à un produit fonctionnel, souvent un ARN ou une protéine. L'expression génétique comprend notamment la transcription de l'ADN en ARN et, pour les ARN messagers, la traduction en protéines.

La photosynthèse permet à certains organismes de convertir l'énergie lumineuse en énergie chimique. Dans sa forme simplifiée chez les plantes, elle utilise du dioxyde de carbone et de l'eau pour produire des composés organiques et libérer du dioxygène, avec l'énergie lumineuse.

La respiration cellulaire extrait de l'énergie utilisable à partir de molécules organiques. Les écosystèmes comprennent des organismes et leur environnement ; les flux d'énergie et les cycles de matière relient les êtres vivants.

Les êtres vivants présentent une diversité et évoluent au fil des générations. La sélection naturelle est un mécanisme évolutif qui agit lorsque des variations héréditaires influencent la survie ou la reproduction dans un environnement donné. Les explications biologiques doivent distinguer les mécanismes établis, les modèles et les hypothèses encore étudiées.
