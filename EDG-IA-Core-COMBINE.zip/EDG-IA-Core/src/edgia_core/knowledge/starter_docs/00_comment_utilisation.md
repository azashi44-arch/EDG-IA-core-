# Comment utiliser une base de connaissances

Une base documentaire conserve des informations consultables sans modifier les poids du modèle neuronal. Le moteur recherche des passages pertinents, les transmet au modèle comme contexte et peut retourner les références des documents utilisés. Cette méthode est souvent appelée génération augmentée par récupération (RAG).

## Cycle de consultation

1. Identifier la question réelle de l'utilisateur.
2. Rechercher des passages dans les collections pertinentes.
3. Vérifier que les extraits répondent réellement à la question.
4. Répondre en distinguant les faits sourcés, les déductions et les incertitudes.
5. Citer les références fournies par le moteur. Si aucun extrait ne répond, le dire et ne pas inventer une source.

## Trois opérations différentes

- Consultation : récupérer des passages au moment d'une conversation. Aucun poids ne change.
- Préparation d'apprentissage : transformer des documents autorisés en exemples, puis les faire vérifier, nettoyer et dédupliquer.
- Entraînement : mettre à jour les poids du modèle avec un pipeline d'entraînement contrôlé, une validation et une version sauvegardée.

Un document ajouté à la bibliothèque n'est donc pas automatiquement appris par les poids. Cette séparation protège la qualité, la provenance et la stabilité du modèle.

## Fiabilité

Les documents peuvent être incomplets, anciens ou erronés. Vérifier la date, l'auteur, la méthode et les sources. Pour les sujets sensibles ou à conséquences importantes, ne pas traiter un extrait isolé comme une preuve suffisante.
