# Développement Web : HTML, CSS, JavaScript et API

## HTML

HTML décrit la structure et le sens du contenu d'une page. Utiliser des éléments sémantiques comme header, nav, main, section, article, form et footer. Associer les champs de formulaire à des labels. Le HTML ne remplace pas la validation côté serveur.

## CSS

CSS contrôle la présentation. Le modèle de boîte comprend contenu, padding, bordure et marge. Flexbox convient aux mises en page unidimensionnelles ; CSS Grid convient aux grilles bidimensionnelles. Les unités relatives, les points de rupture et les requêtes média aident à construire des interfaces adaptatives.

## JavaScript

JavaScript gère le comportement interactif. const déclare une liaison qui ne sera pas réassignée, let une liaison réassignable. Les fonctions peuvent être asynchrones avec async/await. Les promesses représentent des opérations qui se terminent plus tard. Il faut gérer les erreurs avec try/catch.

## API et HTTP

Une API REST utilise souvent des ressources et des méthodes HTTP : GET pour lire, POST pour créer ou déclencher une action, PUT/PATCH pour modifier, DELETE pour supprimer. Les codes 2xx indiquent généralement un succès, 4xx une erreur liée à la requête et 5xx une erreur serveur. Le serveur doit authentifier, autoriser, valider et limiter les requêtes.

## Sécurité Web

Échapper ou encoder les données selon leur contexte, éviter l'injection SQL avec des requêtes paramétrées, protéger les sessions et les cookies, configurer CORS de façon restrictive et ne pas faire confiance aux validations uniquement côté navigateur. Ne jamais placer de secret serveur dans du JavaScript livré au navigateur.
