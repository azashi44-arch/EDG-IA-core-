# Anglais : fondamentaux

## Ordre de base

Une phrase anglaise simple suit souvent l'ordre sujet + verbe + complément : “The student reads a book.” L'adjectif précède généralement le nom : “a useful tool”.

## Verbe be

Au présent, les formes principales sont I am, you are, he/she/it is, we are, they are. La négation se construit généralement avec not : “She is not ready.” La question place souvent le verbe avant le sujet : “Are they ready?”

## Présent simple et présent continu

Le present simple décrit notamment les habitudes, les faits généraux et les états : “Water boils at about 100°C at standard atmospheric pressure.” À la troisième personne du singulier, le verbe prend généralement -s ou -es. Le present continuous utilise be + verbe en -ing pour une action en cours ou une situation temporaire : “I am studying.”

## Articles et pluriels

A s'emploie devant un son consonantique et an devant un son vocalique. The désigne un élément identifié ou spécifique. Beaucoup de noms forment leur pluriel avec -s ou -es, mais il existe des pluriels irréguliers comme child/children et man/men.

## Apprentissage

Apprendre une langue exige de pratiquer l'écoute, la lecture, l'expression orale et l'écriture. Une traduction dépend du contexte : un mot anglais peut avoir plusieurs équivalents français. Demander ou examiner la phrase complète est souvent nécessaire.
