# Langue française : bases

## Phrase et fonctions

Une phrase déclarative exprime généralement une information et se termine par un point. Une phrase interrogative pose une question. Une phrase impérative exprime un ordre, un conseil ou une demande. Une phrase exclamative exprime une émotion ou une intensité.

Le sujet indique de qui ou de quoi l'on parle. Le verbe exprime une action, un état ou un événement. Le complément peut préciser le verbe, le nom ou la phrase. L'adjectif qualificatif apporte une caractéristique au nom et s'accorde généralement en genre et en nombre avec lui.

## Classes grammaticales

Les principales classes variables sont le nom, le déterminant, l'adjectif, le pronom et le verbe. Les classes généralement invariables comprennent l'adverbe, la préposition, la conjonction et l'interjection.

## Accords

Le verbe s'accorde en personne et en nombre avec son sujet. Dans le groupe nominal, le déterminant et l'adjectif s'accordent généralement avec le nom. Le participe passé employé avec être s'accorde en général avec le sujet. Avec avoir, il s'accorde avec le complément d'objet direct seulement si celui-ci est placé avant le verbe, selon les règles usuelles.

## Temps et modes

L'indicatif présente un fait comme réel ou situé dans le temps. Le subjonctif exprime notamment le souhait, le doute ou la nécessité dans certains contextes. Le conditionnel peut exprimer une hypothèse, une demande atténuée ou le futur dans le passé. L'impératif sert notamment à donner une consigne.

## Méthode de rédaction

Définir l'objectif, organiser les idées, construire des paragraphes cohérents, utiliser des connecteurs logiques, puis relire l'orthographe, les accords, la ponctuation et la clarté. Ne pas confondre une règle générale avec toutes ses exceptions.
