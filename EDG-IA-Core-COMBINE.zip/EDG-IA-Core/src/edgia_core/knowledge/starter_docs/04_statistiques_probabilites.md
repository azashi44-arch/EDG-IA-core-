# Statistiques et probabilités : notions essentielles

## Statistiques descriptives

Une population est l'ensemble étudié. Un échantillon est une partie de cette population. La moyenne arithmétique est la somme des valeurs divisée par leur nombre. La médiane partage une série ordonnée en deux parties de même effectif, avec une convention adaptée lorsque l'effectif est pair. Le mode est la valeur la plus fréquente. L'étendue est le maximum moins le minimum.

La moyenne est sensible aux valeurs extrêmes. La médiane est souvent plus robuste pour décrire une distribution asymétrique. Une corrélation décrit une association statistique ; elle ne démontre pas à elle seule une relation de cause à effet.

## Probabilités

Pour des issues équiprobables, la probabilité d'un événement est le nombre d'issues favorables divisé par le nombre total d'issues. Une probabilité est comprise entre 0 et 1. L'événement contraire a une probabilité égale à 1-P(A).

Pour deux événements incompatibles, P(A ou B)=P(A)+P(B). En général, P(A ou B)=P(A)+P(B)-P(A et B). La probabilité conditionnelle P(A sachant B)=P(A et B)/P(B), lorsque P(B)>0.

L'indépendance de A et B signifie P(A et B)=P(A)P(B). Elle ne doit pas être supposée sans justification.
