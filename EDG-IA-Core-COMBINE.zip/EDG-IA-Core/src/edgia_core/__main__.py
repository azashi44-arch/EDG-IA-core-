from edgia_core.cli import main

raise SystemExit(main())
