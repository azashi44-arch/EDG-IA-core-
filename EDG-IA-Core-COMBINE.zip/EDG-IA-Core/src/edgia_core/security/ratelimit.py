"""Limitation de débit à fenêtre glissante, en mémoire, par identité.

Limite : l'état est local au processus. Avec plusieurs instances du service, chaque instance applique
sa propre limite ; une limite globale relève de la passerelle placée devant le service.
"""

from __future__ import annotations

import threading
import time
from collections import OrderedDict, deque
from collections.abc import Callable
from dataclasses import dataclass


@dataclass(frozen=True)
class RateDecision:
    allowed: bool
    retry_after: float  # secondes avant la prochaine tentative possible (0 si autorisé)


class SlidingWindowRateLimiter:
    def __init__(
        self,
        limit: int,
        window_seconds: float = 60.0,
        *,
        clock: Callable[[], float] = time.monotonic,
        max_identities: int = 10_000,
    ) -> None:
        if limit < 1 or window_seconds <= 0 or max_identities < 1:
            raise ValueError("limit >= 1, window_seconds > 0 et max_identities >= 1 sont requis")
        self._limit = limit
        self._window = window_seconds
        self._clock = clock
        self._max_identities = max_identities
        self._events: OrderedDict[str, deque[float]] = OrderedDict()
        self._lock = threading.Lock()

    def _prune(self, events: deque[float], now: float) -> None:
        horizon = now - self._window
        while events and events[0] <= horizon:
            events.popleft()

    def _decision(self, events: deque[float] | None, now: float) -> RateDecision:
        if events is None or len(events) < self._limit:
            return RateDecision(True, 0.0)
        return RateDecision(False, max(0.0, events[0] + self._window - now))

    def peek(self, identity: str) -> RateDecision:
        """Indique si l'identité est actuellement bloquée, sans rien enregistrer."""
        with self._lock:
            now = self._clock()
            events = self._events.get(identity)
            if events is not None:
                self._prune(events, now)
            return self._decision(events, now)

    def hit(self, identity: str) -> RateDecision:
        """Enregistre un événement s'il reste de la place ; sinon refuse sans l'enregistrer."""
        with self._lock:
            now = self._clock()
            events = self._events.get(identity)
            if events is None:
                events = deque()
                self._events[identity] = events
            self._events.move_to_end(identity)
            self._prune(events, now)
            decision = self._decision(events, now)
            if decision.allowed:
                events.append(now)
            while len(self._events) > self._max_identities:
                self._events.popitem(last=False)
            return decision
