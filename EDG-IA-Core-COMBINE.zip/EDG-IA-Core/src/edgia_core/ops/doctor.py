"""Diagnostic de l'environnement avant (ou après) un déploiement : `edgia-core doctor`.

Ne charge aucun modèle, ne télécharge rien, n'ouvre aucun port d'écoute durable. Chaque contrôle donne un statut :
`ok`, `warn` (à lire) ou `fail` (le service ne devrait pas être lancé ainsi). Les mesures de mémoire et d'espace disque
sont celles de la machine où la commande tourne : lancez-la sur la machine de production.
"""

from __future__ import annotations

import importlib.metadata
import importlib.util
import os
import shutil
import socket
import sys
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path

from edgia_core.config import Mode, Settings, build_serving_report, load_settings
from edgia_core.errors import ConfigurationError

OK, WARN, FAIL = "ok", "warn", "fail"
CORE_PACKAGES = ("pydantic", "PyYAML", "starlette", "uvicorn")
ML_PACKAGES = ("torch", "transformers", "peft", "safetensors")
MIN_FREE_DISK_GB = 2.0


@dataclass(frozen=True)
class Check:
    name: str
    status: str
    detail: str


def _real_memory_gb() -> float | None:
    try:
        with open("/proc/meminfo", encoding="ascii") as handle:
            for line in handle:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) / (1024 * 1024)
    except (OSError, ValueError, IndexError):
        pass
    return None


def _port_is_free(host: str, port: int) -> bool:
    try:
        with socket.socket(socket.AF_INET6 if ":" in host else socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind((host, port))
        return True
    except OSError:
        return False


def _version(package: str) -> str | None:
    try:
        return importlib.metadata.version(package)
    except importlib.metadata.PackageNotFoundError:
        return None


def _cuda_summary() -> str | None:
    """Résumé CUDA seulement si PyTorch est importable ; None sinon."""
    if importlib.util.find_spec("torch") is None:
        return None
    try:
        import torch  # noqa: PLC0415

        if not torch.cuda.is_available():
            return "aucun GPU CUDA détecté"
        return "; ".join(
            f"GPU {i}: {torch.cuda.get_device_name(i)} ({torch.cuda.get_device_properties(i).total_memory / 1e9:.0f} Go)"
            for i in range(torch.cuda.device_count())
        )
    except Exception as exc:  # noqa: BLE001 - diagnostic : on rapporte, on ne plante pas
        return f"PyTorch présent mais CUDA illisible ({type(exc).__name__})"


@dataclass
class Probes:
    """Mesures de la machine ; remplaçables dans les tests."""

    memory_gb: Callable[[], float | None] = _real_memory_gb
    free_disk_gb: Callable[[Path], float | None] = lambda p: _free_gb(p)
    port_is_free: Callable[[str, int], bool] = _port_is_free
    version: Callable[[str], str | None] = _version
    cuda_summary: Callable[[], str | None] = _cuda_summary
    cpu_count: Callable[[], int | None] = os.cpu_count
    python_version: tuple[int, int, int] = field(default_factory=lambda: sys.version_info[:3])


def _free_gb(path: Path) -> float | None:
    target = path
    while not target.exists() and target != target.parent:
        target = target.parent
    try:
        return shutil.disk_usage(target).free / 1e9
    except OSError:
        return None


def _weights_gb(settings: Settings, report) -> float | None:
    descriptor = report.descriptor
    if descriptor is None or not descriptor.weights_path.exists():
        return None
    path = descriptor.weights_path
    files = [path] if path.is_file() else list(path.glob("*.safetensors"))
    return sum(f.stat().st_size for f in files) / 1e9 if files else None


def run_doctor(
    env: Mapping[str, str] | None = None, env_file: Path | None = None, probes: Probes | None = None
) -> list[Check]:
    probes = probes or Probes()
    checks: list[Check] = []
    add = lambda name, status, detail: checks.append(Check(name, status, detail))  # noqa: E731

    major, minor, micro = probes.python_version
    add("Python", OK if (major, minor) >= (3, 11) else FAIL, f"{major}.{minor}.{micro} (3.11 ou plus requis ; seule la 3.13 a été testée)")
    missing = []
    for package in CORE_PACKAGES:
        version = probes.version(package)
        if version is None:
            missing.append(package)
    add("Dépendances de base", FAIL if missing else OK, f"absentes : {', '.join(missing)}" if missing else ", ".join(f"{p} {probes.version(p)}" for p in CORE_PACKAGES))

    try:
        settings = load_settings(env=env, env_file=env_file)
    except ConfigurationError as exc:
        add("Configuration", FAIL, " ; ".join(exc.problems))
        return checks
    add("Configuration", OK, f"mode {settings.mode.value}, écoute {settings.host}:{settings.port}")

    report = build_serving_report(settings)
    for problem in report.problems:
        add("Démarrage", FAIL, problem)
    if report.ok:
        add("Démarrage", OK, "la configuration autorise le démarrage")

    real = settings.mode is Mode.REAL
    if not real:
        add("Mode", WARN, "démonstration : le modèle servi n'est PAS le modèle entraîné")

    ml_missing = [p for p in ML_PACKAGES if probes.version(p) is None]
    if ml_missing:
        add("Bibliothèques d'IA", FAIL if real else OK, ("absentes : " + ", ".join(ml_missing)) + (" (obligatoires en mode réel)" if real else " (inutiles en mode démonstration)"))
    else:
        add("Bibliothèques d'IA", OK, ", ".join(f"{p} {probes.version(p)}" for p in ML_PACKAGES) + " (jamais validées avec un vrai modèle dans ce projet)")
    cuda = probes.cuda_summary() if not ml_missing or probes.version("torch") else None
    if cuda:
        add("GPU", OK if "GPU" in cuda and "aucun" not in cuda else WARN, cuda)

    ram = probes.memory_gb()
    cpus = probes.cpu_count()
    add("Machine", OK if ram else WARN, f"{ram:.1f} Go de mémoire, {cpus} cœur(s)" if ram else f"mémoire illisible, {cpus} cœur(s)")
    weights = _weights_gb(settings, report)
    if real and weights is not None and ram:
        needed = weights * 1.2
        if cuda and "aucun" not in cuda and "GPU" in cuda:
            add("Taille du modèle", OK, f"poids {weights:.1f} Go ; vérifiez qu'ils tiennent dans la mémoire GPU ({cuda}) avec la marge du cache")
        elif needed > ram:
            add("Taille du modèle", FAIL, f"poids {weights:.1f} Go (≈ {needed:.1f} Go avec marge) pour {ram:.1f} Go de mémoire et aucun GPU détecté")
        else:
            add("Taille du modèle", WARN, f"poids {weights:.1f} Go sur CPU : possible mais lent (estimation grossière, à mesurer)")

    for label, path in (
        ("Disque (dossier courant)", Path.cwd()),
        ("Disque (registre)", settings.registry_path),
        ("Disque (base documentaire)", settings.knowledge_db),
        ("Disque (leçons apprises)", settings.learning_db),
        ("Disque (poids)", report.descriptor.weights_path if report.descriptor else None),
    ):
        if path is None:
            continue
        free = probes.free_disk_gb(Path(path))
        if free is None:
            add(label, WARN, "espace libre illisible")
        else:
            add(label, OK if free >= MIN_FREE_DISK_GB else WARN, f"{free:.1f} Go libres" + ("" if free >= MIN_FREE_DISK_GB else f" (moins de {MIN_FREE_DISK_GB:g} Go)"))

    if probes.port_is_free(settings.host, settings.port):
        add("Port", OK, f"{settings.host}:{settings.port} libre")
    else:
        add("Port", WARN, f"{settings.host}:{settings.port} occupé ou inaccessible (service déjà lancé ?)")

    if settings.host not in ("127.0.0.1", "localhost", "::1"):
        add("Exposition", WARN, "le serveur écoute hors de la machine : placez-le derrière un proxy TLS (voir docs/DEPLOIEMENT.md)")
    if not settings.auth_enabled:
        add("Authentification", WARN, "désactivée (autorisé seulement en boucle locale)")
    if not settings.rate_limit_enabled:
        add("Limite de débit", WARN, "désactivée")
    if "*" in settings.allowed_origins:
        add("CORS", WARN, "origine « * » autorisée : à éviter en production")
    if not settings.log_redact_content:
        add("Journaux", WARN, "le contenu des messages peut apparaître dans les journaux (EDGIA_LOG_REDACT_CONTENT=false)")
    if env_file is not None and env_file.exists() and env_file.stat().st_mode & 0o004:
        add("Fichier .env", WARN, "lisible par tous les utilisateurs de la machine : restreignez les droits (chmod 600)")
    return checks


def exit_code(checks: list[Check]) -> int:
    return 2 if any(c.status == FAIL for c in checks) else 0
