"""Exécute une suite d'évaluation contre un moteur d'inférence et produit un résultat JSON-compatible.

Génération déterministe (température 0). Les mesures de performance sont celles du processus d'évaluation :
latence, débit, mémoire résidente maximale ; mémoire GPU maximale uniquement si PyTorch est déjà chargé.
Aucune de ces mesures ne dit si le modèle répond bien : seules les vérifications de la suite le font, et seulement
pour les erreurs évidentes (voir docs/EVALUATION.md).
"""

from __future__ import annotations

import platform
import sys
import time
from collections import defaultdict
from collections.abc import Callable
from datetime import datetime, timezone

from edgia_core import __version__
from edgia_core.evaluation.checks import FAIL, PASS, SKIPPED, CheckResult, run_check
from edgia_core.evaluation.sandbox import SandboxLimits, run_code_tests
from edgia_core.evaluation.schema import CaseSpec, Suite
from edgia_core.inference.base import EngineError, GenerationParams, InferenceEngine, Message

try:
    import resource
except ImportError:  # pragma: no cover - Windows
    resource = None  # type: ignore[assignment]

RESULT_FORMAT = 1
MAX_STORED_OUTPUT_CHARS = 20_000

# Statuts d'un cas
CASE_PASS = "pass"
CASE_FAIL = "fail"
CASE_PARTIAL = "partial"  # des vérifications réussies, d'autres non exécutées (ex. code sans bac à sable)
CASE_SKIPPED = "skipped"  # aucune vérification exécutable
CASE_REVIEW = "review"  # aucune vérification automatique : relecture humaine
CASE_ERROR = "error"  # le moteur a échoué


def peak_rss_mb() -> float | None:
    """Mémoire résidente maximale du processus depuis son démarrage (Mo), None si indisponible."""
    if resource is None:
        return None
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return round(value / (1024 * 1024) if sys.platform == "darwin" else value / 1024, 1)


def _gpu_module():
    torch = sys.modules.get("torch")  # jamais importé ici : on ne mesure que si le moteur l'a déjà chargé
    try:
        if torch is not None and torch.cuda.is_available():
            return torch
    except Exception:  # noqa: BLE001
        pass
    return None


def case_status(results: list[CheckResult]) -> str:
    if not results:
        return CASE_REVIEW
    statuses = {r.status for r in results}
    if FAIL in statuses:
        return CASE_FAIL
    if statuses == {PASS}:
        return CASE_PASS
    if statuses == {SKIPPED}:
        return CASE_SKIPPED
    return CASE_PARTIAL


def _evaluate(case: CaseSpec, output: str, allow_code: bool, limits: SandboxLimits | None) -> list[CheckResult]:
    results = []
    for spec in case.checks:
        if spec.kind == "code_tests":
            if allow_code:
                results.append(run_code_tests(spec, output, limits))
            else:
                results.append(CheckResult("code_tests", SKIPPED, "exécution de code désactivée (--allow-code-execution)"))
        else:
            results.append(run_check(spec, output))
    return results


def run_suite(
    engine: InferenceEngine,
    suite: Suite,
    *,
    allow_code: bool = False,
    limit: int | None = None,
    sandbox_limits: SandboxLimits | None = None,
    progress: Callable[[int, int, str], None] | None = None,
) -> dict:
    cases = list(suite.cases[:limit] if limit else suite.cases)
    gpu = _gpu_module()
    if gpu is not None:
        gpu.cuda.reset_peak_memory_stats()
    rss_before = peak_rss_mb()
    started_at = datetime.now(timezone.utc)
    started = time.monotonic()

    records = []
    for index, case in enumerate(cases, start=1):
        if progress:
            progress(index, len(cases), case.id)
        messages = [Message(turn.role, turn.content) for turn in case.messages]
        params = GenerationParams(max_tokens=case.max_tokens, temperature=0.0, top_p=1.0)
        record: dict = {"id": case.id, "category": case.category, "note": case.note, "checks": []}
        t0 = time.monotonic()
        try:
            result = engine.generate(messages, params)
        except EngineError as exc:
            record.update(status=CASE_ERROR, error=str(exc), output="", latency_s=round(time.monotonic() - t0, 3))
            records.append(record)
            continue
        except Exception as exc:  # noqa: BLE001 - une erreur inattendue d'un moteur ne doit pas perdre tout le rapport
            record.update(
                status=CASE_ERROR, error=f"erreur inattendue : {type(exc).__name__}", output="",
                latency_s=round(time.monotonic() - t0, 3),
            )
            records.append(record)
            continue
        latency = time.monotonic() - t0
        checks = _evaluate(case, result.text, allow_code, sandbox_limits)
        record.update(
            status=case_status(checks),
            output=result.text[:MAX_STORED_OUTPUT_CHARS],
            output_truncated=len(result.text) > MAX_STORED_OUTPUT_CHARS,
            finish_reason=result.finish_reason,
            prompt_tokens=result.prompt_tokens,
            completion_tokens=result.completion_tokens,
            latency_s=round(latency, 3),
            tokens_per_s=round(result.completion_tokens / latency, 2) if latency > 0 and result.completion_tokens else None,
            checks=[{"kind": c.kind, "status": c.status, "detail": c.detail} for c in checks],
        )
        records.append(record)

    info = engine.info
    performance = {
        "wall_time_s": round(time.monotonic() - started, 2),
        "peak_rss_mb_before": rss_before,
        "peak_rss_mb_after": peak_rss_mb(),
        "gpu_peak_allocated_mb": round(gpu.cuda.max_memory_allocated() / (1024 * 1024), 1) if gpu is not None else None,
        "note": "Mémoire du processus d'évaluation ; GPU mesuré seulement si PyTorch était déjà chargé.",
    }
    latencies = sorted(r["latency_s"] for r in records if r["status"] != CASE_ERROR)
    if latencies:
        performance["latency_median_s"] = latencies[len(latencies) // 2]
        performance["latency_max_s"] = latencies[-1]
    rates = [r["tokens_per_s"] for r in records if r.get("tokens_per_s")]
    if rates:
        performance["tokens_per_s_median"] = sorted(rates)[len(rates) // 2]

    return {
        "format": RESULT_FORMAT,
        "generated_at": started_at.isoformat(timespec="seconds"),
        "edgia_core_version": __version__,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "engine": {
            "id": info.id,
            "version": info.version,
            "runtime": info.runtime,
            "is_demo": info.is_demo,
            "description": info.description,
        },
        "suite": {"name": suite.name, "sha256": suite.sha256, "cases_total": len(suite.cases), "cases_run": len(cases)},
        "settings": {"temperature": 0.0, "allow_code_execution": allow_code, "limit": limit},
        "performance": performance,
        "summary": summarize(records),
        "cases": records,
    }


def summarize(records: list[dict]) -> dict:
    """Comptes par statut, global et par catégorie. Le taux de réussite ne porte que sur les cas vérifiés
    automatiquement (pass + fail + error) : review, skipped et partial n'y entrent pas."""

    def block(items: list[dict]) -> dict:
        counts: dict[str, int] = defaultdict(int)
        for item in items:
            counts[item["status"]] += 1
        scored = counts[CASE_PASS] + counts[CASE_FAIL] + counts[CASE_ERROR]
        return {
            "counts": {k: counts.get(k, 0) for k in (CASE_PASS, CASE_FAIL, CASE_PARTIAL, CASE_SKIPPED, CASE_REVIEW, CASE_ERROR)},
            "scored": scored,
            "pass_rate": round(counts[CASE_PASS] / scored, 4) if scored else None,
        }

    by_category: dict[str, list[dict]] = defaultdict(list)
    for record in records:
        by_category[record["category"]].append(record)
    return {"overall": block(records), "by_category": {name: block(items) for name, items in sorted(by_category.items())}}
