"""Évaluation de la qualité, des performances et de la sécurité. Phase 5 : suites de cas, vérifications, exécuteur, rapports, comparaison."""
