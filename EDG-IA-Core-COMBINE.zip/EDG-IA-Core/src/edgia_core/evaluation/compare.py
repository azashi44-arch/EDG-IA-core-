"""Comparaison de deux résultats d'évaluation (ex. modèle de base contre modèle adapté, ou deux candidats).

Règle stricte : les deux résultats doivent venir de la MÊME suite (même sha256), sinon la comparaison est refusée.
Le test de McNemar exact est indicatif : avec des dizaines de cas, seule une différence très nette est détectable.
"""

from __future__ import annotations

from math import comb

from edgia_core.errors import ConfigurationError

_SCORED = ("pass", "fail", "error")


def mcnemar_exact_p(only_a: int, only_b: int) -> float:
    """p-valeur bilatérale exacte (binomiale 1/2) sur les cas discordants."""
    n = only_a + only_b
    if n == 0:
        return 1.0
    k = min(only_a, only_b)
    return min(1.0, 2 * sum(comb(n, i) for i in range(k + 1)) / 2**n)


def compare_results(a: dict, b: dict) -> dict:
    for name, side in (("A", a), ("B", b)):
        if side.get("format") != 1 or "cases" not in side:
            raise ConfigurationError(f"Le résultat {name} n'a pas le format attendu.")
    if a["suite"]["sha256"] != b["suite"]["sha256"]:
        raise ConfigurationError(
            "Comparaison refusée : les deux résultats viennent de suites différentes (somme SHA-256 différente). "
            "Relancez les deux évaluations avec la même suite."
        )
    cases_a = {c["id"]: c for c in a["cases"]}
    cases_b = {c["id"]: c for c in b["cases"]}
    common = [cid for cid in cases_a if cid in cases_b and cases_a[cid]["status"] in _SCORED and cases_b[cid]["status"] in _SCORED]
    only_a_pass = [cid for cid in common if cases_a[cid]["status"] == "pass" and cases_b[cid]["status"] != "pass"]
    only_b_pass = [cid for cid in common if cases_b[cid]["status"] == "pass" and cases_a[cid]["status"] != "pass"]

    categories: dict[str, dict] = {}
    for cid in common:
        cat = cases_a[cid]["category"]
        entry = categories.setdefault(cat, {"cases": 0, "a_pass": 0, "b_pass": 0})
        entry["cases"] += 1
        entry["a_pass"] += cases_a[cid]["status"] == "pass"
        entry["b_pass"] += cases_b[cid]["status"] == "pass"
    for entry in categories.values():
        entry["delta"] = entry["b_pass"] - entry["a_pass"]

    total = len(common)
    a_pass = sum(cases_a[c]["status"] == "pass" for c in common)
    b_pass = sum(cases_b[c]["status"] == "pass" for c in common)
    return {
        "a": {"engine": a["engine"], "generated_at": a["generated_at"]},
        "b": {"engine": b["engine"], "generated_at": b["generated_at"]},
        "suite": a["suite"],
        "any_demo": bool(a["engine"]["is_demo"] or b["engine"]["is_demo"]),
        "compared_cases": total,
        "not_compared": len(set(cases_a) | set(cases_b)) - total,
        "a_pass": a_pass,
        "b_pass": b_pass,
        "better_in_a": sorted(only_a_pass),
        "better_in_b": sorted(only_b_pass),
        "mcnemar_exact_p": round(mcnemar_exact_p(len(only_a_pass), len(only_b_pass)), 4),
        "by_category": dict(sorted(categories.items())),
        "performance": {"a": a["performance"], "b": b["performance"]},
    }


def render_comparison_markdown(comparison: dict) -> str:
    a, b = comparison["a"]["engine"], comparison["b"]["engine"]
    out = ["# Comparaison de deux évaluations EDG-IA", ""]
    if comparison["any_demo"]:
        out += ["> **Au moins un des deux résultats vient du modèle de démonstration : cette comparaison n'a AUCUNE signification.**", ""]
    out += [
        f"- **A** : {a['id']} {a['version']}",
        f"- **B** : {b['id']} {b['version']}",
        f"- Suite : {comparison['suite']['name']} (sha256 {comparison['suite']['sha256'][:16]}…), "
        f"{comparison['compared_cases']} cas comparés ({comparison['not_compared']} écartés : relecture, non exécutés ou absents d'un côté)",
        f"- Réussis : A {comparison['a_pass']} / B {comparison['b_pass']} sur {comparison['compared_cases']}",
        f"- Test de McNemar exact (indicatif) : p = {comparison['mcnemar_exact_p']} "
        f"({len(comparison['better_in_a'])} cas mieux réussis par A seul, {len(comparison['better_in_b'])} par B seul)",
        "",
        "> Avec un petit nombre de cas, une différence de quelques réponses peut relever du hasard : ne décidez pas sur ce seul chiffre. "
        "Relisez les cas qui diffèrent et complétez par une évaluation humaine.",
        "",
        "| Catégorie | Cas | A réussis | B réussis | Écart (B − A) |",
        "|---|---|---|---|---|",
    ]
    for name, e in comparison["by_category"].items():
        out.append(f"| {name} | {e['cases']} | {e['a_pass']} | {e['b_pass']} | {e['delta']:+d} |")
    out += ["", f"## Réussis par A seul ({len(comparison['better_in_a'])})", ""]
    out += [f"- `{c}`" for c in comparison["better_in_a"]] or ["Aucun."]
    out += ["", f"## Réussis par B seul ({len(comparison['better_in_b'])})", ""]
    out += [f"- `{c}`" for c in comparison["better_in_b"]] or ["Aucun."]
    out.append("")
    return "\n".join(out)
