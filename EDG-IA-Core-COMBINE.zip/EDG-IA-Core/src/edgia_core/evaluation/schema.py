"""Format des suites d'évaluation (fichiers YAML) : cas de test, vérifications, chargement strict.

Une suite est un dossier de fichiers `.yaml`, chacun contenant une liste de cas. Chaque cas décrit une conversation
et des vérifications AUTOMATIQUES. Ces vérifications sont volontairement simples et déterministes : elles détectent des
erreurs factuelles ou de consigne évidentes, elles ne mesurent PAS la qualité d'une réponse ouverte. Un cas sans
vérification (`checks` vide) est « à relire par un humain ».
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from edgia_core.errors import ConfigurationError, format_validation_error

_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_\-]{0,63}$")

CheckKind = Literal[
    "contains_all",
    "contains_any",
    "not_contains_any",
    "regex",
    "not_regex",
    "contains_number",
    "final_number",
    "word_count",
    "sentence_count",
    "bullet_count",
    "starts_with",
    "ends_with",
    "json_valid",
    "language",
    "refusal",
    "code_tests",
]

# Paramètres obligatoires par type de vérification.
_REQUIRED: dict[str, tuple[str, ...]] = {
    "contains_all": ("values",),
    "contains_any": ("values",),
    "not_contains_any": ("values",),
    "regex": ("value",),
    "not_regex": ("value",),
    "contains_number": ("number",),
    "final_number": ("number",),
    "starts_with": ("value",),
    "ends_with": ("value",),
    "language": ("value",),
    "refusal": ("expected",),
    "code_tests": ("function", "tests"),
}


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CheckSpec(_Strict):
    kind: CheckKind
    value: str | None = None
    values: list[str] | None = None
    number: float | None = None
    tolerance: float = Field(default=0.0, ge=0)
    min: int | None = Field(default=None, ge=0)
    max: int | None = Field(default=None, ge=0)
    keys: list[str] | None = None
    expected: bool | None = None
    case_sensitive: bool = False
    function: str | None = None
    tests: list[str] | None = None

    @model_validator(mode="after")
    def _check_params(self) -> CheckSpec:
        for name in _REQUIRED.get(self.kind, ()):
            if getattr(self, name) in (None, [], ""):
                raise ValueError(f"la vérification « {self.kind} » exige le paramètre « {name} »")
        if self.kind in ("word_count", "sentence_count", "bullet_count") and self.min is None and self.max is None:
            raise ValueError(f"la vérification « {self.kind} » exige min et/ou max")
        if self.min is not None and self.max is not None and self.min > self.max:
            raise ValueError("min ne peut pas dépasser max")
        if self.kind == "language" and self.value not in ("fr", "en"):
            raise ValueError("language : valeurs admises « fr » ou « en »")
        if self.kind in ("regex", "not_regex"):
            try:
                re.compile(self.value or "")
            except re.error as exc:
                raise ValueError(f"expression régulière invalide ({exc})") from None
        if self.kind == "code_tests" and not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", self.function or ""):
            raise ValueError("code_tests : nom de fonction invalide")
        return self


class TurnSpec(_Strict):
    role: Literal["system", "user", "assistant"]
    content: str = Field(min_length=1)


class CaseSpec(_Strict):
    id: str
    category: str
    messages: list[TurnSpec] = Field(min_length=1)
    checks: list[CheckSpec] = Field(default_factory=list)
    max_tokens: int = Field(default=256, ge=1, le=8192)
    note: str = ""

    @field_validator("id")
    @classmethod
    def _check_id(cls, value: str) -> str:
        if not _ID_RE.match(value):
            raise ValueError("identifiant invalide (minuscules, chiffres, « _ » et « - », 64 caractères au plus)")
        return value

    @field_validator("category")
    @classmethod
    def _check_category(cls, value: str) -> str:
        if not _ID_RE.match(value):
            raise ValueError("catégorie invalide (minuscules, chiffres, « _ » et « - »)")
        return value

    @model_validator(mode="after")
    def _check_last_turn(self) -> CaseSpec:
        if self.messages[-1].role != "user":
            raise ValueError("le dernier message d'un cas doit venir de l'utilisateur")
        return self

    @property
    def needs_review(self) -> bool:
        return not self.checks


class Suite(_Strict):
    name: str
    cases: tuple[CaseSpec, ...]
    sha256: str

    def categories(self) -> list[str]:
        return sorted({case.category for case in self.cases})


def load_suite(path: Path | str) -> Suite:
    """Charge un dossier de fichiers .yaml (ou un seul fichier). Toute erreur est signalée avec le fichier concerné."""
    root = Path(path)
    if root.is_dir():
        files = sorted(root.glob("*.yaml"))
    elif root.is_file():
        files = [root]
    else:
        raise ConfigurationError(f"Suite d'évaluation introuvable : {root}")
    if not files:
        raise ConfigurationError(f"Aucun fichier .yaml dans {root}")

    problems: list[str] = []
    cases: list[CaseSpec] = []
    digest = hashlib.sha256()
    for file in files:
        raw_bytes = file.read_bytes()
        digest.update(file.name.encode("utf-8") + b"\0" + raw_bytes + b"\0")
        try:
            raw = yaml.safe_load(raw_bytes.decode("utf-8"))
        except (yaml.YAMLError, UnicodeDecodeError):
            problems.append(f"{file.name} : YAML invalide")
            continue
        if not isinstance(raw, list):
            problems.append(f"{file.name} : le fichier doit contenir une liste de cas")
            continue
        for index, item in enumerate(raw, start=1):
            try:
                cases.append(CaseSpec.model_validate(item))
            except ValidationError as exc:
                label = item.get("id", f"#{index}") if isinstance(item, dict) else f"#{index}"
                problems.extend(format_validation_error(exc, prefix=f"{file.name} cas {label} — "))

    seen: set[str] = set()
    for case in cases:
        if case.id in seen:
            problems.append(f"Identifiant dupliqué : {case.id}")
        seen.add(case.id)
    if problems:
        raise ConfigurationError(problems)
    return Suite(name=root.name if root.is_dir() else root.stem, cases=tuple(cases), sha256=digest.hexdigest())
