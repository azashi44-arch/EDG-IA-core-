"""Exécution OPTIONNELLE de code Python produit par un modèle, pour vérifier des cas de programmation.

Désactivé par défaut : l'exécuteur n'appelle ce module que si l'opérateur passe explicitement `--allow-code-execution`.

Ce que le bac à sable fait : processus séparé (`python -I`), dossier de travail temporaire jetable, environnement vidé,
limites système (temps CPU, mémoire, taille de fichier, nombre de processus), délai maximal, sortie plafonnée.

Ce qu'il ne fait PAS (à lire avant de l'activer) : ce n'est pas une frontière de sécurité contre un code hostile.
Il n'isole ni le réseau ni le système de fichiers (le code peut lire les fichiers lisibles par l'utilisateur courant).
Il protège contre les accidents (boucle infinie, mémoire gourmande, fichiers géants), pas contre une attaque délibérée.
Pour évaluer un modèle non fiable, lancez l'évaluation dans un conteneur ou une machine jetable sans réseau.
"""

from __future__ import annotations

import json
import os
import re
import secrets
import subprocess
import sys
import tempfile
from dataclasses import dataclass

try:  # absent sous Windows : les limites système sont alors indisponibles et le bac à sable refuse de s'activer
    import resource
except ImportError:  # pragma: no cover
    resource = None  # type: ignore[assignment]

from edgia_core.evaluation.checks import FAIL, PASS, SKIPPED, CheckResult
from edgia_core.evaluation.schema import CheckSpec

_MAX_OUTPUT_BYTES = 64 * 1024
_MAX_CODE_CHARS = 20_000

_HARNESS = r"""
import json, sys
payload = json.loads(sys.stdin.read())
token = payload["token"]
function = payload["function"]
results = []
namespace = {"__name__": "__reponse__"}

def emit(obj):
    sys.stdout.write("\n" + token + json.dumps(obj) + "\n")
    sys.stdout.flush()

sys.stdout.write("\n" + token.replace("EDGIA_RESULT_", "EDGIA_READY_") + "\n")  # le harnais a démarré (voir run_code_tests)
sys.stdout.flush()
try:
    exec(compile(payload["code"], "<reponse>", "exec"), namespace)
except BaseException as exc:
    emit({"error": "le code ne s'exécute pas : " + type(exc).__name__})
    raise SystemExit(0)
target = namespace.get(function)
if not callable(target):
    emit({"error": "fonction « " + function + " » absente"})
    raise SystemExit(0)
for expression in payload["tests"]:
    try:
        results.append(bool(eval(expression, namespace)))
    except BaseException:
        results.append(False)
emit({"results": results})
"""


@dataclass(frozen=True)
class SandboxLimits:
    timeout_seconds: float = 5.0
    memory_mb: int = 512
    cpu_seconds: int = 5
    max_file_mb: int = 1
    max_processes: int = 16


def sandbox_available() -> bool:
    return resource is not None and os.name == "posix"


def extract_python(output: str) -> str:
    """Code Python d'une réponse : premier bloc ```python (ou ```), sinon la réponse entière."""
    fenced = re.search(r"```(?:python|py)?[ \t]*\n(.*?)```", output, re.DOTALL | re.IGNORECASE)
    return (fenced.group(1) if fenced else output).strip()


def _limiter(limits: SandboxLimits):
    def apply() -> None:  # exécuté dans le processus fils, avant le lancement de Python
        assert resource is not None
        memory = limits.memory_mb * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
        resource.setrlimit(resource.RLIMIT_CPU, (limits.cpu_seconds, limits.cpu_seconds))
        fsize = limits.max_file_mb * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_FSIZE, (fsize, fsize))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        if hasattr(resource, "RLIMIT_NPROC"):
            resource.setrlimit(resource.RLIMIT_NPROC, (limits.max_processes, limits.max_processes))
        os.setsid()  # groupe de processus propre : permet de tout tuer en cas de dépassement

    return apply


def run_code_tests(spec: CheckSpec, output: str, limits: SandboxLimits | None = None) -> CheckResult:
    """Exécute le code de la réponse puis les tests `spec.tests` (expressions Python évaluées après le code)."""
    kind = "code_tests"
    if not sandbox_available():
        return CheckResult(kind, SKIPPED, "bac à sable indisponible sur cette plateforme")
    limits = limits or SandboxLimits()
    code = extract_python(output)
    if not code:
        return CheckResult(kind, FAIL, "aucun code dans la réponse")
    if len(code) > _MAX_CODE_CHARS:
        return CheckResult(kind, FAIL, "code trop long")

    token = "EDGIA_RESULT_" + secrets.token_hex(8) + ":"
    payload = json.dumps(
        {"code": code, "function": spec.function, "tests": list(spec.tests or []), "token": token}
    )
    with tempfile.TemporaryDirectory(prefix="edgia-sandbox-") as workdir:
        try:
            process = subprocess.Popen(  # noqa: S603 - commande fixe, aucun argument issu du modèle
                [sys.executable, "-I", "-c", _HARNESS],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                cwd=workdir,
                env={"PATH": "/usr/bin:/bin", "HOME": workdir, "TMPDIR": workdir, "PYTHONDONTWRITEBYTECODE": "1"},
                preexec_fn=_limiter(limits),  # noqa: PLW1509 - nécessaire pour poser les limites avant l'exécution
            )
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            # Une limite refusée par le système (ex. RLIMIT_AS sous macOS) ou un lancement impossible : le code n'a PAS été
            # exécuté. On ne l'exécute jamais sans ses limites et on ne le déclare jamais réussi : le cas est « non exécuté ».
            return CheckResult(kind, SKIPPED, f"bac à sable impossible à démarrer sur cette machine ({type(exc).__name__}) : code non exécuté")
        try:
            stdout, _ = process.communicate(payload.encode("utf-8"), timeout=limits.timeout_seconds)
        except subprocess.TimeoutExpired:
            _kill_group(process)
            process.communicate()
            return CheckResult(kind, FAIL, f"délai de {limits.timeout_seconds:g} s dépassé")
        finally:
            _kill_group(process)

    text = stdout[-_MAX_OUTPUT_BYTES:].decode("utf-8", errors="replace")  # le résultat est écrit en dernier
    marker = text.rfind(token)
    if marker < 0 and token.replace("EDGIA_RESULT_", "EDGIA_READY_").encode() not in stdout:
        # Le harnais n'a jamais démarré : le code du modèle n'a PAS été exécuté. Ce n'est pas un échec du modèle (le
        # compter comme tel fausserait les scores) ; jamais « réussi » non plus. Cause à chercher avec tools/sandbox_diagnose.py.
        return CheckResult(
            kind, SKIPPED,
            f"bac à sable non démarré : l'interpréteur n'a pas lancé le harnais (code de sortie {process.returncode}) ; "
            "code non exécuté. Diagnostic : python3 tools/sandbox_diagnose.py",
        )
    if marker < 0:
        reason = "le code a été interrompu" if process.returncode else "aucun résultat produit"
        return CheckResult(kind, FAIL, f"{reason} (code de sortie {process.returncode})")
    try:
        report = json.loads(text[marker + len(token) :].splitlines()[0])
    except (ValueError, IndexError):
        return CheckResult(kind, FAIL, "résultat illisible")
    if "error" in report:
        return CheckResult(kind, FAIL, str(report["error"]))
    results = report.get("results", [])
    failed = [i + 1 for i, ok in enumerate(results) if not ok]
    if len(results) != len(spec.tests or []) or failed:
        return CheckResult(kind, FAIL, f"tests en échec : {failed}" if failed else "résultats incomplets")
    return CheckResult(kind, PASS, f"{len(results)} test(s) réussi(s)")


def _kill_group(process: subprocess.Popen) -> None:
    try:
        os.killpg(process.pid, 9)
    except (ProcessLookupError, PermissionError, OSError):
        pass
