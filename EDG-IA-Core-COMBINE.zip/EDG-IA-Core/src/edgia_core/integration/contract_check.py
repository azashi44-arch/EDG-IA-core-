"""Vérificateur du contrat d'API : `edgia-core contract-check`.

À lancer contre un serveur EDG-IA Core en marche (par l'équipe de l'application EDG-IA, avant toute bascule). Il vérifie
les formes de réponse dont l'application dépend (santé, modèles, chat complet et en flux, erreurs) en utilisant
uniquement la bibliothèque standard. La clé d'API est lue dans une variable d'environnement, jamais en argument.

Il vérifie le CONTRAT (formes, codes d'erreur, en-têtes), pas la QUALITÉ des réponses du modèle.
Avec `expect_real=True`, un serveur en mode démonstration est un ÉCHEC : l'application ne doit jamais prendre la
démonstration pour le vrai modèle.
"""

from __future__ import annotations

import http.client
import json
import urllib.parse
from collections.abc import Callable
from dataclasses import dataclass

MARKER = "MARQUEUR-CONFIDENTIEL-7Q2"  # ne doit jamais être recopié dans un message d'erreur


@dataclass(frozen=True)
class ContractResult:
    name: str
    ok: bool
    detail: str = ""


class _Client:
    def __init__(self, base_url: str, timeout: float) -> None:
        parts = urllib.parse.urlsplit(base_url)
        if parts.scheme not in ("http", "https") or not parts.hostname:
            raise ValueError("URL invalide : http(s)://hôte[:port] attendu")
        self.parts, self.timeout = parts, timeout

    def request(self, method: str, path: str, *, key: str | None = None, body: object = None, raw: bytes | None = None, content_type: str | None = "application/json") -> tuple[int, dict[str, str], bytes]:
        cls = http.client.HTTPSConnection if self.parts.scheme == "https" else http.client.HTTPConnection
        connection = cls(self.parts.hostname, self.parts.port, timeout=self.timeout)
        headers = {}
        if key:
            headers["Authorization"] = f"Bearer {key}"
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        if data is not None and content_type:
            headers["Content-Type"] = content_type
        try:
            connection.request(method, (self.parts.path.rstrip("/") + path), body=data, headers=headers)
            response = connection.getresponse()
            payload = response.read()
            return response.status, {k.lower(): v for k, v in response.getheaders()}, payload
        finally:
            connection.close()


def _json(payload: bytes) -> object:
    try:
        return json.loads(payload)
    except ValueError:
        return None


def _is_error(body: object, code: str | None = None) -> str | None:
    """None si `body` respecte {"error": {"type", "code", "message"}} (et le code attendu), sinon la raison."""
    if not isinstance(body, dict) or not isinstance(body.get("error"), dict):
        return "corps d'erreur absent ou mal formé"
    error = body["error"]
    for field in ("type", "code", "message"):
        if not isinstance(error.get(field), str) or not error[field]:
            return f"champ error.{field} manquant"
    if code is not None and error["code"] != code:
        return f"code « {error['code']} » au lieu de « {code} »"
    if MARKER in json.dumps(body):
        return "le message d'erreur recopie le contenu envoyé par le client"
    return None


def run_contract_check(
    base_url: str, api_key: str, *, expect_real: bool = False, check_knowledge: bool = False, timeout: float = 120.0
) -> list[ContractResult]:
    client = _Client(base_url, timeout)
    results: list[ContractResult] = []

    def check(name: str, fn: Callable[[], str | None]) -> None:
        try:
            problem = fn()
        except Exception as exc:  # noqa: BLE001 - un contrôle qui échoue ne doit pas masquer les suivants
            problem = f"{type(exc).__name__} : {exc}"[:200]
        results.append(ContractResult(name, problem is None, problem or ""))

    state: dict = {}

    def health() -> str | None:
        status, _h, payload = client.request("GET", "/health")
        body = _json(payload)
        if status != 200 or not isinstance(body, dict) or body.get("status") != "ok":
            return f"statut {status}, corps inattendu"
        return None

    def ready() -> str | None:
        status, _h, payload = client.request("GET", "/ready")
        body = _json(payload)
        if status != 200 or not isinstance(body, dict) or body.get("status") != "ready" or not isinstance(body.get("demo"), bool):
            return f"statut {status} : le modèle n'est pas prêt ou le corps est inattendu"
        state["demo"] = body["demo"]
        if expect_real and body["demo"]:
            return "le serveur est en MODE DÉMONSTRATION (demo: true) alors qu'un vrai modèle est attendu"
        return None

    def unauthorized() -> str | None:
        status, headers, payload = client.request("GET", "/v1/models")
        if status != 401:
            return f"statut {status} au lieu de 401 sans clé"
        if "bearer" not in headers.get("www-authenticate", "").lower():
            return "en-tête WWW-Authenticate: Bearer absent"
        return _is_error(_json(payload), "unauthorized")

    def models() -> str | None:
        status, _h, payload = client.request("GET", "/v1/models", key=api_key)
        body = _json(payload)
        if status != 200 or not isinstance(body, dict) or not body.get("data"):
            return f"statut {status} ou liste vide (clé refusée ?)"
        model = body["data"][0]
        if not isinstance(model.get("id"), str) or not isinstance(model.get("edgia", {}).get("demo"), bool):
            return "modèle sans id ou sans edgia.demo"
        state["model"] = model["id"]
        return None

    def chat() -> str | None:
        status, headers, payload = client.request(
            "POST", "/v1/chat/completions", key=api_key,
            body={"messages": [{"role": "system", "content": "Réponds brièvement."}, {"role": "user", "content": "Bonjour"}], "max_tokens": 16, "temperature": 0},
        )
        body = _json(payload)
        if status != 200 or not isinstance(body, dict):
            return f"statut {status} : {payload[:150]!r}"
        if not headers.get("x-request-id"):
            return "en-tête X-Request-ID absent"
        choice = (body.get("choices") or [{}])[0]
        message = choice.get("message", {})
        if message.get("role") != "assistant" or not isinstance(message.get("content"), str):
            return "choices[0].message mal formé"
        if choice.get("finish_reason") not in ("stop", "length"):
            return "finish_reason inattendu"
        usage = body.get("usage", {})
        if not all(isinstance(usage.get(k), int) for k in ("prompt_tokens", "completion_tokens", "total_tokens")):
            return "usage incomplet"
        if usage["total_tokens"] != usage["prompt_tokens"] + usage["completion_tokens"]:
            return "usage.total_tokens incohérent"
        if not isinstance(body.get("edgia", {}).get("demo"), bool) or body["model"] != state.get("model", body["model"]):
            return "edgia.demo absent ou model différent de /v1/models"
        return None

    def stream() -> str | None:
        status, _h, payload = client.request(
            "POST", "/v1/chat/completions", key=api_key,
            body={"messages": [{"role": "user", "content": "Bonjour"}], "max_tokens": 16, "temperature": 0, "stream": True},
        )
        if status != 200:
            return f"statut {status} (streaming désactivé ou non pris en charge ?)"
        blocks = [b for b in payload.decode("utf-8").split("\n\n") if b.startswith("data: ")]
        if not blocks or blocks[-1] != "data: [DONE]":
            return "le flux ne se termine pas par [DONE]"
        chunks = [json.loads(b[6:]) for b in blocks[:-1]]
        if not chunks or chunks[0]["choices"][0]["delta"].get("role") != "assistant":
            return "premier fragment sans rôle assistant"
        final = chunks[-1]
        if final["choices"][0].get("finish_reason") not in ("stop", "length") or "usage" not in final or "edgia" not in final:
            return "dernier fragment sans finish_reason, usage ou edgia"
        return None

    def invalid_request() -> str | None:
        status, _h, payload = client.request("POST", "/v1/chat/completions", key=api_key, body={"messages": [{"role": "user", "content": MARKER}], "champ_inconnu": MARKER})
        if status != 422:
            return f"statut {status} au lieu de 422 pour un champ inconnu"
        return _is_error(_json(payload), "invalid_request")

    def invalid_json() -> str | None:
        status, _h, payload = client.request("POST", "/v1/chat/completions", key=api_key, raw=b"{" + MARKER.encode())
        return f"statut {status} au lieu de 400" if status != 400 else _is_error(_json(payload), "invalid_json")

    def unknown_model() -> str | None:
        status, _h, payload = client.request("POST", "/v1/chat/completions", key=api_key, body={"model": "modele-inexistant", "messages": [{"role": "user", "content": MARKER}]})
        return f"statut {status} au lieu de 404" if status != 404 else _is_error(_json(payload), "model_not_found")

    def not_found() -> str | None:
        status, _h, payload = client.request("GET", "/v1/inexistant", key=api_key)
        return f"statut {status} au lieu de 404" if status != 404 else _is_error(_json(payload), "not_found")

    def knowledge() -> str | None:
        status, _h, payload = client.request("POST", "/v1/knowledge/search", key=api_key, body={"query": "capitale", "top_k": 1})
        body = _json(payload)
        if status != 200 or not isinstance(body, dict) or body.get("object") != "list" or not isinstance(body.get("data"), list):
            return f"statut {status} : base documentaire non configurée ou corps inattendu"
        for item in body["data"]:
            if not all(k in item for k in ("document_id", "title", "source", "text", "score")):
                return "passage sans champs de citation"
        return None

    check("GET /health", health)
    check("GET /ready (et mode démonstration)", ready)
    check("401 sans clé, avec WWW-Authenticate", unauthorized)
    check("GET /v1/models", models)
    check("POST /v1/chat/completions", chat)
    check("POST /v1/chat/completions (stream)", stream)
    check("422 champ inconnu, sans recopier le contenu", invalid_request)
    check("400 JSON invalide, sans recopier le contenu", invalid_json)
    check("404 modèle inconnu", unknown_model)
    check("404 route inconnue", not_found)
    if check_knowledge:
        check("POST /v1/knowledge/search", knowledge)
    return results
