"""Registre des modèles : versions, état de validation, activation contrôlée, retour arrière.

Stockage : SQLite (bibliothèque standard), un fichier local. Le registre ne contient aucun poids ni secret : il garde
le descripteur (JSON) de chaque version, le résultat de sa dernière validation et l'historique des activations.

États d'une version :
- registered : enregistrée, jamais validée ;
- validated  : `check_model` a réussi (licence vérifiée, fichiers présents, sommes SHA-256 correctes) ;
- failed     : la dernière validation a échoué ;
- active     : version servie (une seule à la fois) ;
- retired    : ancienne version active, remplacée ou retirée (peut être réactivée par retour arrière).

Seule une version « validated » ou « retired » dont la **revalidation immédiate** réussit peut être activée.
"""

from __future__ import annotations

import json
import sqlite3
import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

from edgia_core.errors import EdgiaError
from edgia_core.model.descriptor import ModelDescriptor, check_model

REGISTERED = "registered"
VALIDATED = "validated"
FAILED = "failed"
ACTIVE = "active"
RETIRED = "retired"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS versions (
    model_id     TEXT NOT NULL,
    version      TEXT NOT NULL,
    descriptor   TEXT NOT NULL,
    status       TEXT NOT NULL,
    problems     TEXT NOT NULL DEFAULT '[]',
    registered_at REAL NOT NULL,
    validated_at REAL,
    PRIMARY KEY (model_id, version)
);
CREATE TABLE IF NOT EXISTS history (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    at        REAL NOT NULL,
    action    TEXT NOT NULL,
    model_id  TEXT NOT NULL,
    version   TEXT NOT NULL,
    detail    TEXT NOT NULL DEFAULT ''
);
"""


class RegistryError(EdgiaError):
    """Opération refusée par le registre (le message explique pourquoi)."""


@dataclass(frozen=True)
class VersionRecord:
    model_id: str
    version: str
    status: str
    problems: tuple[str, ...]
    registered_at: float
    validated_at: float | None
    descriptor: ModelDescriptor


class ModelRegistry:
    def __init__(self, path: Path | str) -> None:
        self._path = str(path)
        if self._path != ":memory:":
            Path(self._path).parent.mkdir(parents=True, exist_ok=True)
        self._memory_connection: sqlite3.Connection | None = None
        with self._connect() as connection:
            connection.executescript(_SCHEMA)

    def close(self) -> None:
        """Ferme la base en mémoire (les bases fichier sont ouvertes et fermées à chaque opération)."""
        if self._memory_connection is not None:
            self._memory_connection.close()
            self._memory_connection = None

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:  # noqa: BLE001 - pendant l'arrêt de l'interpréteur
            pass

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        if self._path == ":memory:":
            if self._memory_connection is None:
                self._memory_connection = sqlite3.connect(":memory:")
            connection = self._memory_connection
        else:
            connection = sqlite3.connect(self._path, timeout=10)
        try:
            with connection:  # transaction : validée en cas de succès, annulée en cas d'exception
                yield connection
        finally:
            if self._path != ":memory:":
                connection.close()

    # --- lecture ---------------------------------------------------------------------------------------------

    @staticmethod
    def _record(row: tuple) -> VersionRecord:
        model_id, version, descriptor, status, problems, registered_at, validated_at = row
        return VersionRecord(
            model_id=model_id,
            version=version,
            status=status,
            problems=tuple(json.loads(problems)),
            registered_at=registered_at,
            validated_at=validated_at,
            descriptor=ModelDescriptor.model_validate_json(descriptor),
        )

    _COLUMNS = "model_id, version, descriptor, status, problems, registered_at, validated_at"

    def list_versions(self) -> list[VersionRecord]:
        with self._connect() as connection:
            rows = connection.execute(f"SELECT {self._COLUMNS} FROM versions ORDER BY registered_at, model_id, version").fetchall()
        return [self._record(row) for row in rows]

    def get(self, model_id: str, version: str) -> VersionRecord:
        with self._connect() as connection:
            row = connection.execute(
                f"SELECT {self._COLUMNS} FROM versions WHERE model_id = ? AND version = ?", (model_id, version)
            ).fetchone()
        if row is None:
            raise RegistryError(f"Version inconnue : {model_id} {version}")
        return self._record(row)

    def active(self) -> VersionRecord | None:
        with self._connect() as connection:
            row = connection.execute(f"SELECT {self._COLUMNS} FROM versions WHERE status = ?", (ACTIVE,)).fetchone()
        return self._record(row) if row else None

    def history(self) -> list[tuple[float, str, str, str, str]]:
        with self._connect() as connection:
            return connection.execute("SELECT at, action, model_id, version, detail FROM history ORDER BY id").fetchall()

    # --- écriture --------------------------------------------------------------------------------------------

    def register(self, descriptor: ModelDescriptor) -> VersionRecord:
        """Enregistre une version. Refuse d'écraser une version existante (une version est immuable)."""
        now = time.time()
        with self._connect() as connection:
            exists = connection.execute(
                "SELECT 1 FROM versions WHERE model_id = ? AND version = ?", (descriptor.model_id, descriptor.version)
            ).fetchone()
            if exists:
                raise RegistryError(
                    f"{descriptor.model_id} {descriptor.version} est déjà enregistrée : "
                    "une version est immuable, enregistrez une nouvelle version."
                )
            connection.execute(
                "INSERT INTO versions (model_id, version, descriptor, status, registered_at) VALUES (?, ?, ?, ?, ?)",
                (descriptor.model_id, descriptor.version, descriptor.model_dump_json(), REGISTERED, now),
            )
            connection.execute(
                "INSERT INTO history (at, action, model_id, version) VALUES (?, 'register', ?, ?)",
                (now, descriptor.model_id, descriptor.version),
            )
        return self.get(descriptor.model_id, descriptor.version)

    def validate(self, model_id: str, version: str) -> VersionRecord:
        """Vérifie licence, fichiers et sommes SHA-256. Une version active qui échoue est retirée du service."""
        record = self.get(model_id, version)
        problems, _warnings = check_model(record.descriptor)
        now = time.time()
        with self._connect() as connection:
            if problems:
                new_status = FAILED
            else:
                new_status = ACTIVE if record.status == ACTIVE else VALIDATED
            connection.execute(
                "UPDATE versions SET status = ?, problems = ?, validated_at = ? WHERE model_id = ? AND version = ?",
                (new_status, json.dumps(problems, ensure_ascii=False), now, model_id, version),
            )
            connection.execute(
                "INSERT INTO history (at, action, model_id, version, detail) VALUES (?, 'validate', ?, ?, ?)",
                (now, model_id, version, "ok" if not problems else f"{len(problems)} problème(s)"),
            )
        return self.get(model_id, version)

    def activate(self, model_id: str, version: str) -> VersionRecord:
        """Active une version après revalidation immédiate ; l'ancienne version active devient « retired »."""
        return self._activate(model_id, version, action="activate")

    def _activate(self, model_id: str, version: str, *, action: str) -> VersionRecord:
        record = self.get(model_id, version)
        if record.status == ACTIVE:
            return record
        if record.status not in (VALIDATED, RETIRED):
            raise RegistryError(
                f"{model_id} {version} est « {record.status} » : validez-la d'abord (état « validated » requis)."
            )
        problems, _warnings = check_model(record.descriptor)  # les fichiers ont pu changer depuis la validation
        if problems:
            self.validate(model_id, version)
            raise RegistryError(
                f"Activation refusée : la revalidation de {model_id} {version} a échoué ("
                + " ; ".join(problems)
                + ")."
            )
        now = time.time()
        with self._connect() as connection:
            previous = connection.execute("SELECT model_id, version FROM versions WHERE status = ?", (ACTIVE,)).fetchone()
            if previous:
                connection.execute("UPDATE versions SET status = ? WHERE status = ?", (RETIRED, ACTIVE))
            connection.execute(
                "UPDATE versions SET status = ?, problems = '[]', validated_at = ? WHERE model_id = ? AND version = ?",
                (ACTIVE, now, model_id, version),
            )
            detail = f"remplace {previous[0]} {previous[1]}" if previous else "première activation"
            connection.execute(
                "INSERT INTO history (at, action, model_id, version, detail) VALUES (?, ?, ?, ?, ?)",
                (now, action, model_id, version, detail),
            )
        return self.get(model_id, version)

    def rollback(self) -> VersionRecord:
        """Revient à la version que la dernière activation de la version courante a remplacée (après revalidation).

        Un second retour arrière revient à la version qui venait d'être quittée.
        """
        current = self.active()
        if current is None:
            raise RegistryError("Aucune version active : retour arrière impossible.")
        with self._connect() as connection:
            last = connection.execute(
                "SELECT detail FROM history WHERE action IN ('activate', 'rollback') AND model_id = ? AND version = ? "
                "ORDER BY id DESC LIMIT 1",
                (current.model_id, current.version),
            ).fetchone()
        prefix = "remplace "
        if not last or not last[0].startswith(prefix):
            raise RegistryError("Pas de version précédente connue : retour arrière impossible.")
        previous_model, _, previous_version = last[0][len(prefix) :].rpartition(" ")
        return self._activate(previous_model, previous_version, action="rollback")

    def retire(self, model_id: str, version: str) -> VersionRecord:
        """Retire du service une version active (le serveur refusera alors de démarrer en mode réel via le registre)."""
        record = self.get(model_id, version)
        if record.status != ACTIVE:
            raise RegistryError(f"{model_id} {version} n'est pas active.")
        now = time.time()
        with self._connect() as connection:
            connection.execute("UPDATE versions SET status = ? WHERE model_id = ? AND version = ?", (RETIRED, model_id, version))
            connection.execute(
                "INSERT INTO history (at, action, model_id, version) VALUES (?, 'retire', ?, ?)", (now, model_id, version)
            )
        return self.get(model_id, version)
