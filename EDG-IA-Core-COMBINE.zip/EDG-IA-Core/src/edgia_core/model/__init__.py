"""Chargement et description du modèle (le registre et l'adaptateur arrivent en phase 3)."""

from edgia_core.model.descriptor import (
    ModelDescriptor,
    Runtime,
    WeightsFormat,
    apply_overrides,
    check_model,
    load_descriptor,
)

__all__ = [
    "ModelDescriptor",
    "Runtime",
    "WeightsFormat",
    "apply_overrides",
    "check_model",
    "load_descriptor",
]
