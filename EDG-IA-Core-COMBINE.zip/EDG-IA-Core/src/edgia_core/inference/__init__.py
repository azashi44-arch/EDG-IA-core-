"""Génération des réponses : interface des moteurs, modèle de démonstration, verrou de concurrence.

Le chargement d'un vrai modèle (adaptateur) arrive en phase 3.
"""

from edgia_core.inference.base import (
    EngineError,
    GenerationParams,
    GenerationResult,
    InferenceEngine,
    Message,
    ModelInfo,
    StreamChunk,
)
from edgia_core.inference.demo import DEMO_MODEL_ID, DemoEngine
from edgia_core.inference.gate import ConcurrencyGate, Slot

__all__ = [
    "DEMO_MODEL_ID",
    "ConcurrencyGate",
    "DemoEngine",
    "EngineError",
    "GenerationParams",
    "GenerationResult",
    "InferenceEngine",
    "Message",
    "ModelInfo",
    "Slot",
    "StreamChunk",
]
