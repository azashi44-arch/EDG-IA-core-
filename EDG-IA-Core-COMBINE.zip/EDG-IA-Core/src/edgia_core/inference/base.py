"""Interface commune des moteurs d'inférence (démonstration aujourd'hui, vrai modèle en phase 3)."""

from __future__ import annotations

import threading
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Sequence
from dataclasses import dataclass

from edgia_core.errors import EdgiaError


class EngineError(EdgiaError):
    """Échec de génération. Le message ne doit jamais contenir le contenu des conversations."""


@dataclass(frozen=True)
class Message:
    role: str
    content: str


@dataclass(frozen=True)
class ModelInfo:
    id: str
    version: str
    runtime: str
    is_demo: bool
    description: str = ""


@dataclass(frozen=True)
class GenerationParams:
    max_tokens: int
    temperature: float = 0.7
    top_p: float = 1.0
    stop: tuple[str, ...] = ()


@dataclass(frozen=True)
class GenerationResult:
    text: str
    finish_reason: str  # "stop" ou "length"
    prompt_tokens: int
    completion_tokens: int


@dataclass(frozen=True)
class StreamChunk:
    text: str
    finish_reason: str | None = None  # renseigné uniquement sur le dernier fragment
    completion_tokens: int | None = None  # idem


class InferenceEngine(ABC):
    """Un moteur est bloquant pour `generate` (exécuté dans un thread par le serveur) et asynchrone pour `stream`."""

    supports_streaming: bool = False
    # Vrai si `generate` accepte `cancel` et s'arrête réellement quand l'événement est positionné.
    supports_cancel: bool = False

    @property
    @abstractmethod
    def info(self) -> ModelInfo: ...

    @abstractmethod
    def is_ready(self) -> bool: ...

    @abstractmethod
    def count_tokens(self, messages: Sequence[Message]) -> int:
        """Nombre de tokens du prompt (une approximation est acceptable si le moteur le documente)."""

    @abstractmethod
    def generate(
        self, messages: Sequence[Message], params: GenerationParams, cancel: threading.Event | None = None
    ) -> GenerationResult: ...

    def close(self) -> None:
        """Libère les ressources du modèle (appelé à l'arrêt du serveur)."""

    def stream(self, messages: Sequence[Message], params: GenerationParams) -> AsyncIterator[StreamChunk]:
        raise EngineError("Ce moteur ne prend pas en charge le streaming.")
