"""Backend Transformers (PyTorch) : charge un modèle local et produit du texte.

ÉTAT : ce module n'a JAMAIS été exécuté avec les vraies bibliothèques (PyTorch et Transformers sont inaccessibles
dans l'environnement où il a été écrit). Seule la logique qui l'entoure (`llm_engine.py`) est testée, avec un backend
factice ; un test de fumée avec de fausses bibliothèques vérifie seulement l'enchaînement des appels. Les noms d'API
Transformers peuvent varier selon la version : le premier chargement d'un vrai modèle est l'étape de validation
(`tests/real_model/`, `docs/GUIDE_SPECIALISTES.md`).

Garde-fous : chargement strictement local (`local_files_only`), jamais de code distant (`trust_remote_code=False`),
poids safetensors uniquement, aucun téléchargement.

Limite : les générations sont sérialisées (un seul `generate` à la fois sur le modèle). Il n'y a pas de traitement
par lots ; la capacité en requêtes simultanées dépend donc de la file derrière ce verrou.
"""

from __future__ import annotations

import threading
from collections.abc import Iterator, Sequence
from pathlib import Path
from typing import Any

from edgia_core.errors import ConfigurationError
from edgia_core.inference.base import EngineError, GenerationParams, Message
from edgia_core.inference.llm_engine import Backend, Done, Piece
from edgia_core.model.descriptor import AdaptationMethod, Device, ModelDescriptor

_STREAM_TIMEOUT_SECONDS = 600.0


def _import(name: str, hint: str) -> Any:
    try:
        return __import__(name, fromlist=["_"])
    except ImportError as exc:
        raise ConfigurationError(
            f"Dépendance absente : « {name} ». Installez-la ({hint}) ; EDG-IA Core ne télécharge rien automatiquement."
        ) from exc


class HuggingFaceBackend(Backend):
    def __init__(self, descriptor: ModelDescriptor, *, device: str | None = None) -> None:
        torch = _import("torch", "pip install torch")
        transformers = _import("transformers", "pip install transformers")
        self._torch = torch
        self._transformers = transformers
        self._lock = threading.Lock()

        weights = descriptor.weights_path
        if not weights.is_dir() or not (weights / "config.json").is_file():
            raise ConfigurationError(
                f"Runtime transformers : weights_path doit être un dossier contenant config.json et les fichiers "
                f".safetensors (reçu : {weights})."
            )
        assert descriptor.tokenizer_path is not None  # garanti par le descripteur pour ce runtime

        self._device = device or self._pick_device(descriptor.hardware.device)
        self._tokenizer = transformers.AutoTokenizer.from_pretrained(
            str(descriptor.tokenizer_path), local_files_only=True, trust_remote_code=False
        )
        if not getattr(self._tokenizer, "chat_template", None):
            raise ConfigurationError(
                "Le tokenizer ne fournit pas de modèle de conversation (chat_template) : impossible de formater les "
                "messages system/user/assistant. Utilisez le tokenizer d'une version « instruct » du modèle."
            )
        self._model = self._load_model(descriptor)
        self._model.eval()

    # --- chargement ------------------------------------------------------------------------------------------

    def _pick_device(self, requested: Device) -> str:
        if requested is Device.CPU:
            return "cpu"
        available = bool(self._torch.cuda.is_available())
        if requested is Device.CUDA and not available:
            raise ConfigurationError("hardware.device vaut « cuda » mais aucun GPU CUDA n'est disponible.")
        return "cuda" if available else "cpu"

    def _load_model(self, descriptor: ModelDescriptor) -> Any:
        auto = self._transformers.AutoModelForCausalLM
        common = {"local_files_only": True, "trust_remote_code": False, "use_safetensors": True}
        try:
            model = auto.from_pretrained(str(descriptor.weights_path), dtype="auto", **common)
        except TypeError:  # versions de Transformers où l'argument s'appelle encore torch_dtype
            model = auto.from_pretrained(str(descriptor.weights_path), torch_dtype="auto", **common)

        method = descriptor.adaptation.method
        if method in (AdaptationMethod.LORA, AdaptationMethod.QLORA):
            adapter = descriptor.adaptation.adapter_path
            if adapter is None:
                raise ConfigurationError("adaptation.method exige adaptation.adapter_path (dossier de l'adaptateur LoRA).")
            peft = _import("peft", "pip install peft")
            model = peft.PeftModel.from_pretrained(model, str(adapter), local_files_only=True)
        return model.to(self._device)

    # --- Backend ---------------------------------------------------------------------------------------------

    def _prompt_text(self, messages: Sequence[Message]) -> str:
        return self._tokenizer.apply_chat_template(
            [{"role": m.role, "content": m.content} for m in messages], tokenize=False, add_generation_prompt=True
        )

    def count_prompt_tokens(self, messages: Sequence[Message]) -> int:
        encoded = self._tokenizer(self._prompt_text(messages), add_special_tokens=False)
        return len(encoded["input_ids"])

    def stream(
        self, messages: Sequence[Message], params: GenerationParams, cancel: threading.Event
    ) -> Iterator[Piece | Done]:
        # Attente du verrou en surveillant l'annulation : une requête en retard ne bloque pas indéfiniment.
        while not self._lock.acquire(timeout=0.1):
            if cancel.is_set():
                return
        try:
            yield from self._generate_locked(messages, params, cancel)
        finally:
            self._lock.release()

    def _generate_locked(
        self, messages: Sequence[Message], params: GenerationParams, cancel: threading.Event
    ) -> Iterator[Piece | Done]:
        torch, transformers = self._torch, self._transformers
        inputs = self._tokenizer(self._prompt_text(messages), add_special_tokens=False, return_tensors="pt")
        inputs = {key: value.to(self._device) for key, value in inputs.items()}
        prompt_length = int(inputs["input_ids"].shape[1])

        # Événement interne : l'annulation de l'appelant (`cancel`) ne doit jamais être positionnée par le backend,
        # sinon une génération terminée normalement serait prise pour une annulation.
        halt = threading.Event()

        class _Halt(transformers.StoppingCriteria):
            def __call__(self, input_ids: Any, scores: Any, **kwargs: Any) -> Any:
                stop = halt.is_set() or cancel.is_set()
                return torch.full((input_ids.shape[0],), stop, dtype=torch.bool, device=input_ids.device)

        streamer = transformers.TextIteratorStreamer(
            self._tokenizer, skip_prompt=True, skip_special_tokens=True, timeout=_STREAM_TIMEOUT_SECONDS
        )
        options: dict[str, Any] = {
            "max_new_tokens": params.max_tokens,
            "streamer": streamer,
            "stopping_criteria": transformers.StoppingCriteriaList([_Halt()]),
            "pad_token_id": self._tokenizer.pad_token_id
            if self._tokenizer.pad_token_id is not None
            else self._tokenizer.eos_token_id,
        }
        if params.temperature > 0:
            options.update(do_sample=True, temperature=params.temperature, top_p=params.top_p)
        else:
            options["do_sample"] = False

        outcome: dict[str, Any] = {}

        def run() -> None:
            try:
                with torch.no_grad():
                    outcome["output"] = self._model.generate(**inputs, **options)
            except BaseException as exc:  # noqa: BLE001 - remonté au thread appelant
                outcome["error"] = exc
            finally:
                streamer.end()

        thread = threading.Thread(target=run, name="edgia-hf-generate", daemon=True)
        thread.start()
        try:
            for text in streamer:
                if cancel.is_set():
                    break
                yield Piece(text)
        finally:
            halt.set()  # si le consommateur s'en va, `generate` s'arrête au prochain token
            thread.join()

        if "error" in outcome:
            raise EngineError(f"Échec de génération ({type(outcome['error']).__name__}).")
        output = outcome["output"]
        generated = int(output.shape[1]) - prompt_length
        last = int(output[0, -1])
        eos = self._model.generation_config.eos_token_id
        eos_ids = {eos} if isinstance(eos, int) else set(eos or ())
        yield Done("stop" if last in eos_ids or generated < params.max_tokens else "length", generated)

    def close(self) -> None:
        self._model = None
        self._tokenizer = None
        if self._device == "cuda":
            self._torch.cuda.empty_cache()
