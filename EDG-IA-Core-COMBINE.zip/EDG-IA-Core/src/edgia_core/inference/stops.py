"""Détection des séquences d'arrêt dans un flux de texte arrivant par morceaux.

Une séquence d'arrêt peut être coupée entre deux morceaux : on retient donc les derniers caractères tant qu'ils
pourraient être le début d'une séquence. Le texte de la séquence d'arrêt n'est jamais émis.
"""

from __future__ import annotations


class StopMatcher:
    def __init__(self, stops: tuple[str, ...]) -> None:
        self._stops = tuple(s for s in stops if s)
        self._holdback = max((len(s) for s in self._stops), default=1) - 1
        self._buffer = ""
        self.stopped = False

    def feed(self, text: str) -> str:
        """Retourne le texte qu'on peut émettre sans risque ; `stopped` devient vrai à la première séquence trouvée."""
        if self.stopped:
            return ""
        if not self._stops:
            return text
        self._buffer += text
        cut = min((i for i in (self._buffer.find(s) for s in self._stops) if i >= 0), default=-1)
        if cut >= 0:
            emit, self._buffer, self.stopped = self._buffer[:cut], "", True
            return emit
        safe = len(self._buffer) - self._holdback
        if safe <= 0:
            return ""
        emit, self._buffer = self._buffer[:safe], self._buffer[safe:]
        return emit

    def flush(self) -> str:
        """Fin du flux : rend le texte retenu (il ne contient aucune séquence d'arrêt complète)."""
        if self.stopped:
            return ""
        emit, self._buffer = self._buffer, ""
        return emit
