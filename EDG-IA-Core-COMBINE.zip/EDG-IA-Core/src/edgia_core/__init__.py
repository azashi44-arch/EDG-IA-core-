"""EDG-IA Core : moteur d'IA du projet EDG-IA (projet indépendant de l'application existante)."""

__version__ = "0.1.0"
