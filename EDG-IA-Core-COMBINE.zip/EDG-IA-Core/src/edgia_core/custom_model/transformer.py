"""Petit Transformer decoder-only causal, écrit pour EDG-IA.

PyTorch est une dépendance optionnelle: l'import du module échoue avec un message
explicite si l'extra `ml` n'est pas installé. Ce modèle est un prototype, pas un
LLM pré-entraîné: ses poids sont aléatoires jusqu'à entraînement.
"""
from __future__ import annotations

try:
    import torch
    from torch import nn
except ImportError as exc:  # pragma: no cover - dépend de l'environnement
    raise ImportError("Installe PyTorch avec `pip install -e '.[ml]'` pour utiliser le modèle EDG-IA.") from exc


class EDGIAConfig:
    def __init__(self, vocab_size: int = 256, context_length: int = 256,
                 d_model: int = 128, n_heads: int = 4, n_layers: int = 4,
                 dropout: float = 0.1):
        if vocab_size < 2 or context_length < 2 or d_model < 1 or n_heads < 1 or n_layers < 1:
            raise ValueError("Les dimensions doivent être positives (vocab/context >= 2)")
        if d_model % n_heads:
            raise ValueError("d_model doit être divisible par n_heads")
        if not 0 <= dropout < 1:
            raise ValueError("dropout doit être dans [0, 1)")
        self.vocab_size = vocab_size
        self.context_length = context_length
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_layers = n_layers
        self.dropout = dropout


class CausalBlock(nn.Module):
    def __init__(self, config: EDGIAConfig):
        super().__init__()
        self.norm1 = nn.LayerNorm(config.d_model)
        self.attention = nn.MultiheadAttention(config.d_model, config.n_heads,
                                             dropout=config.dropout, batch_first=True)
        self.norm2 = nn.LayerNorm(config.d_model)
        self.mlp = nn.Sequential(
            nn.Linear(config.d_model, 4 * config.d_model), nn.GELU(),
            nn.Linear(4 * config.d_model, config.d_model), nn.Dropout(config.dropout)
        )

    def forward(self, x: torch.Tensor, causal_mask: torch.Tensor) -> torch.Tensor:
        y = self.norm1(x)
        attended, _ = self.attention(y, y, y, attn_mask=causal_mask, need_weights=False)
        x = x + attended
        return x + self.mlp(self.norm2(x))


class EDGIATransformer(nn.Module):
    """Decoder causal: entrée [batch, seq], logits de sortie [batch, seq, vocab]."""
    def __init__(self, config: EDGIAConfig | None = None):
        super().__init__()
        self.config = config or EDGIAConfig()
        c = self.config
        self.token_embedding = nn.Embedding(c.vocab_size, c.d_model)
        self.position_embedding = nn.Embedding(c.context_length, c.d_model)
        self.blocks = nn.ModuleList([CausalBlock(c) for _ in range(c.n_layers)])
        self.final_norm = nn.LayerNorm(c.d_model)
        self.lm_head = nn.Linear(c.d_model, c.vocab_size, bias=False)
        self.lm_head.weight = self.token_embedding.weight

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        if input_ids.ndim != 2:
            raise ValueError("input_ids doit avoir la forme [batch, sequence]")
        batch, seq_len = input_ids.shape
        if seq_len > self.config.context_length:
            raise ValueError(f"Séquence {seq_len} > context_length {self.config.context_length}")
        positions = torch.arange(seq_len, device=input_ids.device).unsqueeze(0)
        x = self.token_embedding(input_ids) + self.position_embedding(positions)
        mask = torch.triu(torch.ones(seq_len, seq_len, device=input_ids.device, dtype=torch.bool), diagonal=1)
        for block in self.blocks:
            x = block(x, mask)
        return self.lm_head(self.final_norm(x))

    @torch.no_grad()
    def generate(self, input_ids: torch.Tensor, max_new_tokens: int = 80,
                 temperature: float = 1.0, top_k: int | None = 40) -> torch.Tensor:
        if temperature <= 0:
            raise ValueError("temperature doit être > 0")
        self.eval()
        for _ in range(max_new_tokens):
            context = input_ids[:, -self.config.context_length:]
            logits = self(context)[:, -1, :] / temperature
            if top_k is not None and 0 < top_k < logits.shape[-1]:
                values, _ = torch.topk(logits, top_k)
                logits[logits < values[:, [-1]]] = -float("inf")
            next_id = torch.multinomial(torch.softmax(logits, dim=-1), num_samples=1)
            input_ids = torch.cat((input_ids, next_id), dim=1)
        return input_ids
