"""Script autonome d'entraînement du prototype EDG-IA Transformer.
Usage: python -m edgia_core.custom_model.train --data ./corpus --steps 1000
"""
from __future__ import annotations
import argparse, json, math
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from .dataset import TextCorpus
from .transformer import EDGIAConfig, EDGIATransformer


def main() -> int:
    p = argparse.ArgumentParser(description="Entraîner le prototype Transformer EDG-IA")
    p.add_argument("--data", required=True, help="Fichier .txt ou dossier de fichiers .txt")
    p.add_argument("--output", default="artifacts/edgia-small")
    p.add_argument("--steps", type=int, default=1000)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--context", type=int, default=128)
    p.add_argument("--d-model", type=int, default=128)
    p.add_argument("--heads", type=int, default=4)
    p.add_argument("--layers", type=int, default=4)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--save-every", type=int, default=100)
    p.add_argument("--resume", help="Checkpoint .pt à reprendre")
    args = p.parse_args()
    if args.steps < 1 or args.batch_size < 1 or args.save_every < 1:
        p.error("steps, batch-size et save-every doivent être positifs")
    torch.manual_seed(42)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    config = EDGIAConfig(context_length=args.context, d_model=args.d_model,
                         n_heads=args.heads, n_layers=args.layers)
    dataset = TextCorpus(args.data, args.context)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True, drop_last=True)
    if len(loader) == 0:
        p.error("Corpus insuffisant pour former un batch")
    model = EDGIATransformer(config).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)
    start_step = 0
    if args.resume:
        state = torch.load(args.resume, map_location=device, weights_only=False)
        model.load_state_dict(state["model"])
        optimizer.load_state_dict(state["optimizer"])
        start_step = int(state.get("step", 0))
    output = Path(args.output); output.mkdir(parents=True, exist_ok=True)
    model.train(); step = start_step
    while step < start_step + args.steps:
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(x)
            loss = torch.nn.functional.cross_entropy(logits.reshape(-1, config.vocab_size), y.reshape(-1))
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); optimizer.step()
            step += 1
            if step % 10 == 0: print(f"step={step} loss={loss.item():.4f} device={device}")
            if step % args.save_every == 0 or step >= start_step + args.steps:
                payload = {"step": step, "model": model.state_dict(), "optimizer": optimizer.state_dict(),
                          "config": vars(config), "loss": float(loss.item())}
                torch.save(payload, output / f"checkpoint-{step}.pt")
                (output / "config.json").write_text(json.dumps(vars(config), indent=2), encoding="utf-8")
            if step >= start_step + args.steps: break
    print(f"Entraînement terminé. Checkpoints: {output.resolve()}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
