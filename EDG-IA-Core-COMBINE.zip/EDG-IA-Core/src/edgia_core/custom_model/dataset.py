"""Chargement simple de corpus texte local pour le pré-entraînement causal."""
from __future__ import annotations
import json
from pathlib import Path
import torch
from torch.utils.data import Dataset
from .tokenizer import ByteTokenizer

class TextCorpus(Dataset):
    def __init__(self, path: str | Path, context_length: int = 256):
        self.path = Path(path)
        self.context_length = context_length
        if context_length < 2:
            raise ValueError("context_length doit être >= 2")
        if not self.path.exists():
            raise FileNotFoundError(f"Corpus introuvable: {self.path}")
        tokenizer = ByteTokenizer()
        chunks: list[int] = []
        files = [self.path] if self.path.is_file() else sorted(self.path.rglob("*.txt"))
        if not files:
            raise ValueError("Aucun fichier .txt trouvé dans le corpus")
        for file in files:
            text = file.read_text(encoding="utf-8", errors="strict")
            chunks.extend(tokenizer.encode(text + "\n"))
        self.tokens = torch.tensor(chunks, dtype=torch.long)
        if len(self.tokens) < context_length + 1:
            raise ValueError(f"Corpus trop petit: {len(self.tokens)} octets; minimum {context_length+1}")
    def __len__(self) -> int:
        return len(self.tokens) - self.context_length
    def __getitem__(self, index: int):
        sample = self.tokens[index:index + self.context_length + 1]
        return sample[:-1], sample[1:]
