"""Tokeniseur UTF-8 byte-level minimal, stable et sans vocabulaire à télécharger.

Ce tokeniseur est un prototype pédagogique/technique, pas un tokenizer performant
pour un LLM de production. Les IDs 0..255 représentent les octets UTF-8.
"""
from __future__ import annotations


class ByteTokenizer:
    vocab_size = 256

    def encode(self, text: str) -> list[int]:
        if not isinstance(text, str):
            raise TypeError("text doit être une chaîne")
        return list(text.encode("utf-8"))

    def decode(self, token_ids: list[int]) -> str:
        if any(not isinstance(i, int) or i < 0 or i > 255 for i in token_ids):
            raise ValueError("Chaque token doit être un entier entre 0 et 255")
        return bytes(token_ids).decode("utf-8", errors="replace")
