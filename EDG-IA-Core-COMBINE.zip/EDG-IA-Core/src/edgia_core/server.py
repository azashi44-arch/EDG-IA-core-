"""Lancement du serveur HTTP avec uvicorn."""

from __future__ import annotations

from edgia_core.api.app import create_app
from edgia_core.config import Settings
from edgia_core.logging_setup import configure_logging


def serve(settings: Settings) -> None:
    """Démarre le service. Lève ConfigurationError si la configuration interdit le démarrage."""
    configure_logging(settings)
    app = create_app(settings)  # refuse de démarrer avant d'ouvrir le moindre port

    import uvicorn  # importé ici : `check-config` n'en a pas besoin

    uvicorn.run(
        app,
        host=settings.host,
        port=settings.port,
        log_level=settings.log_level.value.lower(),
        access_log=False,  # EDG-IA Core journalise lui-même chaque requête, sans contenu ni paramètres d'URL
        server_header=False,
        timeout_keep_alive=5,
    )
