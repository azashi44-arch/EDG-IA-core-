"""Préparation d'un jeu de données d'adaptation : nettoyage, dédoublonnage, anti-contamination, découpage, manifeste.

Aucun entraînement ici. Chaque enregistrement écarté est compté avec sa raison, jamais recopié (il peut contenir des
données personnelles). Les sorties sont déterministes : mêmes entrées et mêmes options, mêmes fichiers.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from edgia_core import __version__
from edgia_core.errors import ConfigurationError
from edgia_core.evaluation.checks import detect_language, normalize
from edgia_core.evaluation.schema import Suite
from edgia_core.training.data import DataRecord, DataTurn
from edgia_core.training.pii import scrub

MANIFEST_FORMAT = 1
_WORD = re.compile(r"[^\W_]+", re.UNICODE)
_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


@dataclass(frozen=True)
class PrepareOptions:
    allow_user_conversations: bool = False  # autorisation explicite, en plus du consentement inscrit dans la donnée
    pii_mode: str = "redact"  # redact | reject
    min_assistant_chars: int = 2
    max_message_chars: int = 8000
    max_total_chars: int = 24000
    near_duplicate_threshold: float = 0.9
    contamination_ngram: int = 8
    val_fraction: float = 0.05
    seed: int = 0

    def validate(self) -> None:
        problems = []
        if self.pii_mode not in ("redact", "reject"):
            problems.append("pii_mode : « redact » ou « reject »")
        if not 0 <= self.val_fraction < 0.5:
            problems.append("val_fraction : entre 0 (inclus) et 0,5 (exclu)")
        if not 0.5 <= self.near_duplicate_threshold <= 1:
            problems.append("near_duplicate_threshold : entre 0,5 et 1")
        if self.contamination_ngram < 4:
            problems.append("contamination_ngram : 4 au minimum")
        if problems:
            raise ConfigurationError(problems)


@dataclass
class PrepareResult:
    train: list[DataRecord] = field(default_factory=list)
    validation: list[DataRecord] = field(default_factory=list)
    rejected: list[tuple[str, str]] = field(default_factory=list)  # (id, raison)
    pii: Counter = field(default_factory=Counter)
    warnings: list[str] = field(default_factory=list)
    contamination_checked: bool = False
    suite_sha256: str | None = None


# --- outils de texte ---------------------------------------------------------------------------------------------


def _words(text: str) -> list[str]:
    return _WORD.findall(normalize(text))


def _conversation_text(record: DataRecord) -> str:
    return "\n".join(f"{m.role}: {m.content}" for m in record.messages)


def _shingles(words: list[str], size: int = 5) -> set[str]:
    if len(words) < size:
        return {" ".join(words)} if words else set()
    return {" ".join(words[i : i + size]) for i in range(len(words) - size + 1)}


def _hash64(value: str, salt: int) -> int:
    return int.from_bytes(hashlib.blake2b(value.encode("utf-8"), digest_size=8, salt=salt.to_bytes(8, "little")).digest(), "big")


def _minhash(shingles: set[str], permutations: int = 32) -> tuple[int, ...]:
    return tuple(min(_hash64(s, p) for s in shingles) for p in range(permutations)) if shingles else ()


def _jaccard(a: set[str], b: set[str]) -> float:
    return len(a & b) / len(a | b) if a and b else 0.0


# --- étapes ----------------------------------------------------------------------------------------------------


def _quality_problem(record: DataRecord, options: PrepareOptions) -> str | None:
    total = 0
    for turn in record.messages:
        if not turn.content.strip():
            return "message vide"
        if _CONTROL.search(turn.content):
            return "caractères de contrôle"
        if len(turn.content) > options.max_message_chars:
            return "message trop long"
        total += len(turn.content)
    if total > options.max_total_chars:
        return "conversation trop longue"
    answer = record.messages[-1].content.strip()
    if len(answer) < options.min_assistant_chars:
        return "réponse trop courte"
    if re.search(r"(.)\1{49,}", answer):
        return "répétition anormale"
    words = _words(answer)
    if len(words) >= 20 and len(set(words)) / len(words) < 0.2:
        return "réponse répétitive"
    return None


class _ContaminationIndex:
    """Textes de la suite d'évaluation : un enregistrement qui en contient un (en entier ou par n-gramme) est écarté."""

    def __init__(self, suite: Suite, ngram: int) -> None:
        self.ngram = ngram
        self.full: set[str] = set()
        self.grams: set[str] = set()
        for case in suite.cases:
            for turn in case.messages:
                if turn.role == "assistant":
                    continue
                words = _words(turn.content)
                if not words:
                    continue
                self.full.add(" ".join(words))
                if len(words) >= ngram:
                    self.grams.update(" ".join(words[i : i + ngram]) for i in range(len(words) - ngram + 1))

    def hit(self, record: DataRecord) -> bool:
        for turn in record.messages:
            words = _words(turn.content)
            joined = " ".join(words)
            if turn.role != "assistant" and joined in self.full:
                return True
            if any(full in joined for full in self.full if len(full.split()) >= 4):
                return True
            if len(words) >= self.ngram and any(
                " ".join(words[i : i + self.ngram]) in self.grams for i in range(len(words) - self.ngram + 1)
            ):
                return True
        return False


def _is_validation(record: DataRecord, options: PrepareOptions) -> bool:
    if options.val_fraction <= 0:
        return False
    key = f"{options.seed}:{record.group or record.id}"
    bucket = int.from_bytes(hashlib.sha256(key.encode("utf-8")).digest()[:8], "big") / 2**64
    return bucket < options.val_fraction


def prepare(records: list[DataRecord], options: PrepareOptions | None = None, *, eval_suite: Suite | None = None) -> PrepareResult:
    options = options or PrepareOptions()
    options.validate()
    result = PrepareResult()
    reject = lambda rid, why: result.rejected.append((rid, why))  # noqa: E731

    index = _ContaminationIndex(eval_suite, options.contamination_ngram) if eval_suite else None
    if eval_suite is not None:
        result.contamination_checked = True
        result.suite_sha256 = eval_suite.sha256
    else:
        result.warnings.append(
            "Aucune suite d'évaluation fournie : contamination NON vérifiée. Un entraînement sur ces données serait refusé par le plan."
        )

    exact_seen: dict[str, str] = {}
    near: list[tuple[str, set[str]]] = []
    buckets: dict[tuple[int, tuple[int, ...]], list[int]] = {}

    for record in records:
        if record.origin == "user_conversation" and not options.allow_user_conversations:
            reject(record.id, "conversation d'utilisateur non autorisée (option explicite requise)")
            continue
        problem = _quality_problem(record, options)
        if problem:
            reject(record.id, problem)
            continue

        cleaned = []
        found = Counter()
        for turn in record.messages:
            text, report = scrub(turn.content)
            found.update(report.counts)
            cleaned.append(DataTurn(role=turn.role, content=text))
        if found and options.pii_mode == "reject":
            reject(record.id, "données personnelles détectées")
            continue
        record = record.model_copy(update={"messages": cleaned})
        if _quality_problem(record, options):  # un masquage ne doit pas laisser une réponse vide
            reject(record.id, "réponse vide après masquage")
            continue

        if index is not None and index.hit(record):
            reject(record.id, "contamination : recoupe la suite d'évaluation")
            continue

        digest = hashlib.sha256(normalize(_conversation_text(record)).encode("utf-8")).hexdigest()
        if digest in exact_seen:
            reject(record.id, f"doublon exact de {exact_seen[digest]}")
            continue
        shingles = _shingles(_words(_conversation_text(record)))
        signature = _minhash(shingles)
        duplicate_of = None
        if signature:
            candidates = set()
            for band in range(0, len(signature), 2):
                candidates.update(buckets.get((band, signature[band : band + 2]), []))
            for position in sorted(candidates):
                other_id, other_shingles = near[position]
                if _jaccard(shingles, other_shingles) >= options.near_duplicate_threshold:
                    duplicate_of = other_id
                    break
        if duplicate_of:
            reject(record.id, f"quasi-doublon de {duplicate_of}")
            continue
        exact_seen[digest] = record.id
        near.append((record.id, shingles))
        for band in range(0, len(signature), 2):
            buckets.setdefault((band, signature[band : band + 2]), []).append(len(near) - 1)

        result.pii.update(found)
        (result.validation if _is_validation(record, options) else result.train).append(record)

    if options.val_fraction > 0 and not result.validation:
        result.warnings.append("Jeu de validation vide (trop peu de données pour la fraction demandée).")
    if not result.train:
        result.warnings.append("Jeu d'entraînement vide.")
    if result.pii:
        result.warnings.append(
            "Données personnelles masquées par motifs (" + ", ".join(f"{k}: {v}" for k, v in sorted(result.pii.items()))
            + ") ; les noms et adresses ne sont pas détectés : relisez un échantillon."
        )
    return result


# --- sorties ---------------------------------------------------------------------------------------------------


def _jsonl(records: list[DataRecord]) -> str:
    return "".join(json.dumps(r.model_dump(mode="json"), ensure_ascii=False, sort_keys=True) + "\n" for r in records)


def _stats(records: list[DataRecord]) -> dict:
    languages: Counter = Counter()
    for r in records:
        languages[r.lang or (detect_language(r.messages[-1].content)[0] or "indéterminée")] += 1
    return {
        "records": len(records),
        "assistant_chars": sum(len(r.messages[-1].content) for r in records),
        "turns_per_record_max": max((len(r.messages) for r in records), default=0),
        "languages": dict(sorted(languages.items())),
        "origins": dict(sorted(Counter(r.origin for r in records).items())),
        "sources": dict(sorted(Counter(r.source for r in records).items())),
        "licenses": dict(sorted(Counter(r.license for r in records).items())),
    }


def write_outputs(result: PrepareResult, out_dir: Path, options: PrepareOptions, *, input_files: list[Path]) -> dict:
    """Écrit train.jsonl, validation.jsonl, rejected.jsonl (id + raison, sans contenu) et manifest.json."""
    if (out_dir / "manifest.json").exists():
        raise ConfigurationError(f"{out_dir} contient déjà un jeu préparé : choisissez un autre dossier (rien n'est écrasé).")
    out_dir.mkdir(parents=True, exist_ok=True)
    files = {
        "train.jsonl": _jsonl(result.train),
        "validation.jsonl": _jsonl(result.validation),
        "rejected.jsonl": "".join(json.dumps({"id": i, "reason": r}, ensure_ascii=False) + "\n" for i, r in result.rejected),
    }
    for name, content in files.items():
        (out_dir / name).write_text(content, encoding="utf-8")
    reasons = Counter(re.sub(r" de .*$", "", reason) for _id, reason in result.rejected)
    manifest = {
        "format": MANIFEST_FORMAT,
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "edgia_core_version": __version__,
        "inputs": [{"name": f.name, "sha256": hashlib.sha256(f.read_bytes()).hexdigest()} for f in input_files],
        "options": {k: getattr(options, k) for k in options.__dataclass_fields__},
        "contamination_checked": result.contamination_checked,
        "eval_suite_sha256": result.suite_sha256,
        "files": {name: hashlib.sha256(content.encode("utf-8")).hexdigest() for name, content in files.items()},
        "train": _stats(result.train),
        "validation": _stats(result.validation),
        "rejected": {"total": len(result.rejected), "by_reason": dict(sorted(reasons.items()))},
        "pii_masked": dict(sorted(result.pii.items())),
        "warnings": result.warnings,
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest
