"""Configuration d'un entraînement d'adaptation LoRA. Rien n'est lancé ici : ce module décrit et valide."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from edgia_core.errors import ConfigurationError, format_validation_error


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class LoraSettings(_Strict):
    r: int = Field(default=16, ge=1, le=256)
    alpha: int = Field(default=32, ge=1, le=512)
    dropout: float = Field(default=0.05, ge=0, lt=1)
    # « all-linear » laisse la bibliothèque choisir ; sinon une liste de noms de modules propres à l'architecture.
    target_modules: list[str] | Literal["all-linear"] = "all-linear"


class TrainingConfig(_Strict):
    base_descriptor: Path = Field(description="Descripteur YAML du modèle de base (licence vérifiée, poids présents)")
    dataset_dir: Path = Field(description="Dossier produit par `edgia-core data prepare` (avec manifest.json)")
    output_dir: Path = Field(description="Dossier de sortie (doit être vide ou absent)")
    method: Literal["lora"] = "lora"  # « qlora » (4 bits) n'est pas pris en charge dans cette version
    lora: LoraSettings = LoraSettings()
    learning_rate: float = Field(default=1e-4, gt=0, le=1e-2)
    epochs: int = Field(default=2, ge=1, le=10)
    per_device_batch_size: int = Field(default=1, ge=1, le=64)
    gradient_accumulation_steps: int = Field(default=16, ge=1, le=512)
    max_seq_len: int = Field(default=2048, ge=64, le=131072)
    warmup_ratio: float = Field(default=0.03, ge=0, le=0.5)
    weight_decay: float = Field(default=0.0, ge=0, le=1)
    max_grad_norm: float = Field(default=1.0, gt=0)
    bf16: bool = True
    seed: int = 0
    min_train_records: int = Field(default=100, ge=1, description="Moins d'exemples : l'entraînement est refusé")

    @model_validator(mode="after")
    def _check(self) -> TrainingConfig:
        if self.lora.alpha < self.lora.r // 4:
            raise ValueError("lora.alpha très inférieur à lora.r : réglage incohérent")
        return self


def load_training_config(path: Path | str) -> TrainingConfig:
    file = Path(path)
    try:
        raw = yaml.safe_load(file.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ConfigurationError(f"Configuration d'entraînement illisible : {file} ({type(exc).__name__})") from None
    except yaml.YAMLError:
        raise ConfigurationError(f"{file.name} : YAML invalide") from None
    if not isinstance(raw, dict):
        raise ConfigurationError(f"{file.name} : un objet YAML est attendu")
    for key in ("base_descriptor", "dataset_dir", "output_dir"):
        if isinstance(raw.get(key), str):
            raw[key] = str((file.parent / raw[key]).resolve()) if not Path(raw[key]).is_absolute() else raw[key]
    try:
        return TrainingConfig.model_validate(raw)
    except ValidationError as exc:
        raise ConfigurationError(format_validation_error(exc, prefix=f"{file.name} : ")) from None
