"""Plan d'entraînement « à blanc » : vérifie tout ce qui peut l'être AVANT de dépenser du calcul.

Le plan refuse (`ok = False`) si : licence du modèle de base non vérifiée ou sans usage commercial, poids absents ou
corrompus, jeu de données non préparé, fichiers du jeu modifiés depuis la préparation, contamination avec la suite
d'évaluation NON vérifiée, trop peu d'exemples, dossier de sortie non vide, dépendances absentes.
Les estimations (étapes, mémoire) sont grossières et le disent.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import math
from dataclasses import dataclass, field
from pathlib import Path

from edgia_core.errors import ConfigurationError
from edgia_core.model.descriptor import ModelDescriptor, check_model, load_descriptor
from edgia_core.training.config import TrainingConfig
from edgia_core.training.prepare import MANIFEST_FORMAT

REQUIRED_MODULES = ("torch", "transformers", "peft")
CHARS_PER_TOKEN = 3.5  # approximation pour du français ; le vrai décompte vient du tokenizer


@dataclass
class TrainingPlan:
    ok: bool = False
    problems: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    descriptor: ModelDescriptor | None = None
    manifest: dict | None = None
    summary: dict = field(default_factory=dict)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _weights_bytes(descriptor: ModelDescriptor) -> int:
    path = descriptor.weights_path
    if path.is_file():
        return path.stat().st_size
    return sum(f.stat().st_size for f in path.glob("*.safetensors")) if path.is_dir() else 0


def _check_dataset(config: TrainingConfig, plan: TrainingPlan) -> None:
    manifest_path = config.dataset_dir / "manifest.json"
    if not manifest_path.is_file():
        plan.problems.append(f"Jeu de données non préparé : {manifest_path} introuvable (lancez `edgia-core data prepare`).")
        return
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("format") != MANIFEST_FORMAT:
            raise ValueError
        declared = manifest["files"]
        train_records = manifest["train"]["records"]
    except (ValueError, KeyError, TypeError):
        plan.problems.append("manifest.json illisible ou d'un format inconnu.")
        return
    plan.manifest = manifest
    for name, expected in declared.items():
        target = config.dataset_dir / name
        if not target.is_file():
            plan.problems.append(f"Fichier du jeu de données manquant : {name}")
        elif _sha256(target) != expected:
            plan.problems.append(f"« {name} » a été modifié depuis la préparation (somme SHA-256 différente) : relancez la préparation.")
    if not manifest.get("contamination_checked"):
        plan.problems.append(
            "Contamination avec la suite d'évaluation NON vérifiée : refaites la préparation avec --eval-suite. "
            "Entraîner sur des cas d'évaluation rendrait toute comparaison sans valeur."
        )
    if train_records < config.min_train_records:
        plan.problems.append(f"Trop peu d'exemples d'entraînement : {train_records} (minimum configuré : {config.min_train_records}).")
    if manifest.get("options", {}).get("allow_user_conversations"):
        plan.warnings.append("Le jeu contient potentiellement des conversations d'utilisateurs : vérifiez consentements et droits avant d'entraîner.")
    plan.warnings.extend(manifest.get("warnings", []))


def build_plan(config: TrainingConfig) -> TrainingPlan:
    plan = TrainingPlan()

    try:
        plan.descriptor = load_descriptor(config.base_descriptor)
    except ConfigurationError as exc:
        plan.problems.extend(exc.problems)
    if plan.descriptor is not None:
        problems, warnings = check_model(plan.descriptor)
        plan.problems.extend(f"Modèle de base : {p}" for p in problems)
        plan.warnings.extend(f"Modèle de base : {w}" for w in warnings)
        if plan.descriptor.adaptation.method.value != "none":
            plan.problems.append("Le modèle de base est déjà un modèle adapté : indiquez le modèle de base d'origine.")

    _check_dataset(config, plan)

    if config.output_dir.exists() and any(config.output_dir.iterdir()):
        plan.problems.append(f"Le dossier de sortie n'est pas vide : {config.output_dir} (rien n'est écrasé).")
    for module in REQUIRED_MODULES:
        if importlib.util.find_spec(module) is None:
            plan.problems.append(f"Dépendance absente : « {module} » (pip install torch transformers peft).")

    summary: dict = {"method": config.method, "epochs": config.epochs, "effective_batch": config.per_device_batch_size * config.gradient_accumulation_steps}
    if plan.manifest:
        train = plan.manifest["train"]
        records = train["records"]
        tokens = int(train["assistant_chars"] / CHARS_PER_TOKEN)
        steps_per_epoch = math.ceil(records / summary["effective_batch"]) if records else 0
        summary.update(
            train_records=records,
            validation_records=plan.manifest["validation"]["records"],
            assistant_tokens_estimate=tokens,
            optimizer_steps=steps_per_epoch * config.epochs,
        )
    if plan.descriptor is not None and plan.descriptor.weights_path.exists():
        weights_gb = _weights_bytes(plan.descriptor) / 1e9
        summary["weights_gb"] = round(weights_gb, 1)
        summary["vram_gb_rough_estimate"] = round(weights_gb * 1.25 + 4, 1)
        plan.warnings.append(
            "Estimation mémoire GROSSIÈRE (poids × 1,25 + 4 Go) : elle dépend de la longueur des séquences et des activations. "
            "Mesurez sur un petit essai avant un long entraînement."
        )
    summary["cost_notice"] = (
        "Un entraînement consomme du calcul payant et peut durer des heures. Il n'est lancé que sur confirmation explicite "
        "(--confirm-training) ; il n'a JAMAIS été exécuté avec de vraies bibliothèques dans ce projet."
    )
    plan.summary = summary
    plan.ok = not plan.problems
    return plan
