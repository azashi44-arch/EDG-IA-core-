"""Phase 4 : préparation des données (data, pii, prepare) et adaptation SFT/LoRA (config, plan, sft)."""
