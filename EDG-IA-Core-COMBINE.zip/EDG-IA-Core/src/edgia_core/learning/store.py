"""Apprentissage par le chat : leçons proposées par des utilisateurs, conservées EN ATTENTE de validation humaine.

Deux sortes de leçons, deux destins différents (voir docs/LEARNING.md) :

- ``fact``    : une information (« La capitale politique du Cameroun est Yaoundé »). Une fois validée, elle est indexée dans
                la base documentaire (collection ``appris-chat``) et sert aussitôt aux réponses, comme n'importe quel document.
                Les poids du modèle ne changent PAS.
- ``example`` : une conversation corrigée (questions de l'utilisateur, réponse que l'assistant aurait dû donner). Une fois
                validée, elle peut être exportée en JSONL pour ``edgia-core data prepare``. Rien n'entraîne le modèle
                automatiquement : l'entraînement reste une décision humaine distincte (plan, évaluation, approbation).

Règles :
- le consentement explicite est obligatoire et inscrit dans la donnée ;
- les données personnelles évidentes sont masquées à l'entrée (motifs : voir ``training/pii.py``, noms et adresses non détectés) ;
- une leçon proposée est « en attente » : jamais utilisée avant validation, sauf choix explicite de l'opérateur (faits seulement) ;
- l'auteur (la clé d'API, ``key-1``…) peut retirer sa leçon ; les erreurs ne recopient jamais le contenu.

Ce module n'utilise que la bibliothèque standard (et le masquage de données personnelles du projet).
"""

from __future__ import annotations

import hashlib
import json
import re
import secrets
import sqlite3
import threading
import time
import unicodedata
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

from edgia_core.errors import EdgiaError
from edgia_core.training.pii import scrub

SCHEMA_VERSION = 1
KINDS = ("fact", "example")
STATUSES = ("pending", "approved", "rejected")
MIN_FACT_CHARS = 10
MAX_FACT_CHARS = 2000
MAX_EXAMPLE_TURNS = 12
MAX_TURN_CHARS = 4000
MAX_NOTE_CHARS = 500
DEFAULT_MAX_PENDING_PER_KEY = 50
LESSON_ID_RE = re.compile(r"^les-[0-9a-f]{12}$")
_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

_SCHEMA = f"""
PRAGMA user_version = {SCHEMA_VERSION};
CREATE TABLE IF NOT EXISTS lessons (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL CHECK (kind IN ('fact', 'example')),
    content TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'rejected')),
    key_id TEXT NOT NULL,
    consent INTEGER NOT NULL CHECK (consent = 1),
    pii_redactions INTEGER NOT NULL DEFAULT 0,
    sha256 TEXT NOT NULL UNIQUE,
    created_at REAL NOT NULL,
    reviewed_at REAL,
    reviewer_note TEXT NOT NULL DEFAULT '',
    doc_id TEXT
);
CREATE INDEX IF NOT EXISTS lessons_status ON lessons(status);
CREATE INDEX IF NOT EXISTS lessons_key ON lessons(key_id);
"""


class LearningError(EdgiaError):
    """Opération refusée. `code` est stable (utilisé par l'API) ; le message ne contient jamais le contenu d'une leçon."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass(frozen=True)
class Lesson:
    id: str
    kind: str
    content: str
    status: str
    key_id: str
    pii_redactions: int
    created_at: float
    reviewed_at: float | None
    reviewer_note: str
    doc_id: str | None

    @property
    def messages(self) -> list[dict[str, str]]:
        """Conversation d'une leçon `example` (liste vide pour un fait)."""
        return json.loads(self.content) if self.kind == "example" else []


def _fold(text: str) -> str:
    decomposed = unicodedata.normalize("NFKD", text)
    stripped = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return re.sub(r"\s+", " ", stripped).lower().strip()


def _clean(text: object, label: str, max_chars: int) -> str:
    if not isinstance(text, str):
        raise LearningError("lesson_invalid", f"{label} : du texte est attendu.")
    text = text.replace("\r\n", "\n").strip()
    if not text:
        raise LearningError("lesson_invalid", f"{label} : texte vide.")
    if len(text) > max_chars:
        raise LearningError("lesson_invalid", f"{label} : trop long (limite : {max_chars} caractères).")
    if _CONTROL_RE.search(text):
        raise LearningError("lesson_invalid", f"{label} : caractères de contrôle interdits.")
    return text


def _validate_turns(messages: object) -> list[dict[str, str]]:
    """Conversation alternée utilisateur → assistant, terminée par la réponse attendue. Le rôle « system » est refusé."""
    if not isinstance(messages, list) or not 2 <= len(messages) <= MAX_EXAMPLE_TURNS or len(messages) % 2:
        raise LearningError(
            "lesson_invalid",
            f"Un exemple contient un nombre pair de messages, de 2 à {MAX_EXAMPLE_TURNS} (utilisateur puis assistant, en alternance).",
        )
    turns: list[dict[str, str]] = []
    for index, message in enumerate(messages):
        expected = "user" if index % 2 == 0 else "assistant"
        if not isinstance(message, dict) or set(message) != {"role", "content"} or message["role"] != expected:
            raise LearningError("lesson_invalid", "Les messages d'un exemple alternent « user » et « assistant » et se terminent par « assistant ».")
        turns.append({"role": expected, "content": _clean(message["content"], "message", MAX_TURN_CHARS)})
    return turns


class LearningStore:
    def __init__(self, path: Path | str, *, max_pending_per_key: int = DEFAULT_MAX_PENDING_PER_KEY) -> None:
        if max_pending_per_key < 1:
            raise ValueError("max_pending_per_key >= 1 est requis")
        self._path = str(path)
        self._max_pending = max_pending_per_key
        self._lock = threading.RLock()
        self._memory: sqlite3.Connection | None = None
        if self._path != ":memory:":
            Path(self._path).parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as connection:
            connection.executescript(_SCHEMA)

    def close(self) -> None:
        with self._lock:
            if self._memory is not None:
                self._memory.close()
                self._memory = None

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            if self._path == ":memory:":
                if self._memory is None:
                    self._memory = sqlite3.connect(":memory:", check_same_thread=False)
                connection = self._memory
            else:
                connection = sqlite3.connect(self._path, timeout=10)
            try:
                with connection:
                    yield connection
            finally:
                if self._path != ":memory:":
                    connection.close()

    # --- écriture --------------------------------------------------------------------------------------------

    def submit(
        self,
        kind: str,
        *,
        text: str | None = None,
        messages: list[dict[str, str]] | None = None,
        key_id: str,
        consent: bool,
    ) -> Lesson:
        """Enregistre une leçon EN ATTENTE. Le consentement doit être exactement `True`."""
        if consent is not True:
            raise LearningError(
                "consent_required",
                "Le consentement explicite est obligatoire (consent: true) : la leçon sera relue par un humain et peut servir à améliorer l'assistant.",
            )
        if kind == "fact":
            if messages is not None:
                raise LearningError("lesson_invalid", "Un fait se donne avec « text », pas avec « messages ».")
            body = _clean(text, "fait", MAX_FACT_CHARS)
            if len(body) < MIN_FACT_CHARS:
                raise LearningError("lesson_invalid", f"fait : au moins {MIN_FACT_CHARS} caractères.")
            content, report = scrub(body)
        elif kind == "example":
            if text is not None:
                raise LearningError("lesson_invalid", "Un exemple se donne avec « messages », pas avec « text ».")
            turns = _validate_turns(messages)
            redactions = 0
            cleaned: list[dict[str, str]] = []
            for turn in turns:
                masked, turn_report = scrub(turn["content"])
                redactions += turn_report.total
                cleaned.append({"role": turn["role"], "content": masked})
            content = json.dumps(cleaned, ensure_ascii=False)
            report = None
        else:
            raise LearningError("lesson_invalid", "Type de leçon inconnu (« fact » ou « example »).")
        pii = report.total if report is not None else redactions
        digest = hashlib.sha256(f"{kind}\0{_fold(content)}".encode("utf-8")).hexdigest()

        with self._connect() as connection:
            pending = connection.execute(
                "SELECT COUNT(*) FROM lessons WHERE key_id = ? AND status = 'pending'", (key_id,)
            ).fetchone()[0]
            if pending >= self._max_pending:
                raise LearningError(
                    "lesson_quota_exceeded",
                    f"Trop de leçons en attente de relecture pour cette clé (limite : {self._max_pending}).",
                )
            if connection.execute("SELECT 1 FROM lessons WHERE sha256 = ?", (digest,)).fetchone():
                raise LearningError("lesson_duplicate", "Cette leçon existe déjà.")
            lesson_id = "les-" + secrets.token_hex(6)
            connection.execute(
                "INSERT INTO lessons (id, kind, content, status, key_id, consent, pii_redactions, sha256, created_at) "
                "VALUES (?, ?, ?, 'pending', ?, 1, ?, ?, ?)",
                (lesson_id, kind, content, key_id, pii, digest, time.time()),
            )
        return self.get(lesson_id)

    def review(self, lesson_id: str, *, approve: bool, note: str = "", doc_id: str | None = None) -> Lesson:
        """Valide ou rejette une leçon EN ATTENTE (une leçon déjà traitée ne change plus)."""
        note = note.strip()
        if len(note) > MAX_NOTE_CHARS or _CONTROL_RE.search(note):
            raise LearningError("lesson_invalid", f"Note de relecture invalide (texte de {MAX_NOTE_CHARS} caractères au plus).")
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE lessons SET status = ?, reviewed_at = ?, reviewer_note = ?, doc_id = ? "
                "WHERE id = ? AND status = 'pending'",
                ("approved" if approve else "rejected", time.time(), note, doc_id, lesson_id),
            )
            if cursor.rowcount == 0:
                exists = connection.execute("SELECT 1 FROM lessons WHERE id = ?", (lesson_id,)).fetchone()
                if not exists:
                    raise LearningError("lesson_not_found", "Leçon introuvable.")
                raise LearningError("lesson_state", "Seule une leçon en attente peut être validée ou rejetée.")
        return self.get(lesson_id)

    def delete(self, lesson_id: str, *, key_id: str | None = None) -> Lesson:
        """Supprime une leçon (retrait du consentement). Avec `key_id`, seule la clé auteur peut la supprimer."""
        lesson = self.get(lesson_id, key_id=key_id)
        with self._connect() as connection:
            connection.execute("DELETE FROM lessons WHERE id = ?", (lesson_id,))
        return lesson

    # --- lecture ---------------------------------------------------------------------------------------------

    _COLUMNS = "id, kind, content, status, key_id, pii_redactions, created_at, reviewed_at, reviewer_note, doc_id"

    def get(self, lesson_id: str, *, key_id: str | None = None) -> Lesson:
        """Avec `key_id`, une leçon d'un autre auteur est « introuvable » (on ne révèle pas son existence)."""
        sql = f"SELECT {self._COLUMNS} FROM lessons WHERE id = ?" + (" AND key_id = ?" if key_id is not None else "")
        params: tuple[str, ...] = (lesson_id,) if key_id is None else (lesson_id, key_id)
        with self._connect() as connection:
            row = connection.execute(sql, params).fetchone()
        if row is None:
            raise LearningError("lesson_not_found", "Leçon introuvable.")
        return Lesson(*row)

    def list_lessons(
        self, *, status: str | None = None, key_id: str | None = None, kind: str | None = None, limit: int = 100
    ) -> list[Lesson]:
        if status is not None and status not in STATUSES:
            raise LearningError("lesson_invalid", "Statut inconnu (pending, approved ou rejected).")
        if kind is not None and kind not in KINDS:
            raise LearningError("lesson_invalid", "Type de leçon inconnu (« fact » ou « example »).")
        if not 1 <= limit <= 100_000:
            raise LearningError("lesson_invalid", "limit doit être compris entre 1 et 100000.")
        clauses, params = [], []
        for column, value in (("status", status), ("key_id", key_id), ("kind", kind)):
            if value is not None:
                clauses.append(f"{column} = ?")
                params.append(value)
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        with self._connect() as connection:
            rows = connection.execute(
                f"SELECT {self._COLUMNS} FROM lessons{where} ORDER BY created_at, id LIMIT ?", (*params, limit)
            ).fetchall()
        return [Lesson(*row) for row in rows]

    def stats(self) -> dict:
        with self._connect() as connection:
            rows = connection.execute("SELECT kind, status, COUNT(*) FROM lessons GROUP BY kind, status").fetchall()
        counts: dict[str, dict[str, int]] = {kind: {status: 0 for status in STATUSES} for kind in KINDS}
        for kind, status, count in rows:
            counts[kind][status] = count
        return {"lessons": sum(c for by_status in counts.values() for c in by_status.values()), "by_kind": counts}
