"""Lecture et écriture du format `safetensors`, sans dépendance et SANS pickle.

Format (https://github.com/huggingface/safetensors) : 8 octets (entier petit-boutiste N), N octets d'en-tête JSON
(complété d'espaces pour que 8+N soit multiple de 8), puis les données brutes. L'en-tête décrit pour chaque tenseur
`dtype`, `shape` et `data_offsets` (relatifs au début des données).

Pourquoi un module maison : Core refuse tout format pickle, et ce module doit fonctionner sans `safetensors` ni
PyTorch (tests, outils). LIMITE : la compatibilité avec la bibliothèque officielle est construite d'après la
spécification publique ; un test croisé (`tests/native/test_safetensors_official.py`) la vérifie dès que la
bibliothèque officielle est installée.

Lecture défensive : taille d'en-tête bornée, décalages contigus sans chevauchement, tailles cohérentes avec la forme,
longueur de fichier exacte.
"""

from __future__ import annotations

import json
import os
from collections.abc import Mapping
from pathlib import Path
from typing import NamedTuple

import numpy as np

from edgia_core.native.errors import FormatError

MAX_HEADER_BYTES = 100_000_000

_DTYPE_SIZE = {
    "F64": 8, "F32": 4, "F16": 2, "BF16": 2,
    "I64": 8, "I32": 4, "I16": 2, "I8": 1,
    "U64": 8, "U32": 4, "U16": 2, "U8": 1, "BOOL": 1,
}
_NUMPY_TO_ST = {
    np.dtype("float64"): "F64", np.dtype("float32"): "F32", np.dtype("float16"): "F16",
    np.dtype("int64"): "I64", np.dtype("int32"): "I32", np.dtype("int16"): "I16", np.dtype("int8"): "I8",
    np.dtype("uint64"): "U64", np.dtype("uint32"): "U32", np.dtype("uint16"): "U16", np.dtype("uint8"): "U8",
    np.dtype("bool"): "BOOL",
}
_ST_TO_NUMPY = {v: k for k, v in _NUMPY_TO_ST.items()}


class RawTensor(NamedTuple):
    """Tenseur déjà sérialisé (utile pour BF16, qui n'existe pas dans NumPy)."""

    dtype: str
    shape: tuple[int, ...]
    data: bytes


def _item_count(shape: tuple[int, ...]) -> int:
    count = 1
    for dim in shape:
        count *= dim
    return count


def _as_raw(name: str, value: np.ndarray | RawTensor) -> RawTensor:
    if isinstance(value, RawTensor):
        if value.dtype not in _DTYPE_SIZE:
            raise FormatError(f"{name} : dtype safetensors inconnu « {value.dtype} »")
        if _item_count(tuple(value.shape)) * _DTYPE_SIZE[value.dtype] != len(value.data):
            raise FormatError(f"{name} : taille des données incohérente avec la forme")
        return RawTensor(value.dtype, tuple(int(x) for x in value.shape), bytes(value.data))
    array = np.asarray(value)
    if array.dtype not in _NUMPY_TO_ST:
        raise FormatError(f"{name} : dtype NumPy non pris en charge ({array.dtype})")
    little = np.ascontiguousarray(array).astype(array.dtype.newbyteorder("<"), copy=False)
    return RawTensor(_NUMPY_TO_ST[array.dtype], tuple(int(x) for x in array.shape), little.tobytes(order="C"))


def serialize(tensors: Mapping[str, np.ndarray | RawTensor], metadata: Mapping[str, str] | None = None) -> bytes:
    """Octets d'un fichier safetensors. Tenseurs triés par nom : sortie déterministe."""
    header: dict[str, object] = {}
    if metadata:
        for key, value in metadata.items():
            if not isinstance(key, str) or not isinstance(value, str):
                raise FormatError("les métadonnées safetensors doivent être des chaînes")
        header["__metadata__"] = dict(metadata)
    chunks: list[bytes] = []
    offset = 0
    for name in sorted(tensors):
        if name == "__metadata__":
            raise FormatError("nom de tenseur réservé : __metadata__")
        raw = _as_raw(name, tensors[name])
        header[name] = {"dtype": raw.dtype, "shape": list(raw.shape), "data_offsets": [offset, offset + len(raw.data)]}
        chunks.append(raw.data)
        offset += len(raw.data)
    blob = json.dumps(header, separators=(",", ":"), ensure_ascii=True).encode("ascii")
    blob += b" " * ((-len(blob)) % 8)
    return len(blob).to_bytes(8, "little") + blob + b"".join(chunks)


def save(path: str | Path, tensors: Mapping[str, np.ndarray | RawTensor], metadata: Mapping[str, str] | None = None) -> None:
    """Écrit le fichier de façon atomique (fichier temporaire, fsync, renommage)."""
    target = Path(path)
    payload = serialize(tensors, metadata)
    tmp = target.with_name(target.name + ".tmp")
    with tmp.open("wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, target)


class TensorEntry(NamedTuple):
    dtype: str
    shape: tuple[int, ...]
    begin: int
    end: int


def parse(buffer: bytes) -> tuple[dict[str, TensorEntry], dict[str, str], int]:
    """Valide l'en-tête et retourne (entrées, métadonnées, début des données)."""
    if len(buffer) < 8:
        raise FormatError("fichier trop court pour un en-tête safetensors")
    header_len = int.from_bytes(buffer[:8], "little")
    if header_len > MAX_HEADER_BYTES:
        raise FormatError("en-tête safetensors trop grand")
    if 8 + header_len > len(buffer):
        raise FormatError("en-tête safetensors tronqué")
    raw_header = buffer[8 : 8 + header_len]
    if not raw_header.startswith(b"{"):
        raise FormatError("l'en-tête safetensors doit commencer par « { »")
    try:
        header = json.loads(raw_header.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise FormatError("en-tête safetensors illisible") from exc
    if not isinstance(header, dict):
        raise FormatError("en-tête safetensors invalide")
    metadata = header.pop("__metadata__", {}) or {}
    if not isinstance(metadata, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in metadata.items()):
        raise FormatError("métadonnées safetensors invalides")
    data_start = 8 + header_len
    data_size = len(buffer) - data_start
    entries: dict[str, TensorEntry] = {}
    for name, spec in header.items():
        if not isinstance(spec, dict) or set(spec) != {"dtype", "shape", "data_offsets"}:
            raise FormatError(f"{name} : entrée d'en-tête invalide")
        dtype, shape, offsets = spec["dtype"], spec["shape"], spec["data_offsets"]
        if dtype not in _DTYPE_SIZE:
            raise FormatError(f"{name} : dtype inconnu")
        if not (isinstance(shape, list) and all(isinstance(x, int) and not isinstance(x, bool) and x >= 0 for x in shape)):
            raise FormatError(f"{name} : forme invalide")
        if not (isinstance(offsets, list) and len(offsets) == 2 and all(isinstance(x, int) and not isinstance(x, bool) for x in offsets)):
            raise FormatError(f"{name} : décalages invalides")
        begin, end = offsets
        if begin < 0 or end < begin or end > data_size:
            raise FormatError(f"{name} : décalages hors du fichier")
        if _item_count(tuple(shape)) * _DTYPE_SIZE[dtype] != end - begin:
            raise FormatError(f"{name} : taille incohérente avec la forme")
        entries[name] = TensorEntry(dtype, tuple(shape), begin, end)
    cursor = 0
    for name, entry in sorted(entries.items(), key=lambda item: (item[1].begin, item[1].end)):
        if entry.begin != cursor:
            raise FormatError(f"{name} : trou ou chevauchement dans les données")
        cursor = entry.end
    if cursor != data_size:
        raise FormatError("octets en trop après le dernier tenseur")
    return entries, dict(metadata), data_start


def read_raw(path: str | Path) -> tuple[dict[str, RawTensor], dict[str, str]]:
    buffer = Path(path).read_bytes()
    entries, metadata, start = parse(buffer)
    return {n: RawTensor(e.dtype, e.shape, buffer[start + e.begin : start + e.end]) for n, e in entries.items()}, metadata


def read_metadata(path: str | Path) -> dict[str, str]:
    return read_raw(path)[1]


def load_numpy(path: str | Path, *, allow_bf16_as_uint16: bool = False) -> tuple[dict[str, np.ndarray], dict[str, str]]:
    """Charge les tenseurs en tableaux NumPy (copie inscriptible). BF16 n'existe pas dans NumPy : refusé par défaut."""
    raw, metadata = read_raw(path)
    out: dict[str, np.ndarray] = {}
    for name, tensor in raw.items():
        if tensor.dtype == "BF16":
            if not allow_bf16_as_uint16:
                raise FormatError(f"{name} : BF16 non représentable en NumPy (utiliser allow_bf16_as_uint16)")
            np_dtype = np.dtype("<u2")
        else:
            np_dtype = _ST_TO_NUMPY[tensor.dtype].newbyteorder("<")
        out[name] = np.frombuffer(tensor.data, dtype=np_dtype).reshape(tensor.shape).astype(np_dtype.newbyteorder("="), copy=True)
    return out, metadata
