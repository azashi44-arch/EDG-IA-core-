"""Backend natif de Core : sert un export EDG-IA Native (`export_model`) derrière le contrat `Backend` existant.

ÉTAT : CODÉ ; la boucle de génération (`generation.py`) est testée avec la référence NumPy, mais ce module (PyTorch + Core)
n'a PAS été exécuté dans l'environnement de développement de L0 (PyTorch, pydantic et starlette y sont absents).
Garde-fous : export vérifié (SHA-256, formes, verrou des identifiants) ; modèle NON ENTRAÎNÉ refusé sauf
`EDGIA_ALLOW_UNTRAINED=true` ; chargement strictement local ; aucune lecture pickle ; générations sérialisées ;
identifiants spéciaux jamais produits. Ce module n'est importé que lorsque le runtime `edgia_native` est choisi :
un serveur en mode démo ou Transformers n'exige ni PyTorch ni ce code.
"""

from __future__ import annotations

import json
import os
import threading
from collections.abc import Iterator, Sequence
from pathlib import Path
from typing import Any

from edgia_core.errors import ConfigurationError
from edgia_core.inference.base import EngineError, GenerationParams, InferenceEngine, Message, ModelInfo
from edgia_core.inference.llm_engine import Backend, Done, LanguageModelEngine, Piece
from edgia_core.native import safetensors_io as st
from edgia_core.native.config import ModelConfig
from edgia_core.native.errors import ExportError, NativeError
from edgia_core.native.generation import DoneEvent, GenerationParams as NativeParams, PromptTooLong, TextEvent, generate_stream
from edgia_core.native.tokenizer.tokenizer import EdgiaTokenizer
from edgia_core.native.train.export import check_servable, verify_export

RUNTIME_ID = "edgia_native"


def _truthy(value: str | None) -> bool:
    return (value or "").strip().lower() in {"1", "true", "yes", "oui"}


class NativeBackend(Backend):
    def __init__(self, export_dir: Path, *, device: str | None = None, allow_untrained: bool | None = None) -> None:
        try:
            import torch
        except ImportError as exc:
            raise ConfigurationError(
                "Dépendance absente : « torch ». Installez-la (pip install -e .[native]) ; EDG-IA Core ne télécharge rien automatiquement."
            ) from exc
        from edgia_core.native.model import EdgiaModel, KVCache

        self._torch, self._KVCache = torch, KVCache
        self._lock = threading.Lock()
        root = Path(export_dir)
        problems = verify_export(root)
        if problems:
            raise ConfigurationError("Export EDG-IA Native invalide : " + " ; ".join(problems[:3]))
        self.config: dict[str, Any] = json.loads((root / "config.json").read_text(encoding="utf-8"))
        permit = _truthy(os.environ.get("EDGIA_ALLOW_UNTRAINED")) if allow_untrained is None else allow_untrained
        try:
            check_servable(self.config, allow_untrained=permit)
        except ExportError as exc:
            raise ConfigurationError(str(exc)) from None
        self.status: str = self.config["training_status"]
        self._cfg = ModelConfig.from_dict(self.config["model"])
        self._tokenizer = EdgiaTokenizer.load(root)
        tensors, _ = st.load_numpy(root / "model.safetensors")
        requested = device or os.environ.get("EDGIA_NATIVE_DEVICE", "cpu")
        if requested == "auto":
            requested = "cuda" if torch.cuda.is_available() else "cpu"
        if requested.startswith("cuda") and not torch.cuda.is_available():
            raise ConfigurationError("EDGIA_NATIVE_DEVICE demande CUDA mais aucun GPU n'est disponible.")
        self._device = requested
        self._model = EdgiaModel(self._cfg, init=False)
        self._model.load_tensors(tensors)  # chargement strict : noms et formes
        self._model.to(self._device).eval()

    @property
    def max_seq_len(self) -> int:
        return self._cfg.max_seq_len

    def count_prompt_tokens(self, messages: Sequence[Message]) -> int:
        return len(self._tokenizer.encode_chat(messages))

    def stream(self, messages: Sequence[Message], params: GenerationParams, cancel: threading.Event) -> Iterator[Piece | Done]:
        while not self._lock.acquire(timeout=0.1):
            if cancel.is_set():
                return
        try:
            yield from self._generate_locked(messages, params, cancel)
        finally:
            self._lock.release()

    def _generate_locked(self, messages: Sequence[Message], params: GenerationParams, cancel: threading.Event) -> Iterator[Piece | Done]:
        torch = self._torch
        try:
            prompt_ids = self._tokenizer.encode_chat(messages)
        except NativeError as exc:
            raise EngineError(f"Conversation invalide : {exc}") from None
        cache = self._KVCache(self._cfg, 1, self._device, torch.float32)

        def forward(ids: Sequence[int], reset: bool) -> Any:
            if reset:
                cache.reset()
            batch = torch.tensor([list(ids)], dtype=torch.long, device=self._device)
            with torch.no_grad():
                logits = self._model(batch, cache)
            return logits[0, -1].float().cpu().numpy()

        native = NativeParams(max_new_tokens=params.max_tokens, temperature=params.temperature, top_p=params.top_p, seed=None)
        finished = False
        try:
            for event in generate_stream(forward, self._tokenizer, prompt_ids, native, max_seq_len=self._cfg.max_seq_len, cancel=cancel.is_set):
                if isinstance(event, TextEvent):
                    yield Piece(event.text)
                elif isinstance(event, DoneEvent):
                    finished = True
                    yield Done(event.finish_reason, event.completion_tokens)
        except PromptTooLong:
            raise EngineError(f"Le contexte de ce modèle est de {self._cfg.max_seq_len} tokens : la conversation est trop longue.") from None
        except EngineError:
            raise
        except Exception as exc:  # noqa: BLE001 - jamais de contenu de conversation dans le message
            raise EngineError(f"Échec de génération ({type(exc).__name__}).") from None
        if not finished:  # annulation : même convention que le backend Transformers
            yield Done("stop", 0)

    def close(self) -> None:
        self._model = None
        if self._device.startswith("cuda"):
            self._torch.cuda.empty_cache()


def build_native_engine(settings: Any, descriptor: Any) -> InferenceEngine:
    """Appelé par `model.loader.build_engine` pour le runtime `edgia_native` (importé paresseusement)."""
    device = None
    hardware = getattr(descriptor, "hardware", None)
    if hardware is not None and getattr(hardware.device, "value", "auto") in ("cpu", "cuda"):
        device = "cpu" if hardware.device.value == "cpu" else "cuda"
    try:
        backend = NativeBackend(Path(descriptor.weights_path), device=device)
    except ConfigurationError:
        raise
    except Exception as exc:  # noqa: BLE001 - toute erreur de chargement empêche le démarrage
        raise ConfigurationError(f"Chargement du modèle natif impossible ({type(exc).__name__}: {exc})"[:300]) from None
    info = ModelInfo(
        id=descriptor.model_id, version=descriptor.version, runtime=RUNTIME_ID, is_demo=False,
        description=f"{descriptor.display_name} [EDG-IA Native — statut d'entraînement : {backend.status}]",
    )
    return LanguageModelEngine(info, backend)
