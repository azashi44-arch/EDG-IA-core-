"""Registre des sources et portes de validation (spécification v1.1, §5.2).

Porte 1 — admission au corpus (entraînement interne) ; Porte 2 — distribution des poids. Elles sont appliquées PAR LE CODE :
un document dont la source ne passe pas la porte 1 n'entre jamais dans un jeu d'entraînement ; un export ne peut être
marqué « distribuable » que si toutes ses sources passent la porte 2. Ce module ne rend aucun avis juridique : il
vérifie que les validations humaines requises sont enregistrées et cohérentes.
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any

from edgia_core.native.data import licenses
from edgia_core.native.errors import DataError, LicenseError
from edgia_core.native.hashing import sha256_json

DECISIONS_TRAINING = ("pending", "approved_training", "blocked")
DECISIONS_DISTRIBUTION = ("pending", "approved_distribution", "blocked")
PROVENANCE_BASES = ("item_verified", "publisher_claim")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")


@dataclass(frozen=True)
class Source:
    source_id: str
    name: str
    publisher: str
    url: str
    license_id: str
    license_text_sha256: str = ""
    archive_sha256: str = ""
    acquired_at: str = ""
    collection_version: str = ""
    acquisition_method: str = ""
    provenance_basis: str = "item_verified"
    audit_sample_ref: str = ""
    validator: str = ""
    validated_at: str = ""
    decision_training: str = "pending"
    training_review_ref: str = ""
    legal_exception_ref: str = ""
    decision_distribution: str = "pending"
    distribution_review_ref: str = ""
    license_class: str = ""  # facultatif : si renseigné, doit correspondre à la classe calculée
    notes: str = ""
    extra: dict[str, Any] = field(default_factory=dict)

    @property
    def computed_class(self) -> str:
        return licenses.license_class(self.license_id)

    def structural_problems(self) -> list[str]:
        p: list[str] = []
        if not self.source_id or not re.fullmatch(r"[A-Za-z0-9._-]+", self.source_id):
            p.append("source_id invalide")
        if self.decision_training not in DECISIONS_TRAINING:
            p.append("decision_training inconnue")
        if self.decision_distribution not in DECISIONS_DISTRIBUTION:
            p.append("decision_distribution inconnue")
        if self.provenance_basis not in PROVENANCE_BASES:
            p.append("provenance_basis inconnue")
        if self.license_class and self.license_class != self.computed_class:
            p.append(f"license_class déclarée ({self.license_class}) ≠ classe calculée ({self.computed_class})")
        return p

    def training_problems(self) -> list[str]:
        """Porte 1 : liste des raisons de refus (vide = admissible)."""
        p = self.structural_problems()
        cls = self.computed_class
        if self.decision_training != "approved_training":
            p.append("porte 1 non franchie (decision_training ≠ approved_training)")
        if cls in (licenses.CLASS_D, licenses.CLASS_E):
            p.append(f"licence de classe {cls} : exclue")
        if cls == licenses.CLASS_C and not self.legal_exception_ref:
            p.append("classe C : décision juridique écrite requise (legal_exception_ref)")
        if cls == licenses.CLASS_B and not self.training_review_ref:
            p.append("classe B : avis écrit sur l'usage en entraînement requis (training_review_ref)")
        if not self.validator or not self.validated_at:
            p.append("validateur humain et date de validation requis")
        if not _SHA256.fullmatch(self.license_text_sha256):
            p.append("empreinte SHA-256 du texte de licence archivé requise")
        if not _SHA256.fullmatch(self.archive_sha256):
            p.append("empreinte SHA-256 de l'archive acquise requise")
        if not self.url or not self.acquired_at or not self.collection_version:
            p.append("url, acquired_at et collection_version requis")
        if self.provenance_basis == "publisher_claim" and not self.audit_sample_ref:
            p.append("confiance déléguée à l'éditeur : audit d'un échantillon requis (audit_sample_ref)")
        return p

    def distribution_problems(self) -> list[str]:
        """Porte 2 : ce qui manque pour que les poids entraînés sur cette source soient distribuables."""
        p = self.training_problems()
        if self.decision_distribution != "approved_distribution":
            p.append("porte 2 non franchie (decision_distribution ≠ approved_distribution)")
        if not self.distribution_review_ref:
            p.append("avis écrit sur la distribution des poids requis (distribution_review_ref)")
        return p

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class SourceRegistry:
    def __init__(self, sources: list[Source]) -> None:
        self._sources: dict[str, Source] = {}
        for source in sources:
            if source.source_id in self._sources:
                raise DataError(f"source_id dupliqué : {source.source_id}")
            self._sources[source.source_id] = source

    def __contains__(self, source_id: str) -> bool:
        return source_id in self._sources

    def get(self, source_id: str) -> Source:
        try:
            return self._sources[source_id]
        except KeyError:
            raise LicenseError(f"source inconnue du registre : {source_id}") from None

    def sources(self) -> list[Source]:
        return [self._sources[k] for k in sorted(self._sources)]

    def registry_hash(self) -> str:
        return sha256_json([s.to_dict() for s in self.sources()])

    def training_report(self) -> dict[str, list[str]]:
        return {s.source_id: s.training_problems() for s in self.sources()}

    @classmethod
    def from_dicts(cls, raw: list[dict[str, Any]]) -> SourceRegistry:
        known = {f.name for f in fields(Source)}
        sources = []
        for entry in raw:
            unknown = sorted(set(entry) - known)
            if unknown:
                raise DataError(f"champs inconnus dans la source {entry.get('source_id')!r} : {unknown}")
            sources.append(Source(**entry))
        return cls(sources)

    @classmethod
    def load(cls, path: str | Path) -> SourceRegistry:
        file = Path(path)
        try:
            text = file.read_text(encoding="utf-8")
        except OSError as exc:
            raise DataError(f"registre illisible : {file}") from exc
        if file.suffix.lower() == ".json":
            raw = json.loads(text)
        else:
            import yaml

            raw = yaml.safe_load(text)
        entries = raw.get("sources") if isinstance(raw, dict) else raw
        if not isinstance(entries, list):
            raise DataError("le registre doit contenir une liste « sources »")
        return cls.from_dicts(entries)


def gate_document(source_registry: SourceRegistry, source_id: str, doc_license_id: str) -> str | None:
    """Porte 1 appliquée à un document. Retourne None si admis, sinon la raison du refus."""
    if source_id not in source_registry:
        return "source inconnue du registre"
    source = source_registry.get(source_id)
    problems = source.training_problems()
    if problems:
        return "source non admise : " + " ; ".join(problems)
    if licenses.canonical_license_id(doc_license_id) != licenses.canonical_license_id(source.license_id):
        return f"licence du document ({doc_license_id}) ≠ licence enregistrée ({source.license_id})"
    return None
