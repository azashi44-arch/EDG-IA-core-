"""Découpage train / val / test par GROUPE d'œuvres, et contrôle de fuite (spécification v1.1, §5.5).

Tous les membres d'un groupe (copies, éditions, quasi-doublons) vont dans le même jeu. Après découpage, les documents de
`val` et `test` dont une trop grande part des séquences de 13 mots figure dans `train` sont RETIRÉS (journalisés).
"""

from __future__ import annotations

import hashlib
from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field

from edgia_core.native.data.dedup import _hash64
from edgia_core.native.data.text import words
from edgia_core.native.errors import DataError

SPLITS = ("train", "val", "test")
_MOD = 1_000_000


def group_bucket(group_id: str, salt: str) -> int:
    return int(hashlib.sha256((salt + group_id).encode("utf-8")).hexdigest()[:12], 16) % _MOD


def assign_groups(group_ids: Sequence[str], *, val_rate: float, test_rate: float, salt: str) -> tuple[dict[str, str], list[str]]:
    """group_id → split. Si `val` ou `test` est vide alors qu'il y a ≥ 10 groupes, le(s) groupe(s) de plus petit bucket
    sont promus (déterministe ; consigné dans les notes retournées)."""
    if not (0 <= val_rate < 1 and 0 <= test_rate < 1 and val_rate + test_rate < 1):
        raise DataError("taux de découpage invalides")
    unique = sorted(set(group_ids))
    val_cut, test_cut = int(val_rate * _MOD), int((val_rate + test_rate) * _MOD)
    out: dict[str, str] = {}
    for gid in unique:
        bucket = group_bucket(gid, salt)
        out[gid] = "val" if bucket < val_cut else "test" if bucket < test_cut else "train"
    notes: list[str] = []
    if len(unique) >= 10:
        for split, rate in (("val", val_rate), ("test", test_rate)):
            if rate > 0 and split not in out.values():
                candidates = sorted((g for g in unique if out[g] == "train"), key=lambda g: (group_bucket(g, salt), g))
                out[candidates[0]] = split
                notes.append(f"jeu {split} vide : groupe {candidates[0]} promu (plus petit bucket)")
    return out, notes


def ngram_hashes(text: str, n: int) -> set[int]:
    tokens = words(text)
    if len(tokens) < n:
        return {_hash64(" ".join(tokens))} if tokens else set()
    return {_hash64(" ".join(tokens[i : i + n])) for i in range(len(tokens) - n + 1)}


@dataclass
class LeakReport:
    ngram: int
    max_fraction: float
    removed: list[dict[str, object]] = field(default_factory=list)
    checked: int = 0

    def to_dict(self) -> dict[str, object]:
        return {"ngram": self.ngram, "max_fraction": self.max_fraction, "checked": self.checked, "removed": self.removed}


def leak_filter(
    docs: Mapping[str, tuple[str, str]], *, ngram: int = 13, max_fraction: float = 0.10,
) -> tuple[set[str], LeakReport]:
    """`docs` : doc_id → (split, texte normalisé). Retourne (doc_id à retirer de val/test, rapport)."""
    train_grams: set[int] = set()
    for _doc_id, (split, text) in docs.items():
        if split == "train":
            train_grams |= ngram_hashes(text, ngram)
    report = LeakReport(ngram=ngram, max_fraction=max_fraction)
    removed: set[str] = set()
    for doc_id in sorted(docs):
        split, text = docs[doc_id]
        if split == "train":
            continue
        grams = ngram_hashes(text, ngram)
        report.checked += 1
        if not grams:
            continue
        fraction = len(grams & train_grams) / len(grams)
        if fraction >= max_fraction:
            removed.add(doc_id)
            report.removed.append({"doc_id": doc_id, "split": split, "fraction_in_train": round(fraction, 4)})
    return removed, report


def assert_no_leak(split_of_doc: Mapping[str, str], group_of_doc: Mapping[str, str]) -> None:
    """Invariants durs : aucun groupe réparti sur plusieurs jeux (donc aucun doc_id non plus)."""
    seen: dict[str, set[str]] = defaultdict(set)
    for doc_id, split in split_of_doc.items():
        seen[group_of_doc[doc_id]].add(split)
    bad = sorted(g for g, s in seen.items() if len(s) > 1)
    if bad:
        raise DataError(f"groupes répartis sur plusieurs jeux : {bad[:5]}")
