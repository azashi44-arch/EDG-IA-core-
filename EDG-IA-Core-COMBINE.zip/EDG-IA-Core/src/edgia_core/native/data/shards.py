"""Écriture des fragments de tokens (`uint16`) et de leur index document → fragment (traçabilité, §5.6).

Format : suite brute d'entiers 16 bits petit-boutiste ; `<|eos|>` (id 2) sépare les documents. Un document n'est JAMAIS
coupé entre deux fragments. Le seul identifiant < 128 présent dans un fragment est EOS : l'écrivain le vérifie.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from edgia_core.native.errors import DataError
from edgia_core.native.hashing import sha256_file
from edgia_core.native.tokenizer import specials


@dataclass(frozen=True)
class ShardInfo:
    path: str
    index_path: str
    sha256: str
    index_sha256: str
    tokens: int
    docs: int


class ShardWriter:
    def __init__(self, directory: Path, split: str, max_tokens: int) -> None:
        if max_tokens < 2:
            raise DataError("max_tokens trop petit")
        self.directory, self.split, self.max_tokens = directory, split, max_tokens
        directory.mkdir(parents=True, exist_ok=True)
        self._chunks: list[np.ndarray] = []
        self._index: list[dict[str, object]] = []
        self._n = 0
        self._counter = 0
        self.shards: list[ShardInfo] = []

    def add(self, token_ids: list[int], meta: dict[str, object]) -> None:
        """Ajoute un document (sans EOS : il est ajouté ici)."""
        if token_ids and (min(token_ids) < specials.N_SPECIAL or max(token_ids) > 65_535):
            raise DataError("identifiant interdit dans le texte d'un document (spécial ou > 65535)")
        arr = np.asarray(token_ids + [specials.EOS], dtype="<u2")
        if self._n and self._n + arr.size > self.max_tokens:
            self._flush()
        self._index.append({**meta, "offset": self._n, "length": int(arr.size)})
        self._chunks.append(arr)
        self._n += arr.size

    def _flush(self) -> None:
        if not self._n:
            return
        stem = f"{self.split}_{self._counter:03d}"
        data_path, index_path = self.directory / f"{stem}.bin", self.directory / f"{stem}.index.jsonl"
        np.concatenate(self._chunks).tofile(data_path)
        index_path.write_text("".join(json.dumps(row, sort_keys=True, ensure_ascii=False) + "\n" for row in self._index), encoding="utf-8")
        self.shards.append(ShardInfo(data_path.name, index_path.name, sha256_file(data_path), sha256_file(index_path), self._n, len(self._index)))
        self._chunks, self._index, self._n = [], [], 0
        self._counter += 1

    def close(self) -> list[ShardInfo]:
        self._flush()
        return self.shards
