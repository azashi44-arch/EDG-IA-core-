"""Construction d'un jeu de données à partir de documents JSONL/dicts (spécification v1.1, §5.4).

Ordre (corrigé en v1.1) : porte 1 → nettoyage → langue → données personnelles → doublons exacts → quasi-doublons et groupes →
découpage par groupe → contrôle de fuite → ENTRAÎNEMENT DU TOKENIZER SUR `train` SEUL → tokenisation → fragments, index, manifeste.
Aucun corpus n'est téléchargé : le pipeline ne lit que les fichiers qu'on lui donne.
"""

from __future__ import annotations

import json
from collections import Counter
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from edgia_core.native.data import licenses
from edgia_core.native.data.dedup import MinHasher, build_groups, find_near_duplicates
from edgia_core.native.data.manifest import MANIFEST_FORMAT, write_manifest
from edgia_core.native.data.registry import SourceRegistry, gate_document
from edgia_core.native.data.shards import ShardWriter
from edgia_core.native.data.split import SPLITS, assert_no_leak, assign_groups, leak_filter
from edgia_core.native.data.text import guess_lang, make_doc_id, normalize_text, scrub_pii
from edgia_core.native.errors import DataError
from edgia_core.native.tokenizer import specials
from edgia_core.native.tokenizer.tokenizer import EdgiaTokenizer, TrainCorpus, train_tokenizer


@dataclass(frozen=True)
class DataConfig:
    val_rate: float = 0.001
    test_rate: float = 0.001
    salt: str = "edgia-split-v1"
    min_chars: int = 200
    allowed_langs: tuple[str, ...] = ("fr", "en")
    scrub_pii: bool = True
    minhash_perm: int = 128
    minhash_bands: int = 16
    shingle_words: int = 5
    jaccard: float = 0.8
    leak_ngram: int = 13
    leak_max_fraction: float = 0.10
    shard_tokens: int = 100_000_000
    tokdev_permille: int = 50
    tokenizer_profile: str = "production"


def read_jsonl(path: str | Path) -> Iterable[dict[str, Any]]:
    with Path(path).open(encoding="utf-8") as handle:
        for number, line in enumerate(handle, 1):
            if line.strip():
                try:
                    yield json.loads(line)
                except json.JSONDecodeError as exc:
                    raise DataError(f"{path}:{number} : JSON invalide") from exc


def _is_tokdev(doc_id: str, permille: int) -> bool:
    return int(doc_id[:8], 16) % 1000 < permille


def build_dataset(
    records: Iterable[dict[str, Any]], registry: SourceRegistry, config: DataConfig, out_dir: str | Path,
    *, tokenizer: EdgiaTokenizer | None = None,
) -> dict[str, Any]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    rejections: list[dict[str, str]] = []

    # 1-4. porte 1, nettoyage, langue, données personnelles
    admitted: dict[str, dict[str, Any]] = {}
    pii_counts: Counter[str] = Counter()
    exact_dups = 0
    for record in records:
        for key in ("text", "source_id", "license_id"):
            if not isinstance(record.get(key), str) or not record[key]:
                raise DataError(f"champ obligatoire manquant ou invalide : {key}")
        reason = gate_document(registry, record["source_id"], record["license_id"])
        text = normalize_text(record["text"])
        doc_id = make_doc_id(text)
        if reason is None and len(text) < config.min_chars:
            reason = f"texte trop court (< {config.min_chars} caractères)"
        lang = record.get("lang") or guess_lang(text)
        if reason is None and lang not in config.allowed_langs:
            reason = f"langue non autorisée ({lang})"
        if reason is not None:
            rejections.append({"doc_id": doc_id, "source_id": record["source_id"], "reason": reason})
            continue
        if config.scrub_pii:
            text, counts = scrub_pii(text)
            pii_counts.update(counts)
            doc_id = make_doc_id(text)
        # 5. doublons exacts : on garde, de façon indépendante de l'ordre d'entrée, la source de plus petit identifiant
        previous = admitted.get(doc_id)
        if previous is not None:
            exact_dups += 1
            if record["source_id"] >= previous["source_id"]:
                continue
        admitted[doc_id] = {
            "text": text, "source_id": record["source_id"], "license_id": record["license_id"], "lang": lang,
            "work_id": record.get("work_id") or None, "origin_ref": record.get("origin_ref", ""),
        }
    if not admitted:
        raise DataError("aucun document admis : vérifier le registre des sources (porte 1) et les documents")

    ids = sorted(admitted)
    # 6-7. quasi-doublons et groupes d'œuvres
    hasher = MinHasher(n_perm=config.minhash_perm, shingle_words=config.shingle_words)
    pairs, dedup_stats = find_near_duplicates(
        ids, [admitted[i]["text"] for i in ids], hasher=hasher, bands=config.minhash_bands, threshold=config.jaccard)
    group_of = build_groups(ids, [admitted[i]["work_id"] for i in ids], pairs)
    # 8. découpage par groupe
    split_of_group, split_notes = assign_groups(
        list(group_of.values()), val_rate=config.val_rate, test_rate=config.test_rate, salt=config.salt)
    split_of_doc = {i: split_of_group[group_of[i]] for i in ids}
    # 9. contrôle de fuite
    removed, leak_report = leak_filter({i: (split_of_doc[i], admitted[i]["text"]) for i in ids},
                                       ngram=config.leak_ngram, max_fraction=config.leak_max_fraction)
    for doc_id in sorted(removed):
        rejections.append({"doc_id": doc_id, "source_id": admitted[doc_id]["source_id"], "reason": "fuite vers train (séquences de mots partagées)"})
        del admitted[doc_id], split_of_doc[doc_id]
    kept = sorted(admitted)
    assert_no_leak(split_of_doc, group_of)
    if not any(split_of_doc[i] == "train" for i in kept):
        raise DataError("aucun document dans le jeu train")

    # 10. tokenizer : entraîné sur `train` seul (hors tranche tokdev), ou tokenizer figé fourni
    tokenizer_origin = "fourni (provenance d'entraînement non vérifiée par ce pipeline)"
    tokdev = [i for i in kept if split_of_doc[i] == "train" and _is_tokdev(i, config.tokdev_permille)]
    if tokenizer is None:
        train_texts = [admitted[i]["text"] for i in kept if split_of_doc[i] == "train" and i not in set(tokdev)]
        tokenizer = train_tokenizer(TrainCorpus("train", train_texts), profile=config.tokenizer_profile)
        tokenizer_origin = "entraîné par ce pipeline sur le jeu train (hors tokdev)"
    tokenizer.save(out / "tokenizer", manifest_extra={"trained_on": tokenizer_origin, "tokdev_docs": tokdev})

    # 11. tokenisation et fragments
    splits_info: dict[str, Any] = {}
    for split in SPLITS:
        members = sorted((i for i in kept if split_of_doc[i] == split), key=lambda i: (group_of[i], i))
        writer = ShardWriter(out / split, split, config.shard_tokens)
        for doc_id in members:
            doc = admitted[doc_id]
            writer.add(tokenizer.encode_text(doc["text"]), {
                "doc_id": doc_id, "source_id": doc["source_id"], "group_id": group_of[doc_id],
                "license_id": doc["license_id"], "lang": doc["lang"]})
        shards = writer.close()
        splits_info[split] = {
            "docs": len(members), "tokens": sum(s.tokens for s in shards), "shards": [asdict(s) for s in shards]}
    used = sorted({admitted[i]["source_id"] for i in kept})
    manifest = {
        "format": MANIFEST_FORMAT, "tokenizer_sha256": tokenizer.tokenizer_hash(), "special_tokens_sha256": specials.lock_hash(),
        "profile": tokenizer.profile, "vocab_size": tokenizer.vocab_size, "tokenizer_origin": tokenizer_origin,
        "data_config": asdict(config), "registry_sha256": registry.registry_hash(), "sources_used": used,
        "sources": [registry.get(s).to_dict() for s in used], "splits": splits_info,
        "counts": {"admitted_before_leak_filter": len(ids), "kept": len(kept), "rejected": len(rejections),
                   "exact_duplicates_dropped": exact_dups, "near_duplicate_pairs": len(pairs), "groups": len(set(group_of.values()))},
        "dedup_stats": dedup_stats, "pii_counts": dict(pii_counts), "split_notes": split_notes,
    }
    manifest = write_manifest(out, manifest)
    (out / "rejections.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n" for r in rejections), encoding="utf-8")
    (out / "leak_report.json").write_text(json.dumps(leak_report.to_dict(), indent=2, sort_keys=True), encoding="utf-8")
    (out / "DATA_CARD.md").write_text(_data_card(registry, used, manifest), encoding="utf-8")
    return manifest


def _data_card(registry: SourceRegistry, used: list[str], manifest: dict[str, Any]) -> str:
    lines = ["# Fiche de données (générée)", "",
             f"Jeu de données : `{manifest['manifest_sha256']}`. Tokenizer : `{manifest['tokenizer_sha256']}`.", "",
             "| Source | Licence | Classe | Version | Obligations connues |", "|---|---|---|---|---|"]
    for source_id in used:
        s = registry.get(source_id)
        obligations = "; ".join(licenses.OBLIGATIONS.get(licenses.canonical_license_id(s.license_id), [])) or "—"
        lines.append(f"| {s.source_id} | {s.license_id} | {s.computed_class} | {s.collection_version} | {obligations} |")
    for split, info in manifest["splits"].items():
        lines.append(f"\n- `{split}` : {info['docs']} documents, {info['tokens']} tokens.")
    lines += ["", "Les obligations ci-dessus sont un rappel, pas un avis juridique. Distribution des poids : porte 2 requise.",
              "Limites : voir `docs/native/DONNEES.md` (quasi-doublons sémantiques non détectés, données personnelles non garanties)."]
    return "\n".join(lines) + "\n"
