"""Modèle EDG-IA Native (PyTorch) : Transformer causal, pré-normalisation, RMSNorm, RoPE (moitiés), GQA, SwiGLU, embeddings liés.

ÉTAT : ce module est CODÉ mais n'a PAS pu être exécuté dans l'environnement de développement de L0 (PyTorch y est absent).
Sa logique a été vérifiée uniquement à travers la référence NumPy (`reference/numpy_model.py`), qui implémente les mêmes formules
indépendamment. Les tests `tests/native/test_torch_model.py` (comparaison à la référence NumPy, cache KV, causalité,
gradients) DOIVENT être exécutés avec PyTorch avant toute utilisation.

Formules : voir spécification v1.1 §3.3 et la docstring de `reference/numpy_model.py`. Points délicats, fixés explicitement :
  * RMSNorm : moyenne et rsqrt en float32, résultat reconverti dans le type d'entrée AVANT le gain.
  * RoPE : positions ABSOLUES (décalage = longueur du cache), K stocké dans le cache APRÈS rotation.
  * GQA : `repeat_interleave(group, dim=1)` (la tête de requête h lit la tête KV h // group).
  * Masque : `is_causal=True` seulement si le cache est vide ; sinon aucun masque pour 1 requête, masque booléen explicite sinon.
  * Sortie : `F.linear(norm(x), E)` ; aucun module `lm_head`.
"""

from __future__ import annotations

from collections.abc import Mapping

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

from edgia_core.native import naming
from edgia_core.native.config import ModelConfig
from edgia_core.native.errors import ConfigError


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float) -> None:
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dtype = x.dtype
        xf = x.float()
        normed = xf * torch.rsqrt(xf.pow(2).mean(dim=-1, keepdim=True) + self.eps)
        return normed.to(dtype) * self.weight.to(dtype)


def rope_tables(cfg: ModelConfig) -> tuple[torch.Tensor, torch.Tensor]:
    """cos/sin float32 [max_seq_len, head_dim/2] ; fréquences θ^(−2j/head_dim), calculées en float64."""
    half = cfg.head_dim // 2
    inv_freq = cfg.rope_theta ** (-2.0 * torch.arange(half, dtype=torch.float64) / cfg.head_dim)
    angles = torch.arange(cfg.max_seq_len, dtype=torch.float64)[:, None] * inv_freq[None, :]
    return torch.cos(angles).float(), torch.sin(angles).float()


def apply_rope(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
    """x : [B, heads, T, head_dim] ; cos/sin : [T, head_dim/2] (positions absolues déjà découpées)."""
    half = x.shape[-1] // 2
    xf = x.float()
    a, b = xf[..., :half], xf[..., half:]
    out = torch.cat([a * cos - b * sin, b * cos + a * sin], dim=-1)
    return out.to(x.dtype)


class KVCache:
    """Cache K/V préalloué [B, Hkv, max_seq_len, head_dim] par couche ; stocke des K DÉJÀ tournés."""

    def __init__(self, cfg: ModelConfig, batch: int = 1, device: str | torch.device = "cpu", dtype: torch.dtype = torch.float32) -> None:
        shape = (batch, cfg.n_kv_heads, cfg.max_seq_len, cfg.head_dim)
        self.k = [torch.zeros(shape, device=device, dtype=dtype) for _ in range(cfg.n_layers)]
        self.v = [torch.zeros(shape, device=device, dtype=dtype) for _ in range(cfg.n_layers)]
        self.length = 0
        self.max_len = cfg.max_seq_len

    def reset(self) -> None:
        self.length = 0

    def update(self, layer: int, k_new: torch.Tensor, v_new: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        start, end = self.length, self.length + k_new.shape[2]
        self.k[layer][:, :, start:end] = k_new.to(self.k[layer].dtype)
        self.v[layer][:, :, start:end] = v_new.to(self.v[layer].dtype)
        return self.k[layer][:, :, :end], self.v[layer][:, :, :end]


class Attention(nn.Module):
    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        d, h, hk, hd = cfg.d_model, cfg.n_heads, cfg.n_kv_heads, cfg.head_dim
        self.n_heads, self.n_kv_heads, self.head_dim, self.group = h, hk, hd, h // hk
        self.q_proj = nn.Linear(d, h * hd, bias=False)
        self.k_proj = nn.Linear(d, hk * hd, bias=False)
        self.v_proj = nn.Linear(d, hk * hd, bias=False)
        self.o_proj = nn.Linear(h * hd, d, bias=False)

    def forward(self, x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor, cache: KVCache | None, layer: int) -> torch.Tensor:
        b, t, _ = x.shape
        pos0 = cache.length if cache is not None else 0
        q = self.q_proj(x).view(b, t, self.n_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(b, t, self.n_kv_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(b, t, self.n_kv_heads, self.head_dim).transpose(1, 2)
        c, s = cos[pos0 : pos0 + t], sin[pos0 : pos0 + t]
        q, k = apply_rope(q, c, s), apply_rope(k, c, s)
        if cache is not None:
            k_all, v_all = cache.update(layer, k, v)
        else:
            k_all, v_all = k, v
        k_all, v_all = k_all.to(q.dtype), v_all.to(q.dtype)
        k_e = k_all.repeat_interleave(self.group, dim=1)  # [B, H, P+T, hd] : tête h ← tête KV h // group
        v_e = v_all.repeat_interleave(self.group, dim=1)
        if pos0 == 0:
            out = F.scaled_dot_product_attention(q, k_e, v_e, is_causal=True)
        elif t == 1:
            out = F.scaled_dot_product_attention(q, k_e, v_e)  # une requête voit tout le passé
        else:
            n_keys = pos0 + t
            mask = torch.arange(n_keys, device=x.device)[None, :] <= (pos0 + torch.arange(t, device=x.device))[:, None]
            out = F.scaled_dot_product_attention(q, k_e, v_e, attn_mask=mask)
        return self.o_proj(out.transpose(1, 2).reshape(b, t, self.n_heads * self.head_dim))


class FeedForward(nn.Module):
    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.gate_proj = nn.Linear(cfg.d_model, cfg.ffn_dim, bias=False)
        self.up_proj = nn.Linear(cfg.d_model, cfg.ffn_dim, bias=False)
        self.down_proj = nn.Linear(cfg.ffn_dim, cfg.d_model, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x))


class Block(nn.Module):
    def __init__(self, cfg: ModelConfig) -> None:
        super().__init__()
        self.attn_norm = RMSNorm(cfg.d_model, cfg.rms_eps)
        self.attn = Attention(cfg)
        self.ffn_norm = RMSNorm(cfg.d_model, cfg.rms_eps)
        self.ffn = FeedForward(cfg)

    def forward(self, x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor, cache: KVCache | None, layer: int) -> torch.Tensor:
        x = x + self.attn(self.attn_norm(x), cos, sin, cache, layer)
        return x + self.ffn(self.ffn_norm(x))


class EdgiaModel(nn.Module):
    def __init__(self, cfg: ModelConfig, *, init: bool = True) -> None:
        super().__init__()
        self.cfg = cfg
        self.tok_embeddings = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.layers = nn.ModuleList(Block(cfg) for _ in range(cfg.n_layers))
        self.norm = RMSNorm(cfg.d_model, cfg.rms_eps)
        cos, sin = rope_tables(cfg)
        self.register_buffer("rope_cos", cos, persistent=False)
        self.register_buffer("rope_sin", sin, persistent=False)
        if init:
            self.init_weights()

    # --- initialisation depuis zéro (spécification §3.5) --------------------------------------------------------
    @torch.no_grad()
    def init_weights(self) -> None:
        generator = torch.Generator(device="cpu").manual_seed(self.cfg.seed)
        for name, param in self.named_parameters():
            if name == naming.FINAL_NORM or name.endswith(naming.NORM_SUFFIXES):
                param.fill_(1.0)
                continue
            std = self.cfg.residual_init_std if name.endswith(naming.RESIDUAL_SUFFIXES) else self.cfg.init_std
            param.copy_(torch.randn(param.shape, generator=generator, dtype=torch.float32) * std)

    def forward(self, ids: torch.Tensor, cache: KVCache | None = None) -> torch.Tensor:
        """ids : [B, T] int64 → logits [B, T, V]. Si `cache` est fourni, il est complété et avancé de T positions."""
        b, t = ids.shape
        pos0 = cache.length if cache is not None else 0
        if t < 1 or pos0 + t > self.cfg.max_seq_len:
            raise ValueError(f"longueur invalide : {pos0} + {t} > {self.cfg.max_seq_len}")
        x = self.tok_embeddings(ids)
        for i, layer in enumerate(self.layers):
            x = layer(x, self.rope_cos, self.rope_sin, cache, i)
        x = self.norm(x)
        if cache is not None:
            cache.length += t
        return F.linear(x, self.tok_embeddings.weight)  # embeddings liés par construction

    # --- passage de/vers des tableaux NumPy (checkpoints, export) -----------------------------------------------
    def export_tensors(self) -> dict[str, np.ndarray]:
        return {name: p.detach().cpu().float().numpy().copy() for name, p in self.named_parameters()}

    @torch.no_grad()
    def load_tensors(self, tensors: Mapping[str, np.ndarray]) -> None:
        expected = naming.expected_shapes(self.cfg)
        params = dict(self.named_parameters())
        if set(tensors) != set(expected) or set(params) != set(expected):
            raise ConfigError("tenseurs manquants ou en trop (chargement strict)")
        for name, value in tensors.items():
            if tuple(value.shape) != expected[name]:
                raise ConfigError(f"{name} : forme {tuple(value.shape)} ≠ {expected[name]}")
            params[name].copy_(torch.from_numpy(np.ascontiguousarray(value, dtype=np.float32)))


def language_model_loss(model: EdgiaModel, batch: torch.Tensor) -> torch.Tensor:
    """Entropie croisée moyenne par token. batch : [B, T+1] ; entrées = [:, :-1], cibles = [:, 1:] (décalage d'un cran)."""
    inputs, targets = batch[:, :-1], batch[:, 1:]
    logits = model(inputs)
    return F.cross_entropy(logits.float().reshape(-1, logits.shape[-1]), targets.reshape(-1))
