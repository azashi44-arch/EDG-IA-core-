"""Échantillonnage du prochain token (NumPy). Applique TOUJOURS le masque des identifiants interdits en sortie."""

from __future__ import annotations

from collections.abc import Collection

import numpy as np

from edgia_core.native.errors import NativeError


def sample_next(
    logits: np.ndarray, *, temperature: float, top_p: float, rng: np.random.Generator | None,
    forbidden: Collection[int],
) -> int:
    scores = np.array(logits, dtype=np.float64, copy=True)
    if scores.ndim != 1:
        raise NativeError("sample_next attend un vecteur de logits")
    if forbidden:
        scores[np.fromiter(forbidden, dtype=np.int64)] = -np.inf
    if not np.isfinite(scores).any():
        raise NativeError("aucun token autorisé (logits non finis)")
    if temperature <= 0:
        return int(np.argmax(scores))  # égalité : plus petit identifiant (déterministe)
    if rng is None:
        raise NativeError("un générateur aléatoire est requis quand temperature > 0")
    scaled = scores / temperature
    scaled -= scaled.max()
    probs = np.exp(scaled)
    probs /= probs.sum()
    if top_p < 1.0:
        order = np.argsort(-probs, kind="stable")
        cumulative = np.cumsum(probs[order])
        keep = int(np.searchsorted(cumulative, top_p, side="left")) + 1  # inclut le token qui franchit top_p
        mask = np.zeros_like(probs)
        mask[order[:keep]] = probs[order[:keep]]
        probs = mask / mask.sum()
    return int(rng.choice(len(probs), p=probs))
