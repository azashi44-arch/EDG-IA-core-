"""Boucle de préentraînement (PyTorch) : prédiction du token suivant depuis une initialisation aléatoire.

ÉTAT : CODÉ, NON EXÉCUTÉ dans l'environnement de développement de L0 (PyTorch absent). Les composants qu'elle assemble et qui
n'ont pas besoin de PyTorch (planificateur, chargeur de données, checkpoints atomiques, comparaison d'environnement, export)
sont, eux, testés. Un test de fumée complet (`tests/native/test_torch_training.py`) doit être exécuté avec PyTorch.

Garanties visées (spécification v1.1, §6-7) : chargeur sans état ; AdamW sans décroissance sur normes et embeddings ; bf16 en
calcul avec poids float32 (GPU) ; écrêtage du gradient ; arrêt immédiat si perte ou gradient non fini (aucun checkpoint écrit) ;
checkpoints atomiques complets (modèle, Adam avec compteurs de pas, RNG Python/NumPy/PyTorch/CUDA, empreintes, environnement) ;
reprise avec niveau de reproductibilité A/B/C annoncé honnêtement.
"""

from __future__ import annotations

import base64
import json
import math
import random
import signal
import time
from pathlib import Path
from typing import Any

import numpy as np

from edgia_core.native import NATIVE_VERSION, naming
from edgia_core.native.config import ModelConfig, TrainConfig
from edgia_core.native.data.loader import WindowLoader
from edgia_core.native.data.manifest import load_manifest, train_shard_paths, verify_manifest
from edgia_core.native.errors import ConfigError, DataError, NativeError
from edgia_core.native.tokenizer import specials
from edgia_core.native.train import checkpoint as ckpt
from edgia_core.native.train.env import capture_environment, compare_environments
from edgia_core.native.train.schedule import lr_at


class TrainingAborted(NativeError):
    """Entraînement arrêté pour une raison de sécurité numérique (perte ou gradient non fini)."""


def plan(model_cfg: ModelConfig, train_cfg: TrainConfig) -> dict[str, Any]:
    """Ce que ferait un entraînement (sans PyTorch, sans rien lancer)."""
    train_cfg.validate(model_cfg)
    seqs = train_cfg.batch_tokens // model_cfg.max_seq_len
    return {
        "params": model_cfg.param_count(), "steps": train_cfg.max_steps, "tokens_total": train_cfg.max_steps * train_cfg.batch_tokens,
        "sequences_per_step": seqs, "accumulation_steps": seqs // train_cfg.micro_batch_seqs,
        "logits_gib_per_microbatch_fp32": round(train_cfg.micro_batch_seqs * model_cfg.max_seq_len * model_cfg.vocab_size * 4 / 2**30, 2),
        "training_flops_6ND": 6 * model_cfg.param_count() * train_cfg.max_steps * train_cfg.batch_tokens,
        "note": "estimations théoriques à mesurer au pilote ; aucun entraînement n'est lancé par `plan`",
    }


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


def capture_rng(torch: Any) -> dict[str, Any]:
    py = random.getstate()
    np_state = np.random.get_state()
    state: dict[str, Any] = {
        "python": [py[0], list(py[1]), py[2]],
        "numpy_global": [np_state[0], [int(x) for x in np_state[1]], int(np_state[2]), int(np_state[3]), float(np_state[4])],
        "torch_cpu": _b64(torch.get_rng_state().numpy().tobytes()), "torch_cuda": [],
    }
    if torch.cuda.is_available():
        state["torch_cuda"] = [_b64(s.cpu().numpy().tobytes()) for s in torch.cuda.get_rng_state_all()]
    return state


def restore_rng(torch: Any, state: dict[str, Any]) -> None:
    py = state["python"]
    random.setstate((py[0], tuple(py[1]), py[2]))
    ns = state["numpy_global"]
    np.random.set_state((ns[0], np.array(ns[1], dtype=np.uint32), ns[2], ns[3], ns[4]))
    torch.set_rng_state(torch.frombuffer(bytearray(base64.b64decode(state["torch_cpu"])), dtype=torch.uint8))
    if state.get("torch_cuda") and torch.cuda.is_available():
        torch.cuda.set_rng_state_all([torch.frombuffer(bytearray(base64.b64decode(s)), dtype=torch.uint8) for s in state["torch_cuda"]])


def _optimizer_snapshot(model: Any, optimizer: Any) -> tuple[dict[str, np.ndarray], dict[str, int]]:
    tensors: dict[str, np.ndarray] = {}
    steps: dict[str, int] = {}
    for name, param in model.named_parameters():
        state = optimizer.state.get(param, {})
        if not state:
            tensors[f"{name}.exp_avg"] = np.zeros(tuple(param.shape), dtype=np.float32)
            tensors[f"{name}.exp_avg_sq"] = np.zeros(tuple(param.shape), dtype=np.float32)
            steps[name] = 0
            continue
        tensors[f"{name}.exp_avg"] = state["exp_avg"].detach().cpu().float().numpy().copy()
        tensors[f"{name}.exp_avg_sq"] = state["exp_avg_sq"].detach().cpu().float().numpy().copy()
        steps[name] = int(round(float(state["step"])))
    return tensors, steps


def _optimizer_restore(torch: Any, model: Any, optimizer: Any, tensors: dict[str, np.ndarray], steps: dict[str, int], device: str) -> None:
    """Restaure moments ET compteur de pas d'Adam (sans lui, la correction de biais repartirait de zéro)."""
    for name, param in model.named_parameters():
        count = steps[name]
        if count == 0:
            continue
        optimizer.state[param] = {
            "step": torch.tensor(float(count)),
            "exp_avg": torch.from_numpy(np.ascontiguousarray(tensors[f"{name}.exp_avg"])).to(device),
            "exp_avg_sq": torch.from_numpy(np.ascontiguousarray(tensors[f"{name}.exp_avg_sq"])).to(device),
        }


def run_training(
    model_cfg: ModelConfig, train_cfg: TrainConfig, data_dir: str | Path, out_dir: str | Path, *, resume: bool = True,
    device: str | None = None, stop_after_step: int | None = None, verify_data: bool = True,
) -> dict[str, Any]:
    import torch

    from edgia_core.native.model import EdgiaModel, language_model_loss

    train_cfg.validate(model_cfg)
    data_dir, out = Path(data_dir), Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    ckpt_root = out / "ckpt"
    manifest = load_manifest(data_dir)
    if verify_data:
        problems = verify_manifest(data_dir)
        if problems:
            raise DataError("jeu de données altéré ou incomplet : " + " ; ".join(problems[:3]))
    if manifest["vocab_size"] != model_cfg.vocab_size or manifest["profile"] != model_cfg.profile:
        raise ConfigError("le jeu de données (tokenizer) ne correspond pas à la configuration du modèle (vocabulaire ou profil)")
    if manifest["special_tokens_sha256"] != specials.lock_hash():
        raise ConfigError("verrou des identifiants réservés différent entre données et code")

    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    device_type = "cuda" if device.startswith("cuda") else "cpu"
    precision = "bf16" if (train_cfg.precision == "bf16" and device_type == "cuda") else "fp32"
    if train_cfg.deterministic:
        torch.use_deterministic_algorithms(True)
        if device_type == "cpu":
            torch.set_num_threads(1)
    ctx = model_cfg.max_seq_len
    batch_seqs = train_cfg.batch_tokens // ctx
    accum = batch_seqs // train_cfg.micro_batch_seqs
    runtime = {"precision": precision, "deterministic": bool(train_cfg.deterministic), "attention_backend": "torch-sdpa", "compiled": False,
               "micro_batch_seqs": train_cfg.micro_batch_seqs, "accumulation_steps": accum}
    env = capture_environment(runtime)

    fingerprints = {
        "model_config": model_cfg.config_hash(), "train_config": train_cfg.config_hash(), "tokenizer": manifest["tokenizer_sha256"],
        "special_tokens": specials.lock_hash(), "dataset": manifest["manifest_sha256"],
    }
    loader = WindowLoader(train_shard_paths(data_dir, "train"), ctx, train_cfg.seed, batch_seqs)
    val_paths = train_shard_paths(data_dir, "val") if manifest["splits"]["val"]["shards"] else []
    val_loader = WindowLoader(val_paths, ctx, 0, train_cfg.micro_batch_seqs) if val_paths else None

    model = EdgiaModel(model_cfg, init=True).to(device)
    named = list(model.named_parameters())
    decay = [p for n, p in named if naming.is_decay_param(n, tuple(p.shape))]
    no_decay = [p for n, p in named if not naming.is_decay_param(n, tuple(p.shape))]
    optimizer = torch.optim.AdamW(
        [{"params": decay, "weight_decay": train_cfg.weight_decay}, {"params": no_decay, "weight_decay": 0.0}],
        lr=train_cfg.peak_lr, betas=(train_cfg.beta1, train_cfg.beta2), eps=train_cfg.adam_eps)

    step = 0
    best_val: dict[str, Any] = {"step": None, "loss": None}
    history: list[dict[str, Any]] = []
    level, exact = "A" if (device_type == "cpu" and precision == "fp32" and train_cfg.deterministic) else "B", None
    existing = ckpt.list_checkpoints(ckpt_root)
    if resume and existing:
        loaded = ckpt.load_checkpoint(ckpt_root / ckpt.step_dir_name(existing[-1]))
        state = loaded["trainer_state"]
        ckpt.check_resume_compatibility(state, fingerprints)
        level, diffs = compare_environments(state["environment"], env)
        model.load_tensors(loaded["model"])
        _optimizer_restore(torch, model, optimizer, loaded["optimizer"], state["adam_steps"], device)
        restore_rng(torch, loaded["rng_state"])
        step = int(state["step"])
        best_val = state.get("best_val", best_val)
        history = list(state.get("resumes", []))
        history.append({"at_step": step, "level": level, "environment_differences": diffs})
        exact = level == "A"
    elif existing and not resume:
        raise ConfigError("des checkpoints existent déjà dans ce dossier ; utiliser resume=True ou un autre dossier")

    metrics_path = out / "metrics.jsonl"
    interrupted = {"flag": False}

    def on_signal(signum: int, _frame: Any) -> None:
        interrupted["flag"] = True
        signal.signal(signum, signal.SIG_DFL)  # un second signal interrompt immédiatement

    try:
        signal.signal(signal.SIGINT, on_signal)
        signal.signal(signal.SIGTERM, on_signal)
    except ValueError:  # pas dans le thread principal
        pass

    def log(record: dict[str, Any]) -> None:
        with metrics_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, sort_keys=True) + "\n")

    def evaluate() -> float | None:
        if val_loader is None:
            return None
        model.eval()
        losses = []
        with torch.no_grad():
            for i in range(train_cfg.eval_batches):
                batch = torch.from_numpy(val_loader.get_batch(i)).to(device)
                with torch.autocast(device_type=device_type, dtype=torch.bfloat16, enabled=precision == "bf16"):
                    losses.append(float(language_model_loss(model, batch)))
        model.train()
        return float(np.mean(losses))

    def save(at: int, last_fp: str | None) -> Path:
        model_t = model.export_tensors()
        opt_t, adam_steps = _optimizer_snapshot(model, optimizer)
        state = {
            "step": at, "tokens_seen": at * train_cfg.batch_tokens, "seed": train_cfg.seed, "train_config": train_cfg.to_dict(),
            "current_lr_next": lr_at(min(at, train_cfg.max_steps - 1), train_cfg), "batch_fingerprint_last": last_fp,
            "fingerprints": fingerprints, "code_version": NATIVE_VERSION, "environment": env, "reproducibility_level": level,
            "resume_exact": level == "A", "adam_steps": adam_steps, "best_val": best_val, "resumes": history,
            "requested_status": train_cfg.status,
        }
        path = ckpt.save_checkpoint(ckpt_root, at, model=model_t, optimizer=opt_t, trainer_state=state, rng_state=capture_rng(torch))
        ckpt.apply_retention(ckpt_root, keep_last=train_cfg.keep_last, milestone_every=train_cfg.milestone_every, best_step=best_val["step"])
        return path

    model.train()
    last_save = time.monotonic()
    last_fp: str | None = None
    last_loss = float("nan")
    last_saved_step = step if existing and resume else -1
    while step < train_cfg.max_steps:
        if stop_after_step is not None and step >= stop_after_step:
            break
        if interrupted["flag"]:
            break
        lr = lr_at(step, train_cfg)
        for group in optimizer.param_groups:
            group["lr"] = lr
        batch_np = loader.get_batch(step)
        last_fp = loader.batch_fingerprint(step)
        batch = torch.from_numpy(batch_np).to(device)
        total = 0.0
        for m in range(accum):
            micro = batch[m * train_cfg.micro_batch_seqs : (m + 1) * train_cfg.micro_batch_seqs]
            with torch.autocast(device_type=device_type, dtype=torch.bfloat16, enabled=precision == "bf16"):
                loss = language_model_loss(model, micro) / accum
            loss.backward()
            total += float(loss.detach())
        grad_norm = float(torch.nn.utils.clip_grad_norm_(model.parameters(), train_cfg.grad_clip))
        if not (math.isfinite(total) and math.isfinite(grad_norm)):
            raise TrainingAborted(f"perte ou gradient non fini au pas {step} (perte={total}, norme={grad_norm}) : aucun checkpoint écrit")
        optimizer.step()
        optimizer.zero_grad(set_to_none=True)
        step += 1
        last_loss = total
        if step % train_cfg.log_every == 0 or step == 1:
            log({"step": step, "loss": total, "lr": lr, "grad_norm": grad_norm, "tokens": step * train_cfg.batch_tokens})
        if step % train_cfg.eval_every == 0 or step == train_cfg.max_steps:
            val = evaluate()
            if val is not None:
                log({"step": step, "val_loss": val})
                if best_val["loss"] is None or val < best_val["loss"]:
                    best_val = {"step": step, "loss": val}
        due_time = (time.monotonic() - last_save) / 60.0 >= train_cfg.ckpt_every_minutes
        if step % train_cfg.ckpt_every == 0 or due_time or step == train_cfg.max_steps:
            save(step, last_fp)
            last_save, last_saved_step = time.monotonic(), step
    if last_saved_step != step:
        save(step, last_fp)  # fin normale (stop_after_step) ou interruption propre : état complet sur disque
    return {"final_step": step, "last_loss": last_loss, "interrupted": interrupted["flag"], "reproducibility_level": level,
            "resume_exact": exact, "best_val": best_val, "checkpoints": ckpt.list_checkpoints(ckpt_root), "metrics": str(metrics_path)}
