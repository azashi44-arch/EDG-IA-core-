"""Export d'un modèle pour Core (spécification v1.1, §7.4) : safetensors + config + tokenizer + manifeste + fiches.

Garde-fous : (1) statut d'entraînement explicite (`random_init`, `smoke_test`, `pilot`, `trained`) ; (2) `distribution_cleared`
vaut FAUX par défaut et ne passe à VRAI que si `for_distribution=True`, que le modèle est `trained` et que TOUTES les sources
du jeu de données ont franchi la porte 2 ; (3) aucune lecture pickle ; (4) vérification complète par `verify_export`.
"""

from __future__ import annotations

import json
import shutil
from collections.abc import Mapping
from pathlib import Path
from typing import Any

import numpy as np

from edgia_core.native import naming
from edgia_core.native import safetensors_io as st
from edgia_core.native.config import PROFILE_SMOKE, TRAINING_STATUSES, ModelConfig
from edgia_core.native.data.registry import SourceRegistry
from edgia_core.native.errors import ExportError
from edgia_core.native.hashing import sha256_file, sha256_json
from edgia_core.native.tokenizer import specials
from edgia_core.native.tokenizer.tokenizer import EdgiaTokenizer

FORMAT_VERSION = 1
ARCHITECTURE = "edgia-native"
EXPORT_FILES = ("model.safetensors", "config.json", "tokenizer.json", "tokenizer_config.json", "tokenizer_manifest.json", "MODEL_CARD.md")
UNTRAINED_STATUSES = ("random_init", "smoke_test")


def check_tensors(cfg: ModelConfig, tensors: Mapping[str, np.ndarray]) -> None:
    """Noms, formes et type exacts ; aucun tenseur en trop (en particulier aucune matrice de sortie séparée)."""
    expected = naming.expected_shapes(cfg)
    missing = sorted(set(expected) - set(tensors))
    extra = sorted(set(tensors) - set(expected))
    if missing or extra:
        raise ExportError(f"tenseurs inattendus ou manquants : manquants={missing[:5]} en trop={extra[:5]}")
    for name, shape in expected.items():
        if tuple(tensors[name].shape) != shape:
            raise ExportError(f"{name} : forme {tuple(tensors[name].shape)} ≠ {shape}")
        if not np.issubdtype(tensors[name].dtype, np.floating) or not np.isfinite(tensors[name]).all():
            raise ExportError(f"{name} : valeurs non finies ou type non flottant")


def check_status(cfg: ModelConfig, status: str) -> None:
    if status not in TRAINING_STATUSES:
        raise ExportError(f"statut inconnu : {status}")
    if cfg.profile == PROFILE_SMOKE and status != "smoke_test":
        raise ExportError("un modèle de profil smoke ne peut avoir que le statut « smoke_test »")
    if status == "smoke_test" and cfg.profile != PROFILE_SMOKE:
        raise ExportError("le statut « smoke_test » est réservé au profil smoke")


def distribution_problems(registry: SourceRegistry, sources_used: list[str], status: str) -> list[str]:
    problems: list[str] = []
    if status != "trained":
        problems.append(f"statut « {status} » : seule une version « trained » peut être distribuée")
    if not sources_used:
        problems.append("aucune source déclarée pour ce modèle")
    for source_id in sources_used:
        if source_id not in registry:
            problems.append(f"{source_id} : absente du registre")
            continue
        problems += [f"{source_id} : {p}" for p in registry.get(source_id).distribution_problems()]
    return problems


def _model_card(cfg: ModelConfig, status: str, cleared: bool, params: int, extra: Mapping[str, Any]) -> str:
    warning = ""
    if status in UNTRAINED_STATUSES:
        warning = ("\n> **AVERTISSEMENT : ce modèle n'est PAS entraîné** (statut `" + status + "`). Ses poids sont aléatoires "
                   "ou issus d'un test technique. Il ne produit aucun texte utile et ne doit jamais être présenté comme une IA.\n")
    return (f"# Fiche de modèle — {cfg.name}\n{warning}\n- Architecture : {ARCHITECTURE} (format v{FORMAT_VERSION})\n"
            f"- Profil : {cfg.profile} ; statut d'entraînement : **{status}**\n- Paramètres : {params:,}\n"
            f"- Contexte : {cfg.max_seq_len} tokens ; vocabulaire : {cfg.vocab_size}\n"
            f"- Distribution autorisée (`distribution_cleared`) : **{cleared}**\n"
            f"- Données : voir DATA_CARD.md et lineage.json lorsqu'ils existent.\n"
            f"- Limites : aucune évaluation de qualité n'est enregistrée dans cet export.\n"
            + "".join(f"- {k} : {v}\n" for k, v in extra.items()))


def export_model(
    tensors: Mapping[str, np.ndarray], cfg: ModelConfig, tokenizer: EdgiaTokenizer, out_dir: str | Path, *, status: str,
    dataset_dir: str | Path | None = None, registry: SourceRegistry | None = None, for_distribution: bool = False,
    run_info: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    out = Path(out_dir)
    check_status(cfg, status)
    check_tensors(cfg, tensors)
    if tokenizer.vocab_size != cfg.vocab_size or tokenizer.profile != cfg.profile:
        raise ExportError("le tokenizer ne correspond pas au modèle (vocabulaire ou profil)")
    manifest_data: dict[str, Any] = {}
    sources_used: list[str] = []
    if dataset_dir is not None:
        manifest_data = json.loads((Path(dataset_dir) / "dataset_manifest.json").read_text(encoding="utf-8"))
        if manifest_data["tokenizer_sha256"] != tokenizer.tokenizer_hash():
            raise ExportError("le tokenizer ne correspond pas au jeu de données")
        sources_used = list(manifest_data["sources_used"])
    cleared = False
    if for_distribution:
        if registry is None:
            raise ExportError("--for-distribution exige le registre des sources")
        problems = distribution_problems(registry, sources_used, status)
        if problems:
            raise ExportError("distribution refusée : " + " | ".join(problems))
        cleared = True
    if out.exists() and any(out.iterdir()):
        raise ExportError(f"{out} existe déjà et n'est pas vide : un export n'est jamais écrasé")
    out.mkdir(parents=True, exist_ok=True)
    dtype_tensors = {k: np.ascontiguousarray(v, dtype=np.float32) for k, v in tensors.items()}
    st.save(out / "model.safetensors", dtype_tensors, {"edgia_format_version": str(FORMAT_VERSION)})
    tokenizer.save(out)
    params = cfg.param_count()
    config = {
        "architecture": ARCHITECTURE, "format_version": FORMAT_VERSION, "model": cfg.to_dict(), "model_config_sha256": cfg.config_hash(),
        "param_count": params, "tokenizer_sha256": tokenizer.tokenizer_hash(), "special_tokens_sha256": specials.lock_hash(),
        "training_status": status, "distribution_cleared": cleared, "dataset_manifest_sha256": manifest_data.get("manifest_sha256"),
        "sources_used": sources_used, "tensor_dtype": "float32",
    }
    (out / "config.json").write_text(json.dumps(config, indent=2, sort_keys=True, ensure_ascii=False), encoding="utf-8")
    (out / "MODEL_CARD.md").write_text(_model_card(cfg, status, cleared, params, dict(run_info or {})), encoding="utf-8")
    files = list(EXPORT_FILES)
    if dataset_dir is not None:
        card = Path(dataset_dir) / "DATA_CARD.md"
        if card.exists():
            shutil.copyfile(card, out / "DATA_CARD.md")
            files.append("DATA_CARD.md")
        lineage = {"dataset_manifest_sha256": manifest_data.get("manifest_sha256"), "registry_sha256": manifest_data.get("registry_sha256"),
                   "sources": manifest_data.get("sources", []), "tokenizer_sha256": tokenizer.tokenizer_hash(), "run": dict(run_info or {})}
        (out / "lineage.json").write_text(json.dumps(lineage, indent=2, sort_keys=True, ensure_ascii=False), encoding="utf-8")
        files.append("lineage.json")
    export_manifest = {"format": "edgia-export-v1", "files": {name: sha256_file(out / name) for name in sorted(files)},
                       "training_status": status, "distribution_cleared": cleared}
    (out / "export_manifest.json").write_text(json.dumps(export_manifest, indent=2, sort_keys=True), encoding="utf-8")
    return config


def verify_export(directory: str | Path) -> list[str]:
    """Contrôle complet d'un export. Retourne les problèmes (liste vide = conforme)."""
    root = Path(directory)
    problems: list[str] = []
    try:
        manifest = json.loads((root / "export_manifest.json").read_text(encoding="utf-8"))
        config = json.loads((root / "config.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ["export_manifest.json ou config.json illisible"]
    for name, digest in manifest.get("files", {}).items():
        path = root / name
        if not path.is_file():
            problems.append(f"fichier absent : {name}")
        elif sha256_file(path) != digest:
            problems.append(f"empreinte différente : {name}")
    if problems:
        return problems
    if config.get("architecture") != ARCHITECTURE or config.get("format_version") != FORMAT_VERSION:
        return ["architecture ou version de format inconnue"]
    try:
        cfg = ModelConfig.from_dict(config["model"])
        tokenizer = EdgiaTokenizer.load(root)
        tensors, meta = st.load_numpy(root / "model.safetensors")
        check_tensors(cfg, tensors)
        check_status(cfg, config["training_status"])
    except Exception as exc:  # noqa: BLE001 - toute anomalie est un problème d'export
        return [f"{type(exc).__name__}: {exc}"]
    if cfg.config_hash() != config.get("model_config_sha256"):
        problems.append("empreinte de la configuration du modèle incohérente")
    if tokenizer.tokenizer_hash() != config.get("tokenizer_sha256"):
        problems.append("tokenizer différent de celui déclaré")
    if config.get("special_tokens_sha256") != specials.lock_hash():
        problems.append("verrou des identifiants réservés différent")
    if tokenizer.vocab_size != cfg.vocab_size or tokenizer.profile != cfg.profile:
        problems.append("tokenizer incompatible avec le modèle")
    if naming.total_params_from_shapes({k: v.shape for k, v in tensors.items()}) != config.get("param_count"):
        problems.append("nombre de paramètres incohérent")
    if config.get("distribution_cleared") and config.get("training_status") != "trained":
        problems.append("distribution_cleared vrai pour un modèle non entraîné")
    if meta.get("edgia_format_version") != str(FORMAT_VERSION):
        problems.append("métadonnée de format absente du fichier de poids")
    return problems


def check_servable(config: Mapping[str, Any], *, allow_untrained: bool) -> None:
    """Garde-fou de service : un modèle non entraîné n'est jamais servi sans activation explicite du mode expérimental."""
    status = config.get("training_status")
    if status in UNTRAINED_STATUSES and not allow_untrained:
        raise ExportError(
            f"Ce modèle n'est PAS entraîné (statut « {status} »). Il est refusé par défaut. "
            "Pour un essai purement technique : EDGIA_ALLOW_UNTRAINED=true (jamais en production)."
        )
    if status not in TRAINING_STATUSES:
        raise ExportError(f"statut d'entraînement inconnu ou absent : {status!r}")


def sha_of_config(config: Mapping[str, Any]) -> str:
    return sha256_json(dict(config))
