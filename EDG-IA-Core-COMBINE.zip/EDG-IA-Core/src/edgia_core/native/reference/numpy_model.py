"""RÉFÉRENCE NumPy (float64) du modèle EDG-IA Native : lente, volontairement simple, indépendante de PyTorch.

Écrite à partir des formules de la spécification v1.1 §3.3 (et non du code PyTorch) pour servir de second avis :
  * RMSNorm : y = x · rsqrt(mean(x²)+ε) · g
  * RoPE : convention « moitiés » ; ici calculée par multiplication complexe z = a + i·b par e^{iα} (indépendant de la
    formule a' = a·cos − b·sin, b' = b·cos + a·sin utilisée par le modèle PyTorch)
  * GQA : la tête de requête h lit la tête KV h // (H/Hkv) ; boucle explicite par tête (pas de repeat_interleave)
  * masque causal rectangulaire : la requête d'indice i (position P+i) voit les clés de position ≤ P+i
  * sortie = RMSNorm_final(x) · Eᵀ, sans module de sortie séparé
LIMITE : mêmes auteurs que le code PyTorch → un malentendu conceptuel commun resterait invisible (spécification §8.4).
"""

from __future__ import annotations

import numpy as np

from edgia_core.native import naming
from edgia_core.native.config import ModelConfig


def init_params(cfg: ModelConfig, seed: int | None = None, dtype: type = np.float64) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(cfg.seed if seed is None else seed)
    params: dict[str, np.ndarray] = {}
    for name, shape in naming.expected_shapes(cfg).items():
        if name == naming.FINAL_NORM or name.endswith(naming.NORM_SUFFIXES):
            params[name] = np.ones(shape, dtype=dtype)
            continue
        std = cfg.residual_init_std if name.endswith(naming.RESIDUAL_SUFFIXES) else cfg.init_std
        params[name] = rng.normal(0.0, std, size=shape).astype(dtype)
    return params


def param_count(params: dict[str, np.ndarray]) -> int:
    return int(sum(p.size for p in params.values()))


def rmsnorm(x: np.ndarray, gain: np.ndarray, eps: float) -> np.ndarray:
    return x / np.sqrt(np.mean(x * x, axis=-1, keepdims=True) + eps) * gain


def rope_angles(positions: np.ndarray, head_dim: int, theta: float) -> np.ndarray:
    """Angles α[p, j] = p · θ^(−2j/head_dim), j = 0 … head_dim/2 − 1."""
    j = np.arange(head_dim // 2)
    return positions[:, None].astype(np.float64) * (theta ** (-2.0 * j / head_dim))[None, :]


def apply_rope(x: np.ndarray, positions: np.ndarray, theta: float) -> np.ndarray:
    """x : [T, hd] (une tête). Convention moitiés : z = x[:hd/2] + i·x[hd/2:]."""
    half = x.shape[-1] // 2
    z = x[:, :half] + 1j * x[:, half:]
    z = z * np.exp(1j * rope_angles(positions, x.shape[-1], theta))
    return np.concatenate([z.real, z.imag], axis=-1)


def softmax(scores: np.ndarray) -> np.ndarray:
    shifted = scores - scores.max(axis=-1, keepdims=True)
    e = np.exp(shifted)
    return e / e.sum(axis=-1, keepdims=True)


def attend(q: np.ndarray, k: np.ndarray, v: np.ndarray, allowed: np.ndarray, head_dim: int) -> np.ndarray:
    """Une tête : softmax(q·kᵀ/√head_dim, masque) · v. q [T, hd], k/v [n_keys, hd], allowed [T, n_keys] (booléen)."""
    scores = q @ k.T / np.sqrt(head_dim)
    return softmax(np.where(allowed, scores, -np.inf)) @ v


def swiglu(gate: np.ndarray, up: np.ndarray) -> np.ndarray:
    """silu(gate) ⊙ up, avec silu(z) = z · σ(z)."""
    return gate / (1.0 + np.exp(-gate)) * up


def new_cache(cfg: ModelConfig) -> list[dict[str, np.ndarray]]:
    empty = lambda: np.zeros((cfg.n_kv_heads, 0, cfg.head_dim))  # noqa: E731
    return [{"k": empty(), "v": empty()} for _ in range(cfg.n_layers)]


def cache_length(cache: list[dict[str, np.ndarray]]) -> int:
    return int(cache[0]["k"].shape[1])


def forward(params: dict[str, np.ndarray], cfg: ModelConfig, ids: np.ndarray, cache: list[dict[str, np.ndarray]] | None = None) -> np.ndarray:
    """Logits [T, V] pour les tokens `ids` ([T]). Si `cache` est fourni, les K/V (DÉJÀ tournés) y sont ajoutés."""
    ids = np.asarray(ids)
    t = int(ids.shape[0])
    p0 = cache_length(cache) if cache is not None else 0
    if t < 1 or p0 + t > cfg.max_seq_len:
        raise ValueError(f"longueur invalide : {p0} + {t} > {cfg.max_seq_len}")
    if ids.min() < 0 or ids.max() >= cfg.vocab_size:
        raise ValueError("identifiant hors vocabulaire")
    positions = np.arange(p0, p0 + t)
    group = cfg.n_heads // cfg.n_kv_heads
    x = params[naming.EMBEDDING][ids]
    for i in range(cfg.n_layers):
        h = rmsnorm(x, params[naming.layer_name(i, "attn_norm.weight")], cfg.rms_eps)
        q = h @ params[naming.layer_name(i, "attn.q_proj.weight")].T
        k = h @ params[naming.layer_name(i, "attn.k_proj.weight")].T
        v = h @ params[naming.layer_name(i, "attn.v_proj.weight")].T
        q = q.reshape(t, cfg.n_heads, cfg.head_dim)
        k = k.reshape(t, cfg.n_kv_heads, cfg.head_dim)
        v = v.reshape(t, cfg.n_kv_heads, cfg.head_dim)
        k_new = np.stack([apply_rope(k[:, g], positions, cfg.rope_theta) for g in range(cfg.n_kv_heads)])  # [Hkv, T, hd]
        v_new = np.transpose(v, (1, 0, 2))
        if cache is not None:
            cache[i]["k"] = np.concatenate([cache[i]["k"], k_new], axis=1)
            cache[i]["v"] = np.concatenate([cache[i]["v"], v_new], axis=1)
            k_all, v_all = cache[i]["k"], cache[i]["v"]
        else:
            k_all, v_all = k_new, v_new
        n_keys = k_all.shape[1]
        key_pos = np.arange(n_keys)
        allowed = key_pos[None, :] <= positions[:, None]  # [T, n_keys]
        heads = []
        for head in range(cfg.n_heads):
            kv = head // group
            qh = apply_rope(q[:, head], positions, cfg.rope_theta)
            heads.append(attend(qh, k_all[kv], v_all[kv], allowed, cfg.head_dim))
        attn = np.concatenate(heads, axis=-1)  # [T, H*hd]
        x = x + attn @ params[naming.layer_name(i, "attn.o_proj.weight")].T
        h = rmsnorm(x, params[naming.layer_name(i, "ffn_norm.weight")], cfg.rms_eps)
        gate = h @ params[naming.layer_name(i, "ffn.gate_proj.weight")].T
        up = h @ params[naming.layer_name(i, "ffn.up_proj.weight")].T
        act = swiglu(gate, up)
        x = x + act @ params[naming.layer_name(i, "ffn.down_proj.weight")].T
    x = rmsnorm(x, params[naming.FINAL_NORM], cfg.rms_eps)
    return x @ params[naming.EMBEDDING].T


def cross_entropy(logits: np.ndarray, targets: np.ndarray) -> float:
    shifted = logits - logits.max(axis=-1, keepdims=True)
    log_probs = shifted - np.log(np.exp(shifted).sum(axis=-1, keepdims=True))
    return float(-np.mean(log_probs[np.arange(len(targets)), targets]))
