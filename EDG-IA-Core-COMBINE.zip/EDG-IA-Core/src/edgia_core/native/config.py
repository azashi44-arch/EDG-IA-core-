"""Configurations du modèle et de l'entraînement (spécification EDG-IA Native v1.1, sections 3 et 6).

Aucune dépendance externe : la validation est faite à la main pour que ce module soit testable partout.
"""

from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import Any

from edgia_core.native.errors import ConfigError
from edgia_core.native.hashing import sha256_json

PROFILE_PRODUCTION = "production"
PROFILE_SMOKE = "smoke"
PROFILE_TEST = "test"  # micro-modèles des tests mathématiques : aucun tokenizer, aucun usage en service
PRODUCTION_VOCAB = 32_768
SMOKE_VOCAB = 1_024
TRAINING_STATUSES = ("random_init", "smoke_test", "pilot", "trained")


def ffn_dim_for(d_model: int) -> int:
    """8·d/3 arrondi au multiple de 64 supérieur (XS : 1024, S : 2048, M : 2752, L : 5504)."""
    return -(-(8 * d_model) // (3 * 64)) * 64


@dataclass(frozen=True)
class ModelConfig:
    name: str
    profile: str
    vocab_size: int
    d_model: int
    n_layers: int
    n_heads: int
    n_kv_heads: int
    head_dim: int
    ffn_dim: int
    max_seq_len: int
    rope_theta: float = 10_000.0
    rms_eps: float = 1e-5
    tie_embeddings: bool = True
    init_std: float = 0.02
    seed: int = 0

    def __post_init__(self) -> None:
        problems = self.problems()
        if problems:
            raise ConfigError("Configuration du modèle invalide : " + " ; ".join(problems))

    # --- validation -------------------------------------------------------------------------------------------
    def problems(self) -> list[str]:
        p: list[str] = []
        for key in ("vocab_size", "d_model", "n_layers", "n_heads", "n_kv_heads", "head_dim", "ffn_dim", "max_seq_len"):
            value = getattr(self, key)
            if not isinstance(value, int) or isinstance(value, bool) or value < 1:
                p.append(f"{key} doit être un entier ≥ 1")
        if p:
            return p
        if self.profile not in (PROFILE_PRODUCTION, PROFILE_SMOKE, PROFILE_TEST):
            p.append(f"profil inconnu « {self.profile} »")
        if self.profile == PROFILE_PRODUCTION and self.vocab_size != PRODUCTION_VOCAB:
            p.append(f"profil production : vocab_size doit valoir {PRODUCTION_VOCAB}")
        if self.profile == PROFILE_SMOKE and self.vocab_size != SMOKE_VOCAB:
            p.append(f"profil smoke : vocab_size doit valoir {SMOKE_VOCAB}")
        if self.vocab_size > 65_536:
            p.append("vocab_size > 65536 : les fragments de données sont en uint16")
        if self.n_heads * self.head_dim != self.d_model:
            p.append("n_heads × head_dim doit être égal à d_model")
        if self.n_heads % self.n_kv_heads != 0:
            p.append("n_heads doit être un multiple de n_kv_heads")
        if self.head_dim % 2 != 0:
            p.append("head_dim doit être pair (RoPE)")
        if not self.tie_embeddings:
            p.append("v1 : les embeddings d'entrée et de sortie sont obligatoirement liés")
        if not (self.rope_theta > 1.0 and math.isfinite(self.rope_theta)):
            p.append("rope_theta invalide")
        if not (0 < self.rms_eps < 1e-2):
            p.append("rms_eps invalide")
        if not (0 < self.init_std < 1):
            p.append("init_std invalide")
        return p

    # --- formules (section 3.4) -------------------------------------------------------------------------------
    @property
    def group_size(self) -> int:
        return self.n_heads // self.n_kv_heads

    @property
    def residual_init_std(self) -> float:
        """Écart-type des projections qui reviennent dans le flux résiduel : std / √(2·couches)."""
        return self.init_std / math.sqrt(2 * self.n_layers)

    def param_count(self) -> int:
        d, h, hk, hd, f = self.d_model, self.n_heads, self.n_kv_heads, self.head_dim, self.ffn_dim
        per_layer = d * h * hd + 2 * d * hk * hd + h * hd * d + 3 * d * f + 2 * d
        return self.vocab_size * d + self.n_layers * per_layer + d

    def kv_cache_elements(self) -> int:
        """Éléments du cache KV pour une séquence pleine (K et V, toutes couches)."""
        return self.n_layers * 2 * self.n_kv_heads * self.max_seq_len * self.head_dim

    # --- sérialisation ----------------------------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> ModelConfig:
        known = {f.name for f in fields(cls)}
        unknown = sorted(set(raw) - known)
        if unknown:
            raise ConfigError(f"Clés inconnues dans la configuration du modèle : {unknown}")
        return cls(**raw)

    def config_hash(self) -> str:
        return sha256_json(self.to_dict())


def _preset(name: str, d: int, layers: int, heads: int, kv: int, hd: int, ctx: int, **extra: Any) -> ModelConfig:
    return ModelConfig(
        name=name, profile=extra.pop("profile", PROFILE_PRODUCTION), vocab_size=extra.pop("vocab_size", PRODUCTION_VOCAB),
        d_model=d, n_layers=layers, n_heads=heads, n_kv_heads=kv, head_dim=hd, ffn_dim=extra.pop("ffn_dim", ffn_dim_for(d)),
        max_seq_len=ctx, **extra,
    )


PRESETS: dict[str, ModelConfig] = {
    "xs": _preset("xs", 384, 8, 6, 2, 64, 1024),
    "s": _preset("s", 768, 12, 12, 4, 64, 2048),
    "m": _preset("m", 1024, 24, 16, 4, 64, 2048),
    "l": _preset("l", 2048, 20, 16, 4, 128, 4096),
    # Smoke : uniquement pour tester la chaîne technique (jamais une IA).
    "smoke": _preset("smoke", 64, 2, 4, 2, 16, 128, profile=PROFILE_SMOKE, vocab_size=SMOKE_VOCAB, ffn_dim=192),
}
EXPECTED_PARAMS = {"xs": 25_172_352, "s": 100_682_496, "m": 299_418_624, "l": 953_239_552}


def load_model_config(path: str | Path) -> ModelConfig:
    """Charge une configuration depuis un fichier JSON ou YAML (clé `model:` facultative) ou un nom de preset."""
    text = str(path)
    if text.lower() in PRESETS:
        return PRESETS[text.lower()]
    file = Path(path)
    try:
        content = file.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigError(f"Configuration illisible : {file}") from exc
    if file.suffix.lower() == ".json":
        raw = json.loads(content)
    else:
        import yaml  # PyYAML est déjà une dépendance de Core

        raw = yaml.safe_load(content)
    if not isinstance(raw, dict):
        raise ConfigError(f"{file} doit contenir un objet")
    return ModelConfig.from_dict(raw.get("model", raw))


@dataclass(frozen=True)
class TrainConfig:
    seed: int = 1234
    batch_tokens: int = 262_144  # lot effectif par pas d'optimisation
    micro_batch_seqs: int = 8
    max_steps: int = 11_500
    peak_lr: float = 1e-3
    warmup_frac: float = 0.02
    min_lr_frac: float = 0.10
    weight_decay: float = 0.1
    beta1: float = 0.9
    beta2: float = 0.95
    adam_eps: float = 1e-8
    grad_clip: float = 1.0
    precision: str = "bf16"  # "bf16" (GPU) ou "fp32"
    eval_every: int = 500
    eval_batches: int = 8
    ckpt_every: int = 500
    ckpt_every_minutes: float = 30.0
    keep_last: int = 3
    milestone_every: int = 5000
    log_every: int = 10
    deterministic: bool = False
    status: str = "pilot"  # statut inscrit dans les exports : random_init | smoke_test | pilot | trained

    def problems(self, model: ModelConfig) -> list[str]:
        p: list[str] = []
        # Validate integer dimensions before modulo/division: malformed configs must
        # raise ConfigError through validate(), never leak ZeroDivisionError/TypeError.
        for key in ("batch_tokens", "micro_batch_seqs", "max_steps", "eval_every", "eval_batches",
                    "ckpt_every", "keep_last", "milestone_every", "log_every"):
            value = getattr(self, key)
            if not isinstance(value, int) or isinstance(value, bool) or value < 1:
                p.append(f"{key} doit être un entier ≥ 1")
        if not p:
            seq = model.max_seq_len
            if self.batch_tokens % seq != 0:
                p.append("batch_tokens doit être un multiple de la longueur de séquence")
            else:
                seqs = self.batch_tokens // seq
                if seqs % self.micro_batch_seqs != 0:
                    p.append("batch_tokens/longueur doit être un multiple de micro_batch_seqs")
        numeric_positive = ("peak_lr", "adam_eps", "grad_clip", "ckpt_every_minutes")
        for key in numeric_positive:
            value = getattr(self, key)
            if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value) or value <= 0:
                p.append(f"{key} doit être un nombre fini > 0")
        for key in ("weight_decay",):
            value = getattr(self, key)
            if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value) or value < 0:
                p.append(f"{key} doit être un nombre fini ≥ 0")
        for key in ("beta1", "beta2"):
            value = getattr(self, key)
            if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value) or not 0 <= value < 1:
                p.append(f"{key} doit être compris entre 0 inclus et 1 exclu")
        if not isinstance(self.warmup_frac, (int, float)) or isinstance(self.warmup_frac, bool) or not math.isfinite(self.warmup_frac) or not 0 <= self.warmup_frac < 1:
            p.append("warmup_frac doit être compris entre 0 inclus et 1 exclu")
        if not isinstance(self.min_lr_frac, (int, float)) or isinstance(self.min_lr_frac, bool) or not math.isfinite(self.min_lr_frac) or not 0 <= self.min_lr_frac <= 1:
            p.append("min_lr_frac doit être compris entre 0 et 1 inclus")
        if self.precision not in ("bf16", "fp32"):
            p.append("precision doit valoir « bf16 » ou « fp32 »")
        if self.status not in TRAINING_STATUSES:
            p.append(f"status doit appartenir à {TRAINING_STATUSES}")
        return p

    def validate(self, model: ModelConfig) -> None:
        problems = self.problems(model)
        if problems:
            raise ConfigError("Configuration d'entraînement invalide : " + " ; ".join(problems))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> TrainConfig:
        known = {f.name for f in fields(cls)}
        unknown = sorted(set(raw) - known)
        if unknown:
            raise ConfigError(f"Clés inconnues dans la configuration d'entraînement : {unknown}")
        return cls(**raw)

    def config_hash(self) -> str:
        return sha256_json(self.to_dict())
