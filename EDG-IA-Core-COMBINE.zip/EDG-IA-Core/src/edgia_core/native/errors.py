"""Erreurs d'EDG-IA Native. Volontairement indépendantes de `edgia_core.errors` (qui importe pydantic) :
le paquet `native` doit pouvoir être testé sans les dépendances du serveur. Le backend convertit ces erreurs en
`ConfigurationError` / `EngineError` à la frontière avec Core."""

from __future__ import annotations


class NativeError(Exception):
    """Base de toutes les erreurs d'EDG-IA Native."""


class ConfigError(NativeError):
    """Configuration invalide."""


class TokenizerError(NativeError):
    """Tokenizer invalide, corpus insuffisant ou usage interdit."""


class DataError(NativeError):
    """Données invalides ou refusées par une porte de provenance."""


class LicenseError(DataError):
    """Licence ou provenance non conforme."""


class CheckpointError(NativeError):
    """Checkpoint absent, incomplet, corrompu ou incompatible."""


class ExportError(NativeError):
    """Export invalide ou interdit (par exemple distribution non validée)."""


class FormatError(NativeError):
    """Fichier safetensors invalide ou dangereux."""
