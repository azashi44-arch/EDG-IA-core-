"""Boucle de génération indépendante du framework (testée avec la référence NumPy, utilisée par le backend PyTorch).

`forward(token_ids, reset)` retourne les logits (vecteur [V]) du DERNIER token fourni ; `reset=True` vide le cache KV.
Contexte : le prompt doit laisser au moins 1 position ; la génération s'arrête avec « length » quand le cache est plein.
Les identifiants spéciaux et réservés ne sont jamais produits (masque) ; seuls EOS et END terminent (« stop »).
"""

from __future__ import annotations

from collections.abc import Callable, Iterator, Sequence
from dataclasses import dataclass

import numpy as np

from edgia_core.native.errors import NativeError
from edgia_core.native.sampling import sample_next
from edgia_core.native.tokenizer import specials
from edgia_core.native.tokenizer.tokenizer import EdgiaTokenizer


class PromptTooLong(NativeError):
    """Le prompt ne laisse aucune place dans le contexte du modèle."""


@dataclass(frozen=True)
class GenerationParams:
    max_new_tokens: int = 256
    temperature: float = 0.0
    top_p: float = 1.0
    seed: int | None = None


@dataclass(frozen=True)
class TextEvent:
    text: str


@dataclass(frozen=True)
class DoneEvent:
    finish_reason: str  # "stop" | "length"
    completion_tokens: int


def generate_stream(
    forward: Callable[[Sequence[int], bool], np.ndarray], tokenizer: EdgiaTokenizer, prompt_ids: Sequence[int],
    params: GenerationParams, *, max_seq_len: int, cancel: Callable[[], bool] = lambda: False,
) -> Iterator[TextEvent | DoneEvent]:
    if not prompt_ids:
        raise PromptTooLong("prompt vide")
    if len(prompt_ids) > max_seq_len - 1:
        raise PromptTooLong(f"prompt de {len(prompt_ids)} tokens : le contexte du modèle est de {max_seq_len} (1 place minimum requise)")
    rng = np.random.default_rng(params.seed) if params.temperature > 0 else None
    decoder = tokenizer.stream_decoder()
    logits = forward(list(prompt_ids), True)
    cache_len = len(prompt_ids)
    emitted = 0
    while emitted < params.max_new_tokens:
        if cancel():
            return
        token = sample_next(logits, temperature=params.temperature, top_p=params.top_p, rng=rng,
                            forbidden=specials.FORBIDDEN_OUTPUT_IDS)
        if token in specials.TERMINATOR_IDS:
            tail = decoder.flush()
            if tail:
                yield TextEvent(tail)
            yield DoneEvent("stop", emitted)
            return
        emitted += 1
        piece = decoder.feed(token)
        if piece:
            yield TextEvent(piece)
        if emitted >= params.max_new_tokens:
            break
        if cache_len + 1 > max_seq_len:  # le token émis ne peut plus être ajouté au cache : contexte plein
            break
        logits = forward([token], False)
        cache_len += 1
    tail = decoder.flush()
    if tail:
        yield TextEvent(tail)
    yield DoneEvent("length", emitted)
