"""BPE au niveau des octets : entraînement et encodage (implémentation EDG-IA, sans bibliothèque externe).

Identifiants : 0..127 spéciaux/réservés, 128..383 octets, 384.. fusions dans l'ordre d'apprentissage.
Entraînement déterministe : paire la plus fréquente, égalité départagée par la plus petite paire (tuple d'entiers).
L'encodage applique à chaque morceau la fusion de plus petit rang jusqu'à épuisement, exactement comme à l'entraînement.
Performance : Python pur, adapté aux corpus de test et de taille modérée (quelques dizaines de Mo). Pour de très gros
corpus, un entraîneur plus rapide devra produire la MÊME liste de fusions (format `merges`) : voir docs/native.
"""

from __future__ import annotations

import heapq
import unicodedata
from collections import Counter, defaultdict
from collections.abc import Iterable

from edgia_core.native.errors import TokenizerError
from edgia_core.native.tokenizer.pretokenizer import split_text
from edgia_core.native.tokenizer.specials import BYTE_BASE, FIRST_MERGE_ID

Pair = tuple[int, int]


def normalize(text: str) -> str:
    return unicodedata.normalize("NFC", text)


def merge_pair(ids: list[int], pair: Pair, new_id: int) -> list[int]:
    """Fusionne de gauche à droite les occurrences non chevauchantes de `pair`."""
    a, b = pair
    out: list[int] = []
    i, n = 0, len(ids)
    while i < n:
        if i < n - 1 and ids[i] == a and ids[i + 1] == b:
            out.append(new_id)
            i += 2
        else:
            out.append(ids[i])
            i += 1
    return out


def train_merges(texts: Iterable[str], n_merges: int, min_frequency: int = 2) -> list[Pair]:
    """Apprend `n_merges` fusions. Lève TokenizerError si le corpus ne permet pas d'en apprendre autant."""
    if n_merges < 0:
        raise TokenizerError("nombre de fusions négatif")
    chunk_counts: Counter[str] = Counter()
    for text in texts:
        chunk_counts.update(split_text(normalize(text)))
    words: list[list[int]] = []
    freqs: list[int] = []
    for chunk in sorted(chunk_counts):  # tri : ordre indépendant du hasard de l'itération
        words.append([BYTE_BASE + b for b in chunk.encode("utf-8")])
        freqs.append(chunk_counts[chunk])

    pair_counts: Counter[Pair] = Counter()
    pair_words: dict[Pair, set[int]] = defaultdict(set)
    for wi, word in enumerate(words):
        for pair in zip(word, word[1:]):
            pair_counts[pair] += freqs[wi]
            pair_words[pair].add(wi)
    heap = [(-count, pair) for pair, count in pair_counts.items()]
    heapq.heapify(heap)

    merges: list[Pair] = []
    while len(merges) < n_merges:
        best: Pair | None = None
        best_count = 0
        while heap:
            neg, pair = heapq.heappop(heap)
            current = pair_counts.get(pair, 0)
            if current <= 0:
                continue
            if -neg != current:  # entrée périmée : on la remet avec le bon compte
                heapq.heappush(heap, (-current, pair))
                continue
            best, best_count = pair, current
            break
        if best is None or best_count < min_frequency:
            raise TokenizerError(
                f"corpus insuffisant : {len(merges)} fusions apprises sur {n_merges} demandées "
                f"(fréquence minimale {min_frequency}). Fournir plus de texte ou réduire le vocabulaire."
            )
        new_id = FIRST_MERGE_ID + len(merges)
        merges.append(best)
        touched: set[Pair] = set()
        for wi in sorted(pair_words.pop(best, ())):
            word, freq = words[wi], freqs[wi]
            if not any(p == best for p in zip(word, word[1:])):
                continue  # ensemble de mots périmé
            for pair in zip(word, word[1:]):
                pair_counts[pair] -= freq
            new_word = merge_pair(word, best, new_id)
            words[wi] = new_word
            for pair in zip(new_word, new_word[1:]):
                pair_counts[pair] += freq
                pair_words[pair].add(wi)
                touched.add(pair)
        pair_counts[best] = 0
        for pair in touched:
            if pair_counts[pair] > 0:
                heapq.heappush(heap, (-pair_counts[pair], pair))
    return merges


class BPE:
    """Encodeur/décodeur BPE d'octets pour une liste de fusions donnée."""

    def __init__(self, merges: list[Pair]) -> None:
        self.merges = [(int(a), int(b)) for a, b in merges]
        self._rank: dict[Pair, int] = {}
        self._token_bytes: list[bytes] = [bytes([i]) for i in range(256)]
        for rank, (a, b) in enumerate(self.merges):
            new_id = FIRST_MERGE_ID + rank
            if not (BYTE_BASE <= a < new_id and BYTE_BASE <= b < new_id):
                raise TokenizerError(f"fusion {rank} invalide : {(a, b)} (identifiants inconnus)")
            if (a, b) in self._rank:
                raise TokenizerError(f"fusion {rank} dupliquée : {(a, b)}")
            self._rank[(a, b)] = rank
            self._token_bytes.append(self._token_bytes[a - BYTE_BASE] + self._token_bytes[b - BYTE_BASE])
        self._cache: dict[str, tuple[int, ...]] = {}

    @property
    def n_ids(self) -> int:
        """Nombre total d'identifiants (spéciaux + octets + fusions)."""
        return FIRST_MERGE_ID + len(self.merges)

    def token_bytes(self, token_id: int) -> bytes:
        """Octets d'un identifiant ≥ 128 (pas de spéciaux ici)."""
        if not (BYTE_BASE <= token_id < self.n_ids):
            raise TokenizerError(f"identifiant hors vocabulaire : {token_id}")
        return self._token_bytes[token_id - BYTE_BASE]

    def encode_chunk(self, chunk: str) -> tuple[int, ...]:
        cached = self._cache.get(chunk)
        if cached is not None:
            return cached
        ids = [BYTE_BASE + b for b in chunk.encode("utf-8")]
        while len(ids) >= 2:
            best: Pair | None = None
            best_rank = len(self.merges)
            for pair in zip(ids, ids[1:]):
                rank = self._rank.get(pair)
                if rank is not None and rank < best_rank:
                    best, best_rank = pair, rank
            if best is None:
                break
            ids = merge_pair(ids, best, FIRST_MERGE_ID + best_rank)
        result = tuple(ids)
        if len(self._cache) < 200_000:
            self._cache[chunk] = result
        return result

    def encode(self, text: str) -> list[int]:
        out: list[int] = []
        for chunk in split_text(normalize(text)):
            out.extend(self.encode_chunk(chunk))
        return out
