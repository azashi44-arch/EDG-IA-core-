"""Pré-découpage du texte en morceaux avant le BPE (motif « edgia-split-v1 »).

Équivalent du motif de type GPT de la spécification §4.1 :

    (?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\\r\\n\\p{L}\\p{N}]?\\p{L}+|\\p{N}| ?[^\\s\\p{L}\\p{N}]+[\\r\\n]*|\\s*[\\r\\n]+|\\s+(?!\\S)|\\s+

écrit à la main avec `unicodedata` (le module `regex`, seul à connaître \\p{L}, n'est pas une dépendance). Les alternatives
sont essayées dans l'ordre, la première qui correspond gagne. Un test différentiel compare cette implémentation à `re`
sur un alphabet restreint (ASCII + Latin-1). Propriété garantie : la concaténation des morceaux redonne le texte.
"""

from __future__ import annotations

import unicodedata

PRETOKENIZER_ID = "edgia-split-v1"
_CONTRACTIONS = ("'s", "'t", "'re", "'ve", "'m", "'ll", "'d")


def _is_letter(ch: str) -> bool:
    return unicodedata.category(ch)[0] == "L"


def _is_number(ch: str) -> bool:
    return unicodedata.category(ch)[0] == "N"


def _is_punct(ch: str) -> bool:  # [^\s\p{L}\p{N}]
    return not ch.isspace() and not _is_letter(ch) and not _is_number(ch)


def _match_at(text: str, i: int) -> int:
    """Fin (exclue) du morceau qui commence en `i`."""
    n = len(text)
    ch = text[i]
    # 1. contractions
    if ch == "'":
        low = text[i : i + 3].lower()
        for c in _CONTRACTIONS:
            if low.startswith(c):
                return i + len(c)
    # 2. [^\r\n\p{L}\p{N}]?\p{L}+
    if _is_letter(ch):
        j = i + 1
        while j < n and _is_letter(text[j]):
            j += 1
        return j
    if ch not in "\r\n" and not _is_number(ch) and i + 1 < n and _is_letter(text[i + 1]):
        j = i + 2
        while j < n and _is_letter(text[j]):
            j += 1
        return j
    # 3. \p{N}
    if _is_number(ch):
        return i + 1
    # 4.  ?[^\s\p{L}\p{N}]+[\r\n]*
    j = i + 1 if ch == " " else i
    k = j
    while k < n and _is_punct(text[k]):
        k += 1
    if k > j:
        while k < n and text[k] in "\r\n":
            k += 1
        return k
    # ici `ch` est une espace blanche (toute autre classe a été traitée)
    end = i
    while end < n and text[end].isspace():
        end += 1
    # 5. \s*[\r\n]+ : jusqu'au dernier saut de ligne de la suite d'espaces blancs
    last_newline = -1
    for idx in range(i, end):
        if text[idx] in "\r\n":
            last_newline = idx
    if last_newline >= 0:
        return last_newline + 1
    # 6. \s+(?!\S) : toute la suite, sauf le dernier blanc s'il précède un caractère non blanc
    if end == n:
        return end
    if end - i > 1:
        return end - 1
    # 7. \s+
    return end


def split_text(text: str) -> list[str]:
    chunks: list[str] = []
    i, n = 0, len(text)
    while i < n:
        j = _match_at(text, i)
        if j <= i:  # garde-fou : ne devrait jamais arriver
            raise RuntimeError("le pré-découpage n'avance pas")
        chunks.append(text[i:j])
        i = j
    return chunks
