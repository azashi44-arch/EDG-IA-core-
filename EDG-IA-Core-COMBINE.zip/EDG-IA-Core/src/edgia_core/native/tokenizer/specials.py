"""Jetons spéciaux d'EDG-IA : identifiants FIGÉS pour toujours (spécification v1.1, §4).

Les 128 premiers identifiants sont réservés. Ils ne sont JAMAIS produits par l'encodage d'un texte : seul le code qui
assemble le gabarit de conversation (`encode_chat`) et le constructeur de jeux de données (séparateur de documents)
les insèrent, au niveau des identifiants.
"""

from __future__ import annotations

from edgia_core.native.hashing import sha256_json

N_SPECIAL = 128
BYTE_BASE = 128  # les 256 octets occupent les identifiants 128..383
FIRST_MERGE_ID = BYTE_BASE + 256  # 384

PAD, BOS, EOS, SYSTEM, USER, ASSISTANT, END, TOOL_CALL, TOOL_RESULT = range(9)

_NAMED = {
    PAD: "<|pad|>", BOS: "<|bos|>", EOS: "<|eos|>", SYSTEM: "<|system|>", USER: "<|user|>",
    ASSISTANT: "<|assistant|>", END: "<|end|>", TOOL_CALL: "<|tool_call|>", TOOL_RESULT: "<|tool_result|>",
}
SPECIAL_STRINGS: dict[int, str] = {i: _NAMED.get(i, f"<|reserved_{i:03d}|>") for i in range(N_SPECIAL)}

ROLE_IDS = {"system": SYSTEM, "user": USER, "assistant": ASSISTANT}

# Identifiants que le modèle n'a JAMAIS le droit de produire (les lignes d'embedding jamais entraînées gardent
# leur valeur d'initialisation : sans masque, elles pourraient être tirées). Seuls EOS et END terminent une génération.
TERMINATOR_IDS = frozenset({EOS, END})
FORBIDDEN_OUTPUT_IDS = frozenset(range(N_SPECIAL)) - TERMINATOR_IDS

LOCK_FORMAT = "edgia-special-tokens-v1"


def lock_document() -> dict[str, object]:
    """Contenu du fichier de verrouillage `configs/native/special_tokens.lock.json`."""
    tokens = [[i, SPECIAL_STRINGS[i]] for i in range(N_SPECIAL)]
    return {"format": LOCK_FORMAT, "count": N_SPECIAL, "tokens": tokens, "sha256": sha256_json(tokens)}


def lock_hash() -> str:
    return str(lock_document()["sha256"])
