"""Tokenizer EDG-IA : texte ↔ identifiants, gabarit de conversation, décodage en flux, sauvegarde/chargement.

SÉCURITÉ (spécification v1.1, §4.2) :
  * `encode_text` n'utilise QUE le BPE d'octets : aucune chaîne de caractères ne peut produire un identifiant < 128.
  * `encode_chat` assemble le gabarit AU NIVEAU DES IDENTIFIANTS ; le contenu des messages passe par `encode_text`.
    Un utilisateur qui écrit « <|end|> » obtient donc des tokens ordinaires, jamais l'identifiant 6.
  * Le décodage ignore les identifiants spéciaux ; le masque de sortie (`FORBIDDEN_OUTPUT_IDS`) est appliqué à l'échantillonnage.
"""

from __future__ import annotations

import codecs
import json
from collections.abc import Iterable, Sequence
from pathlib import Path
from typing import Any

from edgia_core.native.config import PROFILE_PRODUCTION, PROFILE_SMOKE, PROFILE_TEST, PRODUCTION_VOCAB, SMOKE_VOCAB
from edgia_core.native.errors import TokenizerError
from edgia_core.native.hashing import sha256_json
from edgia_core.native.tokenizer import specials
from edgia_core.native.tokenizer.bpe import BPE, train_merges
from edgia_core.native.tokenizer.pretokenizer import PRETOKENIZER_ID

TOKENIZER_FORMAT = "edgia-bpe-v1"
CHAT_TEMPLATE_DOC = (
    "<|bos|> puis, pour chaque message : <|system|>|<|user|>|<|assistant|> + contenu + <|end|> ; "
    "l'invite de génération se termine par <|assistant|>. Assemblé au niveau des identifiants."
)


def expected_vocab(profile: str) -> int | None:
    return {PROFILE_PRODUCTION: PRODUCTION_VOCAB, PROFILE_SMOKE: SMOKE_VOCAB}.get(profile)


class EdgiaTokenizer:
    def __init__(self, merges: list[tuple[int, int]], profile: str) -> None:
        self.profile = profile
        self._bpe = BPE(merges)
        want = expected_vocab(profile)
        if profile not in (PROFILE_PRODUCTION, PROFILE_SMOKE, PROFILE_TEST):
            raise TokenizerError(f"profil de tokenizer inconnu : {profile}")
        if want is not None and self._bpe.n_ids != want:
            raise TokenizerError(f"profil {profile} : vocabulaire de {self._bpe.n_ids} identifiants, {want} attendus")

    # --- propriétés ---------------------------------------------------------------------------------------------
    @property
    def vocab_size(self) -> int:
        return self._bpe.n_ids

    @property
    def merges(self) -> list[tuple[int, int]]:
        return list(self._bpe.merges)

    def tokenizer_hash(self) -> str:
        return sha256_json({
            "format": TOKENIZER_FORMAT, "pretokenizer": PRETOKENIZER_ID, "profile": self.profile,
            "merges": self._bpe.merges, "special_tokens_sha256": specials.lock_hash(),
        })

    # --- encodage -----------------------------------------------------------------------------------------------
    def encode_text(self, text: str) -> list[int]:
        """Texte → identifiants (tous ≥ 128). Ne reconnaît AUCUN jeton spécial dans le texte."""
        if not isinstance(text, str):
            raise TokenizerError("encode_text attend une chaîne")
        return self._bpe.encode(text)

    @staticmethod
    def _message_fields(message: Any) -> tuple[str, str]:
        if isinstance(message, dict):
            role, content = message.get("role"), message.get("content")
        else:
            role, content = getattr(message, "role", None), getattr(message, "content", None)
        if role not in specials.ROLE_IDS:
            raise TokenizerError(f"rôle de message inconnu : {role!r}")
        if not isinstance(content, str):
            raise TokenizerError("le contenu d'un message doit être une chaîne")
        return role, content

    def encode_chat(self, messages: Sequence[Any], *, add_generation_prompt: bool = True) -> list[int]:
        ids = [specials.BOS]
        for message in messages:
            role, content = self._message_fields(message)
            ids.append(specials.ROLE_IDS[role])
            ids.extend(self.encode_text(content))
            ids.append(specials.END)
        if add_generation_prompt:
            ids.append(specials.ASSISTANT)
        return ids

    # --- décodage -----------------------------------------------------------------------------------------------
    def token_bytes(self, token_id: int) -> bytes:
        """Octets émis pour un identifiant ; vide pour les identifiants spéciaux."""
        if 0 <= token_id < specials.N_SPECIAL:
            return b""
        return self._bpe.token_bytes(token_id)

    def decode(self, ids: Iterable[int], *, skip_special: bool = True) -> str:
        parts: list[bytes] = []
        for token_id in ids:
            if token_id < specials.N_SPECIAL:
                if not skip_special:
                    parts.append(specials.SPECIAL_STRINGS[token_id].encode("utf-8"))
            else:
                parts.append(self._bpe.token_bytes(token_id))
        return b"".join(parts).decode("utf-8", errors="replace")

    def stream_decoder(self) -> StreamDecoder:
        return StreamDecoder(self)

    # --- sérialisation ------------------------------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        return {
            "format": TOKENIZER_FORMAT, "pretokenizer": PRETOKENIZER_ID, "profile": self.profile,
            "vocab_size": self.vocab_size, "special_tokens_sha256": specials.lock_hash(),
            "merges": [list(pair) for pair in self._bpe.merges],
        }

    def save(self, directory: str | Path, *, manifest_extra: dict[str, Any] | None = None) -> dict[str, str]:
        out = Path(directory)
        out.mkdir(parents=True, exist_ok=True)
        (out / "tokenizer.json").write_text(json.dumps(self.to_dict(), ensure_ascii=True, separators=(",", ":")), encoding="utf-8")
        config = {
            "format": TOKENIZER_FORMAT, "profile": self.profile, "vocab_size": self.vocab_size,
            "special_tokens": {str(i): specials.SPECIAL_STRINGS[i] for i in range(specials.N_SPECIAL)},
            "role_ids": specials.ROLE_IDS, "terminator_ids": sorted(specials.TERMINATOR_IDS),
            "forbidden_output_ids": sorted(specials.FORBIDDEN_OUTPUT_IDS), "chat_template": CHAT_TEMPLATE_DOC,
        }
        (out / "tokenizer_config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        manifest = {
            "tokenizer_sha256": self.tokenizer_hash(), "special_tokens_sha256": specials.lock_hash(),
            "profile": self.profile, "vocab_size": self.vocab_size, **(manifest_extra or {}),
        }
        (out / "tokenizer_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        return manifest  # type: ignore[return-value]

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> EdgiaTokenizer:
        if raw.get("format") != TOKENIZER_FORMAT or raw.get("pretokenizer") != PRETOKENIZER_ID:
            raise TokenizerError("format de tokenizer inconnu")
        if raw.get("special_tokens_sha256") != specials.lock_hash():
            raise TokenizerError("verrou des identifiants réservés différent : tokenizer incompatible avec ce code")
        tok = cls([(int(a), int(b)) for a, b in raw["merges"]], str(raw["profile"]))
        if raw.get("vocab_size") != tok.vocab_size:
            raise TokenizerError("vocab_size incohérent avec la liste de fusions")
        return tok

    @classmethod
    def load(cls, directory: str | Path) -> EdgiaTokenizer:
        path = Path(directory) / "tokenizer.json"
        try:
            return cls.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except (OSError, json.JSONDecodeError) as exc:
            raise TokenizerError(f"tokenizer illisible : {path}") from exc


class StreamDecoder:
    """Décodage incrémental : n'émet que des caractères UTF-8 COMPLETS (un caractère coupé entre deux tokens est retenu)."""

    def __init__(self, tokenizer: EdgiaTokenizer) -> None:
        self._tokenizer = tokenizer
        self._decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")

    def feed(self, token_id: int) -> str:
        data = self._tokenizer.token_bytes(token_id)
        return self._decoder.decode(data, final=False) if data else ""

    def flush(self) -> str:
        """Fin de flux : les octets incomplets restants sont émis sous forme de U+FFFD."""
        return self._decoder.decode(b"", final=True)


class TrainCorpus:
    """Corpus autorisé pour l'entraînement du tokenizer : UNIQUEMENT le jeu `train` (spécification §4.6)."""

    def __init__(self, split: str, texts: Iterable[str]) -> None:
        if split != "train":
            raise TokenizerError(f"le tokenizer ne peut être entraîné que sur le jeu « train » (reçu : {split!r})")
        self.split = split
        self._texts = texts

    def __iter__(self):
        return iter(self._texts)


def train_tokenizer(corpus: TrainCorpus, *, profile: str, vocab_size: int | None = None, min_frequency: int = 2) -> EdgiaTokenizer:
    if not isinstance(corpus, TrainCorpus):
        raise TokenizerError("train_tokenizer exige un TrainCorpus (jeu « train » uniquement)")
    size = vocab_size if vocab_size is not None else expected_vocab(profile)
    if size is None:
        raise TokenizerError("profil sans taille imposée : préciser vocab_size")
    want = expected_vocab(profile)
    if want is not None and size != want:
        raise TokenizerError(f"profil {profile} : vocab_size doit valoir {want}")
    n_merges = size - specials.FIRST_MERGE_ID
    if n_merges < 0:
        raise TokenizerError(f"vocab_size minimal : {specials.FIRST_MERGE_ID}")
    return EdgiaTokenizer(train_merges(corpus, n_merges, min_frequency), profile)
