# Mission technique 01 — stabilisation des tests et du système d'évaluation

## 1. Diagnostic

**Les quatre échecs signalés n'ont PAS été reproduits.** Sur l'archive `EDG-IA-Core_phase8.zip` extraite dans un dossier vierge :

| Condition essayée | Commande | Résultat |
|---|---|---|
| Linux, Python 3.13.16, root | `PYTHONPATH=src python3 -W error -m unittest discover -s tests -t .` | 359 tests, **OK**, 0 échec, 0 ignoré |
| Même chose, utilisateur sans privilège (uid 65534) | idem via `setpriv` | 359 tests, **OK** |
| Utilisateur sans privilège avec 25 processus déjà actifs | tests `eval_sandbox` + `eval_runner` | OK |
| Démarrage de Python sous 16–256 Mo d'espace virtuel (3.11, 3.12, 3.13) | `ulimit -v` | démarre dès 16 Mo : la limite de 256 Mo n'est pas en cause |
| Python 3.11 et 3.12 : syntaxe des 74 fichiers | `ast.parse` | OK |
| Python 3.11 et 3.12 : tests réels du bac à sable avec un `CheckSpec` simplifié (pydantic non installable ici) | script de test | 14 tests, 0 échec chacun |

**Non exécutable ici** : pytest (absent, PyPI inaccessible), Windows, macOS, suite complète sous Python 3.11/3.12 (pydantic absent pour ces versions). L'environnement de la première exécution n'est pas connu : sans son journal d'erreurs, je ne peux pas désigner sa cause. **Demande : envoyer le journal complet (système, version de Python, commande, messages d'erreur).**

## 2. Défauts réels trouvés en cherchant des conditions différentes (reproduits, puis corrigés)

1. **Bac à sable : échec de démarrage non géré** (`src/edgia_core/evaluation/sandbox.py`). Si le système refuse une limite (ex. `RLIMIT_AS` sous macOS, simulé par une `ValueError`) ou si le lancement échoue, `subprocess.SubprocessError`/`OSError` remontait, et `run_suite` (qui appelle les vérifications hors de son `try`) **faisait planter toute l'évaluation**. Correction : ces erreurs donnent un résultat « non exécuté » (`skipped`) ; le code n'est jamais lancé sans ses limites et jamais déclaré réussi. Aucune limite n'est assouplie.
2. **Test dépendant de la plateforme** (`tests/unit/test_eval_runner.py`, `test_limit_metadata_and_json_serialisable`). Il exigeait une mesure de mémoire non vide ; sans module `resource` (Windows), elle est légitimement `None`. Reproduit en simulant l'absence de `resource` : 1 échec. Le test vérifie désormais « mesure présente si `resource` existe, sinon `None` ». Défaut dans le **test**, pas dans le moteur.
3. **Rapport** (`src/edgia_core/evaluation/report.py`) : afficherait « None Mo » sans mesure. Il affiche maintenant « indisponible sur cette plateforme ».

## 3. Tests ajoutés (aucun test supprimé ni affaibli)

- `SandboxStartFailureTest` (2 tests) : limite refusée ; lancement impossible → `skipped`, jamais `pass`.
- `test_sandbox_start_failure_does_not_crash_the_evaluation` : l'évaluation va jusqu'au bout, les cas de code sont `partial`.
- `test_report_without_memory_measurement_says_unavailable`.
- Vérifié : les nouveaux tests **échouent sur l'ancien code** (4 erreurs) et **passent sur le nouveau**.

## 4. Résultats après correction (exécutés)

- Suite complète, root : **363 tests OK** ; non-root : **363 tests OK** (avec `-W error`).
- Simulation « sans module resource » : 62 tests d'évaluation, 0 échec, 0 erreur, 16 ignorés.

## 5. Sécurité

Modification de sécurité : **aucun contrôle supprimé ni assoupli** ; la seule modification du bac à sable est un `try/except` qui refuse d'exécuter. Sondes mesurées (voir `docs/EVALUATION.md`) : pas d'isolation du système de fichiers ni du réseau ; la limite de processus n'est **pas appliquée à root** (40 processus créés en root, bloqué en non-root). Correction sûre proposée, **non appliquée** car elle change le comportement : refuser `--allow-code-execution` quand l'utilisateur est root, sauf option explicite. Le `Dockerfile` utilise déjà un utilisateur non-root.

## 6. Problèmes encore présents

- Causes exactes des 4 échecs d'origine : **inconnues** (non reproduits).
- pytest, Windows, macOS, Python 3.11/3.12 (suite complète) : non testés.
- Isolation réseau et fichiers du bac à sable : inexistante (documentée).
- Tous les points de `docs/BILAN.md` (aucun vrai modèle, Docker jamais construit, etc.) restent valables : le projet n'est **pas** déclaré entièrement fonctionnel.

## 7. Fichiers modifiés

`src/edgia_core/evaluation/sandbox.py`, `src/edgia_core/evaluation/report.py`, `tests/unit/test_eval_sandbox.py`, `tests/unit/test_eval_runner.py`, `docs/EVALUATION.md` (section ajoutée), `docs/MISSION_01_RAPPORT.md` (nouveau).
