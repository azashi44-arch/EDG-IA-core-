# Guide pour l'équipe d'entraînement : livrer et brancher un modèle

> **État honnête** : le chargement d'un vrai modèle (`inference/hf_backend.py`) n'a **jamais été exécuté** : PyTorch,
> Transformers et des poids n'étaient pas disponibles là où le code a été écrit. La logique autour (arrêts, annulation,
> streaming, registre, démarrage) est testée avec un backend factice ; le backend lui-même n'est vérifié que par un
> test de fumée avec de fausses bibliothèques. **Le premier chargement réel est l'étape de validation** : attendez-vous
> à devoir ajuster quelques appels selon la version de Transformers installée.

## Ce qu'il faut livrer

Un dossier contenant :

1. **Le modèle** : un dossier au format Hugging Face Transformers (`config.json` + fichiers `.safetensors`).
   Les formats pickle (`.bin`, `.pt`) sont refusés. Le format GGUF / `llama_cpp` n'est **pas encore** pris en charge.
2. **Le tokenizer** : dossier du tokenizer, **avec un `chat_template`** (version « instruct »). Sans lui, le serveur refuse de démarrer.
3. **Facultatif, un adaptateur LoRA** : dossier de l'adaptateur (PEFT). `weights_path` désigne alors le **modèle de base**.
   Un modèle déjà fusionné (poids complets réentraînés) se livre sans adaptateur.
4. **La licence** du modèle de base, et des données d'adaptation si elles sont soumises à droits.
5. **Les sommes SHA-256** de chaque fichier de poids (`sha256sum *.safetensors`).

## Décrire le modèle

Copiez `configs/model.example.yaml` en `configs/model.yaml` et renseignez : identifiant, version, chemins, licence,
matériel, adaptation, sommes SHA-256. **`license.reviewed: true` doit être mis par un humain** après lecture du texte
intégral de la licence ; `commercial_use_allowed: true` doit être confirmé (EDG-IA est un produit payant).

## Installer les dépendances (sur la machine avec le GPU ou le CPU de production)

```bash
pip install torch transformers          # versions à noter dans docs/DEPENDANCES.md après le premier test réussi
pip install peft                        # seulement avec un adaptateur LoRA
```

## Valider (avant tout service)

```bash
# 1. Le descripteur, les fichiers, la licence et les sommes sont-ils valides ?
EDGIA_MODE=real EDGIA_MODEL_DESCRIPTOR=configs/model.yaml EDGIA_API_KEYS=<clé de 24+ caractères> \
  PYTHONPATH=src python3 -m edgia_core check-config

# 2. Le modèle se charge-t-il, répond-il, s'interrompt-il, diffuse-t-il ? (le test n'a jamais encore été exécuté)
EDGIA_REAL_MODEL_DESCRIPTOR=configs/model.yaml PYTHONPATH=src python3 -m unittest discover -s tests/real_model -v
```

Notez le temps de chargement, la mémoire GPU/RAM utilisée et la vitesse (tokens par seconde) : ces mesures n'existent
pas encore et décideront de la capacité réelle du serveur.

## Gérer les versions (registre)

```bash
R=data/registry.sqlite3
PYTHONPATH=src python3 -m edgia_core models --registry $R register configs/model.yaml
PYTHONPATH=src python3 -m edgia_core models --registry $R validate edgia-core 1.0.0   # licence + fichiers + SHA-256
PYTHONPATH=src python3 -m edgia_core models --registry $R activate edgia-core 1.0.0   # revalide, puis active
PYTHONPATH=src python3 -m edgia_core models --registry $R rollback                    # revient à la version remplacée
PYTHONPATH=src python3 -m edgia_core models --registry $R list
PYTHONPATH=src python3 -m edgia_core models --registry $R history
```

Une version enregistrée est **immuable** (nouvelle version = nouvel enregistrement). Une version ne peut être activée
qu'après validation réussie, **revalidée à l'instant de l'activation** (les fichiers ont pu changer). Une seule version
est active à la fois.

## Servir

```bash
# Depuis un descripteur :
EDGIA_MODE=real EDGIA_MODEL_DESCRIPTOR=configs/model.yaml EDGIA_API_KEYS=<clé> PYTHONPATH=src python3 -m edgia_core serve
# …ou depuis la version active du registre (l'un OU l'autre, pas les deux) :
EDGIA_MODE=real EDGIA_REGISTRY_PATH=data/registry.sqlite3 EDGIA_API_KEYS=<clé> PYTHONPATH=src python3 -m edgia_core serve
```

Le chargement se fait **avant** l'ouverture du port : le serveur peut mettre plusieurs minutes à répondre. Si un fichier
manque, si la licence n'est pas vérifiée, si une somme est fausse ou si le chargement échoue, le serveur **refuse de
démarrer** ; il ne sert jamais le modèle de démonstration à la place. Changer de version = activer dans le registre puis
**redémarrer** le service (pas de rechargement à chaud).

## Limites à connaître

- **Une seule génération à la fois sur le modèle** : les générations sont sérialisées, sans traitement par lots. Mettez
  `EDGIA_MAX_CONCURRENT_REQUESTS` à une petite valeur (1 à 4) ; au-delà, le serveur répond `503`. Pour plus de débit,
  il faudra un moteur d'inférence spécialisé (batching continu) : non prévu dans cette version.
- Le modèle est placé sur **un seul périphérique** (`.to(device)`). Les modèles trop gros pour un GPU ne sont pas répartis automatiquement.
- La quantification (4 bits, QLoRA) n'est **pas** gérée au chargement : le modèle se charge dans sa précision d'origine
  (`dtype="auto"`), donc un modèle de 27 milliards en 16 bits demande environ 54 Go de mémoire pour les poids seuls.
- Le décompte de tokens du prompt vient du vrai tokenizer ; la fenêtre de contexte autorisée est celle de
  `EDGIA_MAX_CONTEXT_TOKENS`, que **vous** devez régler selon la capacité réelle du modèle (non lue automatiquement).
- Le temps de chargement et la consommation mémoire ne sont pas encore mesurés par le serveur.

## Parcours complet de l'équipe d'entraînement (phases 4 à 7)

Ordre recommandé, chaque étape s'appuie sur la précédente. Aucune de ces étapes n'a été exécutée avec un vrai modèle.

1. **Choisir le modèle de base** : comparer les candidats (`MODELES_CANDIDATS.md`) avec `edgia-core eval run --descriptor …` sur
   `configs/eval/starter`, puis faire relire les cas « à relire » par un humain (`EVALUATION.md`). Faire lire la licence en texte intégral.
2. **Préparer les données** (`DONNEES.md`) : fichiers JSONL avec source et licence, `data prepare --eval-suite configs/eval/starter`
   (anti-contamination obligatoire), relire un échantillon de `train.jsonl`.
3. **Planifier puis entraîner** : `train plan` (refuse au moindre doute), puis `train run --confirm-training`. Premier essai sur un
   très petit jeu et un petit modèle pour valider la boucle (jamais exécutée).
4. **Évaluer** l'adaptateur : `eval run` sur la même suite que la base, `eval compare base adapté`, relecture humaine.
5. **Enregistrer et activer** : relire la licence du modèle adapté (`descriptor_suggestion.yaml` la remet à « non vérifiée »),
   `models register` → `validate` → `activate`, puis `tests/real_model` sur la machine cible.
6. **Déployer** (`DEPLOIEMENT.md`) : `doctor`, mode démonstration d'abord, puis réel ; sauvegardes et procédures (`EXPLOITATION.md`).
7. **Connaissances externes** (programme scolaire, règlements) : base documentaire (`KNOWLEDGE.md`), sans réentraîner.

Règles qui ne changent jamais : aucune capacité n'est annoncée avant d'avoir été mesurée sur le vrai modèle ; aucun
téléchargement ni entraînement coûteux sans confirmation ; aucune donnée sans source ni droits ; aucun repli silencieux sur la démonstration.
