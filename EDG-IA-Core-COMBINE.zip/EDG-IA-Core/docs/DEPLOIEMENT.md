# Déploiement d'EDG-IA Core (phase 7)

> **État** : rien de ce document n'a été appliqué sur un vrai serveur. `Dockerfile`, `compose.yaml` et les fichiers de
> `deploy/` n'ont **jamais été exécutés** (pas de Docker, de systemd, de proxy ni de GPU dans l'environnement de
> développement). Seuls `edgia-core doctor` et `edgia-core backup` sont testés. Le premier déploiement doit se faire en
> **mode démonstration** (sans modèle) pour valider la chaîne, puis en mode réel.

## 1. Choisir la machine (point bloquant : la mémoire)

Le chargeur actuel met le modèle **sur un seul périphérique, dans sa précision d'origine**, sans quantification ni
répartition sur plusieurs GPU (voir `GUIDE_SPECIALISTES.md`). Conséquence directe pour le dimensionnement :

| Modèle (poids 16 bits) | Poids seuls | Machine minimale avec le chargeur actuel |
|---|---|---|
| 7-8 milliards | ≈ 14-16 Go | 1 GPU 24 Go, ou CPU avec 32 Go de RAM (lent) |
| 14 milliards | ≈ 28 Go | 1 GPU 40 Go |
| 27-32 milliards | ≈ 54-64 Go | **1 GPU 80 Go** (un GPU 24 Go ne suffit pas) |

Les chiffres « 24 Go en 4 bits » de `MODELES_CANDIDATS.md` **ne s'appliquent pas** tant que la quantification n'est pas
prise en charge. Ajoutez la mémoire du cache de génération (croît avec la longueur du contexte et la concurrence) : prévoir
une marge d'au moins 20 %. Ces ordres de grandeur sont des calculs, **pas des mesures** : aucun modèle n'a été chargé.
Décisions à prendre avec l'équipe d'entraînement : modèle de base, précision, matériel. `edgia-core doctor` compare la
taille des poids à la mémoire et au GPU détectés, et dit « échec » si le modèle ne peut manifestement pas tenir.

Débit : une seule génération à la fois (pas de traitement par lots). Pour une charge élevée (nombreux élèves simultanés),
prévoir plusieurs instances derrière un répartiteur, ou un moteur d'inférence spécialisé (non prévu dans cette version).
Aucun test de charge n'a été fait.

## 2. Préparer

1. Copier `.env.example` en `.env` (droits `600`) ; générer une clé d'API :
   `python -c "import secrets; print(secrets.token_urlsafe(32))"` → `EDGIA_API_KEYS`. Jamais de clé dans le dépôt ni dans une image.
2. Mode démonstration pour commencer : `EDGIA_MODE=demo`. Mode réel : voir `GUIDE_SPECIALISTES.md` (descripteur ou registre,
   licence vérifiée, sommes SHA-256).
3. Lancer le diagnostic **sur la machine cible** : `python -m edgia_core doctor --env-file .env`
   (code de sortie 2 = ne pas démarrer). Il vérifie Python, dépendances, bibliothèques d'IA, GPU, mémoire, espace disque,
   port, configuration et réglages risqués.

## 3. Installer — deux voies

**A. Sans Docker (systemd)** : environnement virtuel, `pip install '.[ml]'` (`ml` seulement en mode réel), `deploy/edgia-core.service`
(à adapter). L'unité lance `doctor` avant chaque démarrage et redémarre le service en cas d'échec.

**B. Docker** : `docker build --build-arg EXTRAS=ml -t edgia-core .` puis `docker compose up -d`. Dans le conteneur, les chemins
du `.env` sont ceux **vus du conteneur** (`/models`, `/app/data`, `/app/configs`). Pour un GPU NVIDIA : activer le bloc
`deploy` de `compose.yaml` (nécessite le NVIDIA Container Toolkit). L'image n'a jamais été construite.

## 4. Exposer en sécurité

Le serveur écoute en local par défaut et **ne gère pas TLS**. Pour l'ouvrir au réseau :
- placez un proxy TLS devant (`deploy/Caddyfile.example` ou `deploy/nginx.conf.example`, jamais testés) ; le streaming exige de
  désactiver la mise en mémoire tampon, les délais doivent dépasser `EDGIA_REQUEST_TIMEOUT_SECONDS` ;
- derrière un proxy, toutes les requêtes semblent venir de l'adresse du proxy : le blocage après échecs d'authentification
  protège alors le proxy entier, pas chaque client (voir `API.md`) ; la limite de débit réelle par client relève du proxy ;
- ne publiez jamais directement le port 8000 ; gardez `127.0.0.1:8000:8000` dans `compose.yaml` ;
- `EDGIA_ALLOWED_ORIGINS` : seulement les origines des applications autorisées, jamais `*` en production.

## 5. Liste de contrôle avant ouverture

- [ ] `doctor` sans « ÉCHEC » ; les « ATTN » lues et acceptées par écrit.
- [ ] `GET /health` répond ; `GET /ready` répond 200 **et `demo: false`** en mode réel.
- [ ] Une requête authentifiée à `POST /v1/chat/completions` réussit ; une requête sans clé reçoit 401.
- [ ] `tests/real_model` exécuté sur la machine cible (jamais encore lancé) et évaluation `eval run` + relecture humaine.
- [ ] Licence du modèle relue par un humain (`license.reviewed` seulement après lecture).
- [ ] Sauvegarde faite et vérifiée (`edgia-core backup … && edgia-core backup --verify …`) ; procédure de restauration répétée.
- [ ] TLS en place ; clés d'API distinctes par client ; `.env` en `600`.
- [ ] Journaux : `EDGIA_LOG_REDACT_CONTENT=true` (contenu des messages jamais journalisé).
- [ ] Surveillance externe de `/health` et `/ready` (pas de page de métriques intégrée).

## 6. Ce qui n'existe pas encore

Métriques (Prometheus), alertes, rechargement à chaud d'un modèle ou d'une clé (redémarrage nécessaire), haute
disponibilité, limite de débit partagée entre instances, multi-établissements (une base documentaire par établissement),
test de charge, procédure de montée de version automatisée.
