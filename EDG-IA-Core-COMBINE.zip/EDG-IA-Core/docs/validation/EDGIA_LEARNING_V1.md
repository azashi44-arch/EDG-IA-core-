# Apprentissage par le chat v1 — rapport

Voir `docs/LEARNING.md`. Livré : module `learning/` (stockage SQLite, publication, retrait, export), routes `POST/GET /v1/learning/lessons` et
`DELETE /v1/learning/lessons/{id}`, commande `edgia-core learning`, 3 réglages `EDGIA_LEARNING_*`, sauvegarde `--learning`, client Node (`teach`, `lessons`, `withdrawLesson`), OpenAPI et API.md à jour.

## Vérifié (exécuté)
- `tests/unit/test_learning.py` : 14 tests réussis (stockage, consentement, masquage PII, doublons, quota, isolation entre clés, publication dans la base documentaire puis recherche, retrait, export, CLI complète), Python 3.12, `-W error`.
  Exécutés **avec une cale minimale de pydantic** (pydantic/starlette non installables dans l'environnement de développement) : aucune validation pydantic n'a donc servi.
- `docs/openapi.yaml` lisible, tous les codes d'erreur de l'énumération sont dans `API.md` ; `node --check` du client ; compilation de tous les fichiers modifiés.

## NON exécuté
- `tests/unit/test_learning_api.py` (routes HTTP) et le schéma `LessonRequest` : écrits, jamais lancés (starlette/pydantic absents).
- Suite complète du dépôt, `test_contract` (cohérence OpenAPI ↔ routes), `test_ops` (variables ↔ `.env.example`), `test_node_client` : non lancés ; à exécuter avant toute fusion.
- Aucun test avec un vrai modèle ; l'effet des faits enseignés sur les réponses n'est pas mesuré.
- `tools/verify_untouched.py` renvoyait déjà « NON CONFORME » (pack de connaissances v1 ajouté hors des dossiers autorisés) ; cette livraison modifie en plus `api/app.py`, `api/schemas.py`, `api/http.py`, `config.py`, `cli.py`, `ops/`, `.env.example`, docs.
