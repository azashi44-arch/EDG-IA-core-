# Apprendre en discutant (leçons proposées par chat)

Les utilisateurs peuvent **enseigner** quelque chose à l'assistant pendant une conversation. Deux voies, volontairement séparées :

| | Fait (`fact`) | Exemple (`example`) |
|---|---|---|
| Contenu | une information (« La capitale politique du Cameroun est Yaoundé ») | une conversation corrigée : la question et la réponse que l'assistant aurait dû donner |
| Après relecture humaine | indexé dans la base documentaire (collection `appris-chat`) : **utilisé dès la question suivante** | mis de côté, exportable en JSONL |
| Poids du modèle | **inchangés** | inchangés tant qu'un humain ne lance pas un entraînement (voir plus bas) |

> **Ce que cette fonction n'est pas** : l'assistant ne se réentraîne jamais tout seul en discutant. Un fait enseigné devient une connaissance
> externe (comme un document), consultable et retirable à tout moment. Modifier les poids reste une opération séparée, planifiée et approuvée par un humain
> (`DONNEES.md`, `EVALUATION.md`). C'est volontaire : un entraînement automatique sur des messages d'inconnus permettrait d'empoisonner le modèle.

## Parcours

1. **Configurer** (une fois) :
   ```bash
   PYTHONPATH=src python -m edgia_core learning --db data/learning.sqlite3 init
   PYTHONPATH=src python -m edgia_core knowledge --db data/knowledge.sqlite3 seed-starter   # si la base documentaire n'existe pas encore
   ```
   ```dotenv
   EDGIA_LEARNING_DB=data/learning.sqlite3
   EDGIA_KNOWLEDGE_DB=data/knowledge.sqlite3
   EDGIA_KNOWLEDGE_AUTO_SEARCH=true      # pour que les faits validés servent automatiquement
   ```
2. **L'application propose une leçon** (appel de serveur à serveur, avec une clé d'API ; l'utilisateur doit avoir **coché** le consentement) :
   ```bash
   curl -s http://127.0.0.1:8000/v1/learning/lessons -H "Authorization: Bearer $EDGIA_API_KEY" -H "Content-Type: application/json" \
     -d '{"kind":"fact","consent":true,"text":"La capitale politique du Cameroun est Yaoundé."}'
   ```
   Pour une correction : `{"kind":"example","consent":true,"messages":[{"role":"user","content":"…"},{"role":"assistant","content":"réponse corrigée"}]}`.
   Côté interface : un bouton « Corriger / enseigner » sous une réponse, qui envoie la question et la réponse corrigée ; ou un message « retiens que… »
   que l'application transforme en `fact`. Le client Node de référence offre `teach()`, `lessons()` et `withdrawLesson()`.
3. **Un humain relit** :
   ```bash
   edgia-core learning --db data/learning.sqlite3 list --status pending
   edgia-core learning --db data/learning.sqlite3 show les-1a2b3c4d5e6f
   edgia-core learning --db data/learning.sqlite3 approve les-1a2b3c4d5e6f --knowledge-db data/knowledge.sqlite3 --note "vérifié"
   edgia-core learning --db data/learning.sqlite3 reject  les-… --note "faux"
   ```
4. **Option, pour améliorer les poids un jour** :
   ```bash
   edgia-core learning --db data/learning.sqlite3 export --out data/lecons-validees.jsonl
   edgia-core data prepare data/lecons-validees.jsonl --allow-user-conversations --eval-suite configs/eval/starter --out data-prepared/v2
   ```
   puis `train plan`, `eval run`, `eval compare` et relecture humaine, comme pour toute donnée. `data prepare` applique encore ses filtres
   (qualité, données personnelles, anti-contamination, doublons). Les exemples seuls sont rarement assez nombreux : `train plan` exige un minimum.

## Garde-fous

- **Consentement explicite** (`consent: true`) obligatoire, inscrit dans la donnée ; sinon `422 consent_required`.
- **Rien n'est utilisé avant relecture.** Option `EDGIA_LEARNING_AUTO_APPROVE_FACTS=true` : les faits sont indexés sans relecture. À réserver à un usage privé (un seul
  utilisateur de confiance) ; sinon n'importe quelle clé pourrait injecter de fausses informations ou des consignes cachées.
- **Données personnelles** : courriels, téléphones, suites de chiffres, IBAN et URL avec identifiants sont masqués à l'entrée (`pii_redactions` en donne le nombre).
  **Les noms et adresses ne sont pas détectés** : l'humain qui relit doit les repérer.
- **Retrait du consentement** : `DELETE /v1/learning/lessons/{id}` (ou `learning delete`) supprime la leçon et le document indexé. Un export déjà
  produit, ou un modèle déjà entraîné dessus, ne sont pas modifiés : ces cas se traitent à la main.
- **Isolation entre auteurs** : une clé ne voit, ne liste et ne supprime que ses propres leçons ; le contenu n'est jamais renvoyé par l'API.
  L'identité est la position de la clé (`key-1`…) : changer l'ordre de `EDGIA_API_KEYS` change l'auteur apparent. Sans authentification (boucle locale), toutes les requêtes ont la même identité.
- **Limites** : 10 à 2000 caractères par fait ; 2 à 12 messages par exemple ; rôle `system` refusé ; `EDGIA_LEARNING_MAX_PENDING_PER_KEY` leçons en attente par clé ; doublons refusés.
- Les faits indexés restent des **données non fiables** pour le modèle (même délimitation que les autres documents, voir `KNOWLEDGE.md`) et apparaissent dans `edgia.sources` avec la source « Enseigné par chat ».
- Sauvegarde : `edgia-core backup --learning data/learning.sqlite3 --out …`. Le fichier contient le texte des utilisateurs en clair : protégez-le.

## Limites connues

- La recherche documentaire est lexicale : un fait enseigné avec d'autres mots que la question suivante peut ne pas être retrouvé.
- Un fait validé n'est pas revérifié : si l'opérateur approuve une erreur, l'assistant la répétera jusqu'au retrait du document.
- Pas de rôles d'administration par API : la relecture se fait en ligne de commande sur la machine (volontairement).
- Rien n'a été mesuré avec un vrai modèle : on ne sait pas encore s'il exploite bien les faits enseignés.
