# Modèles candidats pour EDG-IA Core (assistant généraliste)

> **Ce document n'arrête aucun choix.** Il prépare la décision avec l'équipe d'entraînement. Recherche faite le
> 15 octobre 2026 sur des pages web ; **aucune licence n'a été lue dans son texte intégral**, et l'une d'elles est
> contestée entre deux sources (voir « À vérifier »). La licence réelle doit être lue par un humain dans le dépôt du
> modèle avant tout usage commercial (champ `license.reviewed` du descripteur).

## Objectif

Un assistant généraliste « à la ChatGPT » : conversation en français et en anglais, explication, rédaction, résumé,
aide à la programmation, suivi d'instructions. EDG-IA est un produit payant : l'**usage commercial** est obligatoire.

## Ce qu'il faut savoir avant de choisir

1. **Entraîner un modèle généraliste à partir de zéro n'est pas réaliste** pour ce projet (données, calcul, coût).
   La voie réaliste : partir d'un modèle ouvert déjà préentraîné, puis l'adapter (SFT/LoRA) au français, au ton
   pédagogique et aux contextes d'EDG-IA. C'est ce que prévoit le prompt maître.
2. **Le niveau de ChatGPT n'est pas garanti.** Les plus gros modèles ouverts (centaines de milliards de paramètres,
   plusieurs GPU de centre de données) s'en approchent ; les modèles de 27 à 31 milliards qui tiennent sur un seul
   GPU sont nettement plus modestes. Aucune qualité ne sera affirmée avant les évaluations de la phase 5.
3. **Le français doit être mesuré, pas supposé.** Aucune des pages consultées ne détaille la qualité en français.

## Candidats (état des sources au 15 octobre 2026)

| Modèle | Taille | Licence annoncée | Usage commercial | Matériel (estimation) | Fiabilité de l'information |
|---|---|---|---|---|---|
| Qwen3.8-27B (Alibaba) | 27 milliards, dense | Apache-2.0 | Oui, attribution | 1 GPU 24 Go en 4 bits | **Licence lue sur la page officielle du modèle** (Hugging Face) ; langues non listées sur cette page |
| Gemma 4 31B (Google) | 31 milliards, dense | **Contradictoire** : « Gemma License » (onyx.app) ou Apache 2.0 (codersera.com) | À vérifier | 1 GPU 24 Go en 4 bits (estimation) | Page officielle non lue (accès échoué) |
| gpt-oss-20b / 120b (OpenAI) | 20 / 120 milliards, MoE (120b) | Apache 2.0 | Oui, attribution | non vérifié | Une seule source secondaire |
| Muse Glimmer 30B | 30 milliards, dense | Apache 2.0 | Oui, attribution | non vérifié | Une seule source secondaire |
| DeepSeek V4-Flash / V4-Pro, GLM-5.2 | 284 à 1 600 milliards, MoE | MIT | Oui | Très gros : « 16 × H100 80 Go » cité pour les plus grands | Sources secondaires ; hors de portée d'un petit serveur |
| Llama 4 Maverick (Meta) | MoE, 17 milliards actifs | Llama 4 Community | Licence séparée au-delà de 700 M d'utilisateurs, mention « Built with Llama » | non vérifié | Une seule source secondaire |
| Qwen3.8-Flash-Next, Kimi K3, MiniMax M3, Mistral Medium 3.5 | divers | Licences personnalisées | Conditions particulières (services d'IA, seuils de revenus…) | — | **Écartés pour l'instant** : conditions à lire une par une |

Sources : [onyx.app](https://onyx.app/insights/best-open-source-llms-2026) (mise à jour le 13/10/2026),
[codersera.com](https://codersera.com/blog/open-source-llms-landscape-2026/) (5/10/2026),
[fiche Hugging Face de Qwen3.8-27B](https://huggingface.co/Qwen/Qwen3.8-27B),
[aicybr.com (matériel)](https://aicybr.com/blog/local-llm-vram-ram-requirements-2026).

## Matériel (ordres de grandeur, poids seuls ; le cache de contexte et le moteur ajoutent de la mémoire)

| Taille | 4 bits | 16 bits | Machine type |
|---|---|---|---|
| 7-8 milliards | ≈ 3,5 Go | ≈ 14 Go | GPU 8 Go, ou CPU avec 32 Go de RAM |
| 14 milliards | ≈ 7 Go | ≈ 28 Go | GPU 12 Go |
| 30-32 milliards | ≈ 16 Go | ≈ 64 Go | GPU 24 Go (4 bits) |
| 70 milliards | ≈ 35 Go | ≈ 140 Go | GPU 48 Go |

Un modèle de 27 milliards en 16 bits représente environ 54 Go de poids (calcul : 27 × 2 octets). Sur CPU seul,
le service est possible mais lent : adapté à un usage peu fréquent, pas à un assistant interactif pour de nombreux élèves.

## À vérifier avant toute décision

- **Licence de Gemma 4** : lire le fichier de licence dans le dépôt officiel du modèle (deux sources se contredisent).
- **Licence de chaque candidat retenu** : lire le texte intégral, pas un résumé ; puis passer `license.reviewed` à `true`.
- **Qualité en français** : mesurer avec les évaluations de la phase 5, sur des exemples réels d'EDG-IA.
- **Matériel réel** du serveur de production (GPU, mémoire) : à confirmer avec toi et l'équipe d'entraînement.
- **Format des poids** : safetensors pour tous les candidats ci-dessus d'après les sources ; GGUF ne serait qu'une
  conversion pour le CPU.

## Recommandation provisoire

Comparer d'abord **Qwen3.8-27B** (licence Apache-2.0 confirmée sur la page officielle) et **Gemma 4 31B** (sous
réserve de sa licence) sur un jeu de questions en français représentatif d'EDG-IA, avant de choisir. Les très gros
modèles ne se justifient que si le budget GPU le permet.
