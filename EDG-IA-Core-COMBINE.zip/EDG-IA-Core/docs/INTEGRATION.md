# Intégration d'EDG-IA Core dans l'application EDG-IA

> **Base de ce document** : le code de l'application (archive `EDG-IA_v7_2_0_SOURCE`, fichiers `backend/src/ai/ai-provider.ts` et `ai.service.ts`) a été lu en lecture seule ; **aucun fichier de l'application n'a été modifié**.
> Le comportement décrit dans « Constat sur le code réel » a été vérifié en exécutant une copie du fournisseur de l'application contre un vrai serveur Core **de démonstration**. Rien n'a été vérifié avec un vrai modèle ni dans l'application complète (NestJS, base, quotas).

## Constat sur le code réel de l'application

Le fournisseur `AIProvider` a déjà une branche `openai-compatible` (`AI_PROVIDER=openai-compatible`) qui appelle `{AI_BASE_URL}/chat/completions` avec seulement `model`, `messages`, `temperature`, `max_tokens` : ce sont des champs que Core accepte. **Aucun nouveau fournisseur n'est nécessaire.** Mais quatre pièges existent :

| # | Problème | Effet constaté | Remède |
|---|---|---|---|
| 1 | L'application ne regarde pas `edgia.demo` | Un serveur de **démonstration** serait présenté aux élèves comme une vraie IA | Patch `integration/app-patch/ai-provider.edgia-core.patch` (3 lignes ajoutées, aucune supprimée) : refuse la démo (`AI_DEMO_MODEL_REFUSED`) sauf `EDGIA_CORE_ALLOW_DEMO=true`. Vérifié : refus par défaut, accepté avec la variable |
| 2 | L'application demande `max_tokens` = 1400 par défaut ; Core limite à `EDGIA_MAX_NEW_TOKENS` (512 par défaut) | **Chaque requête échoue en 422** (vérifié) | Régler `EDGIA_MAX_NEW_TOKENS` ≥ 1400 côté Core (et `EDGIA_MAX_CONTEXT_TOKENS` ≥ prompt + max_tokens), ou baisser `AI_MAX_TOKENS` côté application |
| 3 | `AI_TIMEOUT_MS` vaut 30 000 par défaut ; un vrai modèle peut être plus lent | Coupures côté application (`AI_PROVIDER_TIMEOUT`) | `AI_TIMEOUT_MS` ≥ `EDGIA_REQUEST_TIMEOUT_SECONDS` × 1000 + marge |
| 4 | L'application lit `data.sources`, Core met les sources dans `edgia.sources` | Sources de la base documentaire perdues | Même patch : repli sur `edgia.sources` |

Réglages de l'application pour Core :
```
AI_PROVIDER=openai-compatible
AI_BASE_URL=https://<hote-core>/v1      # le /v1 est obligatoire : l'application ajoute /chat/completions
AI_API_KEY=<clé de EDGIA_API_KEYS>      # côté serveur seulement
AI_MODEL=<identifiant exact renvoyé par GET /v1/models>   # sinon 404 model_not_found
AI_TIMEOUT_MS=130000
```
Autres constats : l'application n'utilise pas le flux (SSE) ; la voix (STT/TTS) passe par OpenAI (`OPENAI_API_KEY`) et **reste indépendante** de Core ; l'application a déjà son propre module de programmes (RAG, Voyage + pgvector) : garder cette source de vérité et ne pas envoyer `knowledge` depuis l'application sans décision explicite ; quotas, audit et erreurs (`mapProviderError`) restent côté application. Le patch n'est **pas appliqué** : à toi de décider (`patch -p0 < …` depuis `src/ai/`).

## Principes

1. **Appel de serveur à serveur uniquement.** La clé d'API (`EDGIA_API_KEYS`) reste dans le backend ; jamais dans l'application mobile ni dans un navigateur.
2. **Le mode démonstration n'est jamais un vrai modèle.** Les réponses portent `edgia.demo`. Le client de référence refuse ce mode par défaut (`allowDemo: true` réservé au développement).
3. **Champs supportés seulement** : `model`, `messages`, `stream`, `max_tokens`, `temperature`, `top_p`, `stop`, `knowledge`. Un champ OpenAI non supporté (`user`, `n`, `response_format`, `tools`…) donne **422**. C'est le risque de compatibilité n° 1 si l'application utilise un SDK OpenAI : filtrez la requête avant envoi.
4. **Pas de repli silencieux.** Basculer vers un autre fournisseur si Core est indisponible est une décision explicite du propriétaire de l'application, jamais un comportement caché.
5. **Aucun contenu dans les journaux.** Journalisez `X-Request-ID`, le code d'erreur et la durée, pas les messages.
6. **Contexte minimal.** N'envoyez pas de données personnelles non nécessaires (le nettoyage PII de Core ne s'applique qu'aux données d'entraînement).

## Délais et erreurs

- Délai client ≥ `EDGIA_REQUEST_TIMEOUT_SECONDS` du serveur + marge (le client de référence : 130 s).
- `429` : limite de débit, attendre `Retry-After`. `503 server_busy` : le client de référence réessaie une fois. `504` : ne pas réessayer en boucle.
- Dans un flux, une erreur peut arriver après les premiers fragments : traiter le flux sans `[DONE]` comme **interrompu**.

## Base de connaissances (RAG)

Décision à prendre par l'équipe : l'application a déjà un module de programmes (Voyage + pgvector selon un message antérieur, à vérifier). Garder **une seule source de vérité**. La recherche de Core est lexicale (FTS5) ; elle ne remplace pas une recherche sémantique sans évaluation comparée.
`sources: null` = ancrage non demandé ; `[]` = rien de pertinent trouvé (la réponse n'est alors pas ancrée).

## Ce qui reste dans l'application

Quotas, facturation FCFA, comptes, historique, voix (STT/TTS : **non fournis** par Core), modération métier.

## Versions

Dans `v1`, les changements sont additifs ; l'extension `edgia` peut gagner des champs : ignorez les champs inconnus en lecture.

## Déploiement progressif recommandé

1. **Ombre** : Core reçoit une copie des requêtes, réponses non affichées, comparées hors ligne.
2. **Canari** : petite part d'utilisateurs, retour arrière immédiat par variable.
3. **Général** : après validation par la suite d'évaluation et relecture humaine.

## Esquisse TypeScript (non testée, à adapter)

```ts
// Esquisse inutile avec l'application actuelle (voir « Constat ») : conservée pour un autre backend.
export class EdgiaCoreProvider /* implements AIProvider */ {
  constructor(private baseUrl = process.env.AI_BASE_URL!, private apiKey = process.env.AI_API_KEY!) {}
  async chat(messages: { role: string; content: string }[], maxTokens = 512) {
    const res = await fetch(`${this.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${this.apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages, max_tokens: maxTokens }),
      signal: AbortSignal.timeout(130_000),
    });
    if (!res.ok) throw new Error(`edgia-core ${res.status} ${res.headers.get('x-request-id')}`);
    const data = await res.json();
    if (data.edgia?.demo) throw new Error('mode démonstration refusé');
    return data.choices[0].message.content as string;
  }
}
```

## Vérifier un serveur avant de le brancher

```bash
EDGIA_CHECK_API_KEY=... python -m edgia_core contract-check --url https://core.example --expect-real
```
