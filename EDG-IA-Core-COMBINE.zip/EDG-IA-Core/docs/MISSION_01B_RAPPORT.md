# Mission 01-B — diagnostic croisé du bac à sable

## 1. Constat
Chez le vérificateur indépendant, 4 tests échouent (`test_correct_code_passes`, `test_environment_is_cleared`, `test_noisy_output_does_not_break_parsing`, `test_reference_answers_pass_with_code_execution`) avec « le code a été interrompu (code de sortie 255) », sur l'archive d'origine comme sur l'archive corrigée : les échecs sont **antérieurs à mes corrections** et indépendants d'elles.

## 2. Ce qui est confirmé
- **Mon environnement** : Linux, Python 3.13.16 (aussi 3.11.17 et 3.12.3 pour le bac à sable), root et uid 65534. Toutes les étapes de démarrage réussissent, avec chaque limite seule et toutes ensemble ; l'interpréteur démarre dès 16 Mo de `RLIMIT_AS`. **Mes tests précédents réussissaient donc parce que mon environnement accepte toutes les limites ; je n'ai pas d'environnement qui reproduit la panne.**
- **Le motif est reproduit, pas la cause** : en remplaçant `sys.executable` par un faux interpréteur qui sort en 255, les **mêmes 4 tests** échouent (`'fail' != 'pass'`) avec **le même message** (`le code a été interrompu (code de sortie 255)`). Conclusion : dans l'environnement du vérificateur, l'interpréteur lancé par le bac à sable n'exécute jamais le harnais. Les tests qui *attendent* un échec (mémoire, boucle infinie, gros fichier, code faux) passaient **par hasard** : « fail » est aussi ce que donnait une panne, et le message contient « 2 » (255), ce que teste `test_wrong_code_fails_with_test_numbers`.
- **Le code 255 n'est pas typique d'un `RLIMIT_AS` trop bas** pour CPython ici : sous un espace virtuel insuffisant, j'ai observé les codes 1 (`MemoryError`), 127 (bibliothèque non chargée), 137 et 139, jamais 255. Hypothèse affaiblie, **non écartée**.

## 3. Hypothèses encore ouvertes (non départagées sans la machine du vérificateur)
1. Interpréteur lancé via un script intermédiaire (pyenv, uv, conda, venv) incompatible avec l'environnement vidé (`PATH=/usr/bin:/bin`, pas de `LD_LIBRARY_PATH`, etc.) : simulé, l'outil le distingue.
2. Limite (`RLIMIT_AS`, `NPROC`, `setsid`) traitée différemment par le noyau/conteneur (gVisor, seccomp, émulation) : simulé pour `RLIMIT_AS`.
3. Autre runtime que CPython au lieu de `sys.executable`.

**Pour trancher** : exécuter, avec le même Python que les tests, `python3 tools/sandbox_diagnose.py` et renvoyer la sortie complète.

## 4. Corrections (les défauts confirmés par simulation, indépendants de la cause)
- `src/edgia_core/evaluation/sandbox.py` : le harnais écrit une ligne de démarrage avant d'exécuter le code du modèle. Sans elle, le résultat est « non exécuté » (`skipped`) avec le code de sortie et l'indication du diagnostic, au lieu d'un faux « échec du modèle ». Aucune limite modifiée ni assouplie ; jamais « réussi » ; un plantage après démarrage reste un échec.
- `tools/sandbox_diagnose.py` (nouveau, bibliothèque standard).
- Tests ajoutés (`SandboxBrokenInterpreterTest`, 3 tests) : interpréteur qui sort en 255 → non exécuté (**échoue sur l'ancien code**, passe sur le nouveau) ; plantage après démarrage → échec ; l'outil de diagnostic s'exécute et rapporte un bac à sable sain. Aucun test supprimé ni modifié.
- **Effet attendu chez le vérificateur** : plus de 4 échecs (tous les tests qui exercent le bac à sable), car les tests « attendant un échec » ne passent plus par hasard. C'est voulu : la panne devient visible, avec un message qui indique la marche à suivre.

## 5. Résultats exécutés
| Vérification | Résultat |
|---|---|
| Suite complète `PYTHONPATH=src python3 -W error -m unittest discover -s tests -t .`, Python 3.13.16, root | 366 tests, OK |
| Idem, utilisateur uid 65534 | 366 tests, OK |
| Bac à sable, Python 3.11.17 et 3.12.3 (schéma simplifié, pydantic absent) | 17 tests, 0 échec chacun |
| Simulation sans module `resource` | 65 tests d'évaluation, 0 échec, 19 ignorés |
| Simulation d'un interpréteur qui sort en 255 | 13 échecs sur 18 tests ciblés, message explicite |

Non exécutable ici : la machine du vérificateur, pytest, Windows, macOS, suite complète sous 3.11/3.12.

## 6. Risques de sécurité restants
- **Forgerie de résultat (nouveau, mesuré)** : un code faux obtient « réussi » en retrouvant le jeton par introspection de la pile, écrivant un faux résultat puis quittant. Non corrigé (hors périmètre, correction lourde) ; correction proposée dans `docs/EVALUATION.md`.
- Pas d'isolation du réseau ni du système de fichiers ; limite de processus inopérante pour root (voir `docs/EVALUATION.md`).

## 7. Fichiers modifiés
`src/edgia_core/evaluation/sandbox.py`, `tests/unit/test_eval_sandbox.py`, `docs/EVALUATION.md`, `docs/MISSION_01B_RAPPORT.md` (nouveau), `tools/sandbox_diagnose.py` (nouveau).
