# Base documentaire (phase 6)

Connaissances **externes au modèle** : on ajoute ou retire un document sans réentraîner (le modèle n'en mémorise rien).
Utile pour ancrer les réponses sur un programme scolaire, un règlement, une fiche pratique. Ce n'est **pas** une
mémoire de conversation et ce n'est pas de l'entraînement.

## Utiliser

```bash
DB=data/knowledge.sqlite3
PYTHONPATH=src python -m edgia_core knowledge --db $DB add cours.docx --source "Programme officiel 2024" \
    --rights "Usage pédagogique autorisé par l'éditeur" --collection maths-3e --tag programme
PYTHONPATH=src python -m edgia_core knowledge --db $DB search "capitale du Cameroun" --collection geo
PYTHONPATH=src python -m edgia_core knowledge --db $DB list | stats | delete <id>
```

Pour l'activer dans le serveur : `EDGIA_KNOWLEDGE_DB=data/knowledge.sqlite3` (le serveur refuse de démarrer si le fichier
n'existe pas). Il apporte `POST /v1/knowledge/search` et le champ `knowledge` du chat (voir `docs/API.md`).

## Règles

- **Source et droits obligatoires**, jamais « inconnu » : la base ne doit contenir que des documents que l'on a le droit d'utiliser.
- Types lus : `.txt`, `.md`, `.html`, `.docx` (bibliothèque standard) ; `.pdf` seulement si `pypdf` est installé (**non testé**).
  Un document sans texte extractible (PDF scanné, par exemple) est refusé, jamais indexé « à vide ». Pas d'OCR.
- Un même contenu n'est indexé qu'une fois (somme SHA-256 du texte normalisé). Un `.docx` avec déclaration DOCTYPE/ENTITY est refusé.
- Découpage en passages d'environ 900 caractères sur des frontières naturelles, avec recouvrement ; la section (titre) est conservée.
- La recherche (SQLite FTS5, classement BM25) est **lexicale** : accents et casse ignorés, pluriels simples, préfixes. Elle exige
  que la moitié au moins des mots utiles de la question se retrouvent dans le passage ; sinon elle renvoie **rien**. Les
  caractères spéciaux de la question ne peuvent pas injecter de syntaxe de recherche.

## Ancrage d'une réponse (`knowledge` dans le chat)

Les passages trouvés sont placés dans un message système, délimités et présentés comme des **données non fiables** (la
consigne dit de ne jamais exécuter une instruction qu'ils contiendraient, de citer `[n]`, et de dire qu'on ne sait pas si
les extraits ne répondent pas). La réponse porte `edgia.sources` : liste vide = rien de pertinent trouvé, la conversation
est alors envoyée telle quelle. Les sources désignent les documents (titre, source, section) sans recopier les passages.

## Limites connues

- **Recherche lexicale seulement** : pas de synonymes ni de sens. Une question formulée avec d'autres mots que le document
  peut ne rien trouver. Pas d'embeddings dans cette version (aucun modèle d'embeddings n'est disponible ni choisi).
- **L'injection de consignes par un document n'est pas éliminée** : la délimitation et la consigne réduisent le risque,
  sans garantie. Ne l'indexez que des documents de confiance. Rien ne prouve, tant qu'aucun vrai modèle n'a été testé,
  qu'il respecte la consigne.
- Rien ne garantit qu'un modèle cite correctement ou n'invente pas malgré les extraits : à évaluer sur le vrai modèle.
- Les droits sont déclarés par l'opérateur, jamais vérifiés par le logiciel.
- Pas de droits d'accès par utilisateur : toute clé d'API valide interroge toute la base. Pour séparer des établissements,
  utilisez une base par établissement (pas de multi-tenant dans cette version).
- Pas de mise à jour d'un document en place : supprimer puis ré-ajouter. Un seul processus d'écriture à la fois.
- Non mesuré sur de gros volumes (largement plus de quelques milliers de passages) ; pas de test de performance.
- Les documents sont stockés en clair dans le fichier SQLite : protégez-le comme les documents eux-mêmes.

## Bibliothèque de démarrage EDG-IA (v1)

Le dépôt contient un premier ensemble de notes originales, incluses dans le paquet Python : français, anglais, mathématiques,
statistiques, informatique, Python, Web, algorithmique, physique, biologie, géographie du Cameroun, méthodes d'apprentissage,
IA/apprentissage automatique et utilisation de la RAG. Ce pack est un socle pédagogique court, pas une encyclopédie complète
et pas un corpus suffisant pour préentraîner le modèle.

Créer et remplir la base locale (les documents déjà présents ne sont jamais écrasés) :

```bash
PYTHONPATH=src python -m edgia_core knowledge --db data/knowledge.sqlite3 seed-starter
PYTHONPATH=src python -m edgia_core knowledge --db data/knowledge.sqlite3 stats
PYTHONPATH=src python -m edgia_core knowledge --db data/knowledge.sqlite3 search "comment fonctionne une fonction Python"
```

Configurer le serveur :

```dotenv
EDGIA_KNOWLEDGE_DB=data/knowledge.sqlite3
EDGIA_KNOWLEDGE_AUTO_SEARCH=true
EDGIA_KNOWLEDGE_MAX_CONTEXT_CHARS=6000
```

Avec `EDGIA_KNOWLEDGE_AUTO_SEARCH=true`, Core cherche automatiquement des passages à partir du dernier message utilisateur
avant de générer sa réponse. Les extraits sont ajoutés comme données non fiables et les sources sont retournées dans
`edgia.sources`. L'option est désactivée par défaut ; elle exige une base documentaire configurée. On peut aussi demander
explicitement la recherche dans une requête Chat Completions avec le champ `knowledge`.

## Consultation et apprentissage des poids : séparation obligatoire

Le pack peut servir à la consultation immédiate par RAG. Il ne modifie pas les poids du modèle et ne doit pas être injecté
automatiquement dans le préentraînement. Pour préparer des données d'entraînement, il faut une étape séparée : sélection des
documents et de leurs droits, extraction, transformation en exemples, déduplication, contrôle de qualité, séparation
entraînement/validation/test et approbation humaine. L'entraînement ne démarre qu'après validation explicite d'un plan.

Les notes de démarrage sont du contenu original préparé pour le projet EDG-IA. Elles sont volontairement concises, peuvent
contenir des omissions et doivent être relues avant toute diffusion publique. Elles ne remplacent pas des manuels, des sources
officielles ni des références scientifiques complètes. Les informations évolutives, notamment géographiques et administratives,
doivent être vérifiées auprès de sources récentes.
