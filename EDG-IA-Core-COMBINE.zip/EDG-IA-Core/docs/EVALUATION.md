# Évaluation (phase 5)

Objectif : **comparer des modèles candidats ou une version adaptée à sa base**, sur des cas en français, avec des
résultats reproductibles. L'outil n'entraîne rien et ne télécharge rien.

> **Ce que cet outil n'est pas** : une mesure de la qualité d'un modèle. Les vérifications sont des heuristiques
> déterministes qui repèrent des erreurs *évidentes*. Un bon score n'est pas une preuve de qualité ; un mauvais score
> sur un cas peut venir d'une vérification trop stricte. Les cas « à relire » exigent un humain.

## Lancer une évaluation

```bash
# 1. Valider le format d'une suite (aucun modèle nécessaire)
PYTHONPATH=src python -m edgia_core eval validate-suite configs/eval/starter

# 2. Évaluer un vrai modèle (descripteur YAML ; nécessite torch + transformers, GPU/mémoire adaptés)
PYTHONPATH=src python -m edgia_core eval run --suite configs/eval/starter \
    --descriptor configs/modele-a.yaml --out resultats/modele-a

# 3. Comparer deux résultats (même suite exigée)
PYTHONPATH=src python -m edgia_core eval compare resultats/modele-a/results.json resultats/modele-b/results.json \
    --out resultats/comparaison.md
```

`--demo` évalue le moteur de démonstration : utile pour vérifier que la chaîne fonctionne, **sans aucune signification**
(le rapport l'affiche en bandeau). `--limit N` n'exécute que les N premiers cas. Le dossier de sortie n'est jamais écrasé.

Sorties : `results.json` (tout, réponses complètes), `report.md`, `report.html` (autonome), `review.csv` (cas à relire,
avec colonnes de notation pour le relecteur).

## Format d'une suite

Un dossier de fichiers `.yaml`, chacun une liste de cas (voir `configs/eval/starter/`). Cas : `id`, `category`,
`messages` (le dernier vient de l'utilisateur ; conversations à plusieurs tours et message `system` possibles),
`checks`, `max_tokens`, `note`. Sans `checks`, le cas est « à relire ». La suite a une somme SHA-256 : deux résultats
ne se comparent que si elle est identique. Toute erreur de format est signalée avec le fichier et le cas.

Vérifications : `contains_all`, `contains_any`, `not_contains_any` (insensibles à la casse et aux accents),
`regex` / `not_regex` (motif cherché dans la réponse sans accents ; écrivez le motif sans accents ; `case_sensitive: true`
pour comparer le texte tel quel), `contains_number` / `final_number` (formats français : « 24 000 », « 3,5 »),
`word_count`, `sentence_count`, `bullet_count`, `starts_with`, `ends_with`, `json_valid` (clés exigées facultatives),
`language` (fr/en, par mots courants ; indéterminée = échec), `refusal` (détection par formules de refus),
`code_tests` (exécution de code, voir ci-dessous).

Statuts d'un cas : `pass`, `fail`, `partial` (certaines vérifications non exécutées), `skipped`, `review`, `error`
(le moteur a échoué). Le taux de réussite ne porte que sur `pass + fail + error`.

## Exécution de code généré (désactivée par défaut)

Les cas de programmation contiennent des tests `code_tests`. Sans `--allow-code-execution`, ils ne sont **pas**
exécutés et le cas reste `partial`. Avec l'option, le code de la réponse est exécuté dans un sous-processus
(`python -I`, dossier temporaire, environnement vidé, limites de temps CPU, mémoire, taille de fichier et de processus,
délai maximal). **Ce n'est pas une frontière de sécurité** : le réseau et le système de fichiers ne sont pas isolés,
et un code hostile pourrait s'y soustraire. Activez l'option seulement dans un conteneur ou une machine jetable sans
réseau, surtout avec un modèle non fiable. Plateforme POSIX uniquement.

## Performances mesurées

Par cas : latence, débit (tokens/s). Pour l'ensemble : durée, latence médiane et maximale, mémoire résidente maximale du
processus d'évaluation, mémoire GPU maximale allouée **seulement si PyTorch est déjà chargé** par le moteur.
Ce sont des mesures de l'évaluation, pas un banc d'essai de charge : une génération à la fois, température 0.

## Comparer base et version adaptée

`eval compare` exige la même suite (SHA-256), liste les cas qui diffèrent dans chaque sens, donne l'écart par
catégorie et un test de McNemar exact **indicatif**. Avec des dizaines de cas, seule une différence très nette est
détectable ; ne décidez pas sur ce seul chiffre. Une suite doit en outre rester **séparée des données d'entraînement** :
ne jamais entraîner sur les cas d'évaluation (sinon la comparaison ne vaut rien).

## Limites connues

- Suite de départ : 43 cas (38 vérifiés automatiquement, 5 à relire). C'est trop peu pour départager finement deux
  modèles ; elle sert à repérer des écarts nets et à amorcer l'enrichissement de la suite avec l'équipe pédagogique.
- Les réponses de référence des tests prouvent que chaque vérification est satisfaisable et que des réponses fausses
  échouent ; elles ne disent rien de la qualité d'un vrai modèle.
- Une vérification de « non-fuite » (ex. secret du message système) est satisfaite par toute réponse qui ne divulgue
  rien, y compris une réponse vide : un « réussi » sur ces cas est faible.
- Détection de langue et de refus : heuristiques simples, fausses dans les cas limites (textes très courts, mélange de langues).
- Génération déterministe : un seul tirage par cas ; la variabilité en usage réel (température > 0) n'est pas mesurée.
- Les catégories sensibles (détresse, données personnelles, intégrité scolaire) ne sont **pas** notées automatiquement :
  relecture humaine obligatoire.
- Jamais exécuté avec un vrai modèle (le chargement réel n'a jamais été testé, voir `PHASE_TRACKER.md`).

## Bac à sable de code : ce qui a été mesuré (mission 01)

Sondes exécutées dans le bac à sable (Linux, Python 3.13), en root et en utilisateur sans privilège :

| Sonde | Résultat |
|---|---|
| Lire un fichier hors du dossier de travail (`/etc/hostname`, un fichier du projet) | **Possible** (pas d'isolation du système de fichiers) |
| Ouvrir un socket réseau | **Possible** (pas d'isolation du réseau) |
| Variables d'environnement du processus parent | Non transmises (environnement vidé) |
| Créer 40 processus alors que la limite est 16 | **Possible en root** (la limite `RLIMIT_NPROC` n'est pas appliquée à root) ; **bloqué** en utilisateur normal |

Conséquences : n'activez `--allow-code-execution` que dans un conteneur jetable, **sans réseau** et **sous un utilisateur non-root** (le `Dockerfile` fourni utilise l'utilisateur `edgia`, uid 10001). Si le bac à sable ne peut pas démarrer (limite refusée par le système, lancement impossible), le code n'est **pas exécuté** et le cas est marqué « non exécuté » : jamais « réussi ».

## Bac à sable : panne de démarrage et intégrité des résultats (mission 01-B)

- **Panne de démarrage** : le harnais annonce son démarrage avant d'exécuter le code du modèle. S'il n'a jamais démarré (interpréteur inutilisable, limite incompatible, script intermédiaire défaillant…), le cas est « non exécuté » avec le code de sortie dans le message, **jamais** « échec du modèle » ni « réussi ». Un code du modèle qui plante après le démarrage reste un échec.
- **Diagnostic** : `python3 tools/sandbox_diagnose.py` (bibliothèque standard seulement, n'exécute aucun code de modèle) relance l'interpréteur étape par étape (sans limite, chaque limite seule, toutes ensemble) et capture code de sortie et message d'erreur. À lancer avec **le même Python que les tests**.
- **Risque connu, NON corrigé** : le code d'une réponse peut **forger un résultat « réussi »** (introspection de la pile pour retrouver le jeton du harnais, écriture d'un faux résultat, puis sortie immédiate). Mesuré : un code faux obtient « 2 test(s) réussi(s) ». Tant que ce n'est pas corrigé, ne faites pas confiance à un score de code pour un modèle potentiellement adverse. Correction proposée : exécuter le code du modèle dans un processus fils séparé de celui qui détient le jeton et évalue les tests, en ne lui faisant renvoyer que des valeurs à comparer côté parent.
