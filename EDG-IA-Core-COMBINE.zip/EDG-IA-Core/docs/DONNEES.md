# Données et adaptation SFT/LoRA (phase 4)

Cette phase prépare des données d'adaptation **propres, traçables et séparées de l'évaluation**, et décrit un
entraînement LoRA. **Aucun entraînement n'a été exécuté** ; aucune donnée réelle n'est fournie (seulement 4 exemples
fictifs dans `configs/data/exemple.jsonl`).

## Format des données (JSONL, une conversation par ligne)

```json
{"id":"ex-001","messages":[{"role":"user","content":"…"},{"role":"assistant","content":"…"}],
 "source":"d'où vient la donnée","license":"licence ou base légale","origin":"curated|synthetic|licensed|public_domain|user_conversation",
 "consent":false,"group":null,"lang":"fr","tags":[]}
```

Refusés au chargement : source ou licence absente ou « inconnue », champ inconnu, identifiant dupliqué, dernier message
qui n'est pas de l'assistant, ligne trop longue. Les messages d'erreur donnent fichier et ligne, **jamais le contenu**.

## Préparer un jeu

```bash
PYTHONPATH=src python -m edgia_core data validate donnees/*.jsonl
PYTHONPATH=src python -m edgia_core data prepare donnees/*.jsonl \
    --eval-suite configs/eval/starter --out data-prepared/v1 [--val-fraction 0.05] [--pii redact|reject]
```

Étapes, dans cet ordre, chacune comptée dans `manifest.json` (les écartés sont listés par raison dans `rejected.jsonl`,
sans contenu) :
1. **Conversations d'utilisateurs** : écartées, sauf `consent: true` dans la donnée **et** `--allow-user-conversations`.
   Aucun réentraînement automatique à partir des conversations de l'application.
2. **Qualité** : messages vides, caractères de contrôle, trop longs, réponse trop courte, répétitions anormales.
3. **Données personnelles** : courriels, téléphones et longues suites de chiffres, IBAN, URL avec identifiants sont masqués
   (`[EMAIL]`, `[TELEPHONE_OU_NUMERO]`…) ou, avec `--pii reject`, l'exemple est écarté. Les montants en FCFA ne sont pas masqués.
4. **Anti-contamination** : tout exemple qui contient un message de la suite d'évaluation (en entier ou par séquences de
   8 mots) est écarté. **Sans `--eval-suite`, le jeu est marqué « contamination non vérifiée » et le plan d'entraînement le refuse.**
5. **Doublons** : exacts (après normalisation) et quasi-doublons (similarité de Jaccard ≥ 0,9, MinHash), en gardant le premier.
6. **Découpage** entraînement/validation déterministe (graine + `group` ou `id`) : un même `group` reste du même côté.

Sorties : `train.jsonl`, `validation.jsonl`, `rejected.jsonl`, `manifest.json` (sommes SHA-256 des entrées et sorties,
options, statistiques par langue/origine/source/licence, avertissements). Le dossier de sortie n'est jamais écrasé.

## Entraîner (LoRA)

```bash
PYTHONPATH=src python -m edgia_core train plan configs/training/exemple.yaml          # vérifie tout, ne lance rien
PYTHONPATH=src python -m edgia_core train run  configs/training/exemple.yaml --confirm-training
```

Le **plan** refuse si : licence du modèle de base non vérifiée ou sans usage commercial, poids absents ou corrompus
(SHA-256), modèle de base déjà adapté, jeu non préparé ou modifié depuis la préparation, contamination non vérifiée,
moins de `min_train_records` exemples, dossier de sortie non vide, `torch`/`transformers`/`peft` absents. Il affiche une
estimation **grossière** (étapes, mémoire). `run` n'est lancé qu'avec `--confirm-training` (calcul payant).

L'entraînement n'apprend que la dernière réponse de l'assistant (le reste du prompt est masqué), enregistre l'adaptateur
et écrit `training_report.json` (pertes, sommes des fichiers) et `descriptor_suggestion.yaml`, dont **la licence est
remise à « non vérifiée »**. Ensuite : `eval run` sur la suite, `eval compare` base contre adapté, relecture humaine,
puis seulement `models register`.

## Limites connues

- **La boucle d'entraînement n'a jamais été exécutée** (pas de PyTorch ni de GPU ici). Seules les fonctions pures
  (masquage des labels, calendrier du taux d'apprentissage, plan, validation) sont testées, avec un faux tokenizer. À
  valider sur un très petit jeu et un petit modèle avant tout long entraînement.
- QLoRA (4 bits), multi-GPU, reprise après interruption, points de contrôle intermédiaires : non pris en charge.
- Le masquage des données personnelles est par motifs : **noms, adresses, informations décrites en toutes lettres ne sont pas
  détectés**. Relisez un échantillon.
- La détection de quasi-doublons est conçue pour des jeux de l'ordre de quelques dizaines de milliers d'exemples ; non
  mesurée sur de gros volumes.
- Les statistiques de langue sont indicatives (heuristique) ; aucun filtre de qualité linguistique n'est appliqué.
- Aucune donnée n'est fournie : sources, droits et consentements restent à établir par l'équipe.
