# Rapport de vérification d'intégrité (existant vs référence)

- Fichiers de référence : 230
- Inchangés : 227
- Modifiés et déclarés (patches) : 3 → pyproject.toml, src/edgia_core/model/descriptor.py, src/edgia_core/model/loader.py
- Modifiés NON déclarés : 0 []
- Supprimés : 0 []
- Ajoutés (dossiers autorisés) : 85
- Ajoutés hors dossiers autorisés : 0 []
- Artefacts d'exécution ignorés (__pycache__, *.pyc) : 0
- Patches non réversibles : []

**Résultat : CONFORME**
