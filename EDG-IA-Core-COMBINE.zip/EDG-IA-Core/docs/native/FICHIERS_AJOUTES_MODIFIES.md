# Fichiers ajoutés et modifiés (L0)

Référence : 230 fichiers d'origine (`native_baseline/BASELINE_SHA256.txt`). Après L0 : 220 fichiers hors `__pycache__`.

## Fichiers EXISTANTS modifiés (3, par patches minimaux et réversibles)

| Fichier | Patch | Original conservé | SHA-256 avant → après |
|---|---|---|---|
| `src/edgia_core/model/descriptor.py` | `patches/src__edgia_core__model__descriptor.py.patch` | `native_baseline/originals/src/edgia_core/model/descriptor.py` | 3fa8ba48d2f2 → 3e7235e5ee2b |
| `src/edgia_core/model/loader.py` | `patches/src__edgia_core__model__loader.py.patch` | `native_baseline/originals/src/edgia_core/model/loader.py` | b23317a356ca → a4d8b4822b78 |
| `pyproject.toml` | `patches/pyproject.toml.patch` | `native_baseline/originals/pyproject.toml` | e946fee6deef → 6a0ddea33642 |

Nature des modifications : `descriptor.py` (+ `EDGIA_SAFETENSORS`, + `EDGIA_NATIVE`, correspondance, tokenizer obligatoire aussi pour le natif), `loader.py` (une branche `build_engine`, import paresseux), `pyproject.toml` (extra `native`).
Retour arrière : recopier les fichiers de `native_baseline/originals/` ou `patch -R -p1 < patches/<nom>.patch`.

## Fichiers AJOUTÉS (86)

### (racine)/ (1)
- `README_L0.md`

### configs/ (5)
- `configs/native/model.native.example.yaml`
- `configs/native/smoke.yaml`
- `configs/native/sources.example.yaml`
- `configs/native/special_tokens.lock.json`
- `configs/native/xs.yaml`

### docs/ (12)
- `docs/native/ARCHITECTURE.md`
- `docs/native/CONFIGURATION.md`
- `docs/native/DONNEES.md`
- `docs/native/ENTRAINEMENT.md`
- `docs/native/INSTALLATION.md`
- `docs/native/PROBLEMES.md`
- `docs/native/PROCHAINES_ETAPES.md`
- `docs/native/TESTS.md`
- `docs/native/resultats/mutation.json`
- `docs/native/resultats/tests.json`
- `docs/native/resultats/tests_verbose.txt`
- `docs/native/resultats/verify_untouched.md`

### native_baseline/ (5)
- `native_baseline/BASELINE_SHA256.txt`
- `native_baseline/PATCHED_FILES.json`
- `native_baseline/originals/pyproject.toml`
- `native_baseline/originals/src/edgia_core/model/descriptor.py`
- `native_baseline/originals/src/edgia_core/model/loader.py`

### patches/ (3)
- `patches/pyproject.toml.patch`
- `patches/src__edgia_core__model__descriptor.py.patch`
- `patches/src__edgia_core__model__loader.py.patch`

### src/ (35)
- `src/edgia_core/native/__init__.py`
- `src/edgia_core/native/__main__.py`
- `src/edgia_core/native/backend.py`
- `src/edgia_core/native/cli.py`
- `src/edgia_core/native/config.py`
- `src/edgia_core/native/data/__init__.py`
- `src/edgia_core/native/data/dedup.py`
- `src/edgia_core/native/data/licenses.py`
- `src/edgia_core/native/data/loader.py`
- `src/edgia_core/native/data/manifest.py`
- `src/edgia_core/native/data/pipeline.py`
- `src/edgia_core/native/data/registry.py`
- `src/edgia_core/native/data/shards.py`
- `src/edgia_core/native/data/split.py`
- `src/edgia_core/native/data/text.py`
- `src/edgia_core/native/errors.py`
- `src/edgia_core/native/generation.py`
- `src/edgia_core/native/hashing.py`
- `src/edgia_core/native/model.py`
- `src/edgia_core/native/naming.py`
- `src/edgia_core/native/reference/__init__.py`
- `src/edgia_core/native/reference/numpy_model.py`
- `src/edgia_core/native/safetensors_io.py`
- `src/edgia_core/native/sampling.py`
- `src/edgia_core/native/tokenizer/__init__.py`
- `src/edgia_core/native/tokenizer/bpe.py`
- `src/edgia_core/native/tokenizer/pretokenizer.py`
- `src/edgia_core/native/tokenizer/specials.py`
- `src/edgia_core/native/tokenizer/tokenizer.py`
- `src/edgia_core/native/train/__init__.py`
- `src/edgia_core/native/train/checkpoint.py`
- `src/edgia_core/native/train/env.py`
- `src/edgia_core/native/train/export.py`
- `src/edgia_core/native/train/loop.py`
- `src/edgia_core/native/train/schedule.py`

### tests/ (21)
- `tests/native/_bootstrap.py`
- `tests/native/datafixtures.py`
- `tests/native/synthetic.py`
- `tests/native/test_checkpoint_resume.py`
- `tests/native/test_cli.py`
- `tests/native/test_config.py`
- `tests/native/test_core_integration.py`
- `tests/native/test_data_pipeline.py`
- `tests/native/test_export.py`
- `tests/native/test_generation.py`
- `tests/native/test_licenses_registry.py`
- `tests/native/test_numpy_reference.py`
- `tests/native/test_pretokenizer.py`
- `tests/native/test_safetensors_io.py`
- `tests/native/test_safetensors_official.py`
- `tests/native/test_static_security.py`
- `tests/native/test_tokenizer.py`
- `tests/native/test_torch_model.py`
- `tests/native/test_torch_training.py`
- `tests/native/test_untouched.py`
- `tests/native/toy_trainer.py`

### tools/ (4)
- `tools/baseline_manifest.py`
- `tools/mutation_check.py`
- `tools/run_native_tests.py`
- `tools/verify_untouched.py`

## Fichiers existants supprimés : aucun (vérifié). Prototype phase 9 (`custom_model/`) : octet pour octet identique.
