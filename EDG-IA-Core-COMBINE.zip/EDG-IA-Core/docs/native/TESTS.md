# Guide de lancement des tests

```bash
python tools/run_native_tests.py                 # tout (unittest, aucune dépendance)
python tools/run_native_tests.py test_tokenizer -v
python tools/run_native_tests.py --json rapport.json
python -m pytest tests/native                    # compatible pytest
python tools/verify_untouched.py --root .        # intégrité des fichiers existants
python tools/mutation_check.py --json mut.json   # tests de mutation (≈ 5 à 10 min)
python -m pytest tests/unit                      # suite EXISTANTE de Core (nécessite l'installation de Core)
```
Un test SAUTÉ n'est pas un test réussi : les tests PyTorch, l'intégration Core et le test croisé safetensors sont sautés sans les bibliothèques.
Ordre conseillé sur votre machine : 1) `pip install -e ".[native,dev]"`, 2) tout lancer, 3) lire les « mesures » imprimées ([mesure M2], [mesure T6], [mesure S14], [mesure F1]).
Fichiers : `test_config`, `test_safetensors_io`, `test_pretokenizer`, `test_tokenizer`, `test_numpy_reference`, `test_generation`, `test_licenses_registry`,
`test_data_pipeline`, `test_checkpoint_resume` (mini-entraîneur NumPy `toy_trainer.py`), `test_export`, `test_static_security`, `test_untouched`, `test_cli`,
`test_torch_model`, `test_torch_training`, `test_core_integration`, `test_safetensors_official`.
