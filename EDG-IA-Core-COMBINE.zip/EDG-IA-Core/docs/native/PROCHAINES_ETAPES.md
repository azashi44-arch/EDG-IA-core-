# Prochaines étapes vers L1 et le préentraînement

## Avant tout (sur VOTRE machine)
1. `pip install -e ".[native,dev]"` puis `python tools/run_native_tests.py` : lire les « mesures » ; les 21 tests sautés doivent s'exécuter. **Corriger ce qui échoue** (je peux le faire avec les messages d'erreur).
2. `python -m pytest tests/unit` : suite EXISTANTE de Core (non-régression réelle après les 3 patches).
3. `python tools/verify_untouched.py --root .` et `python tools/mutation_check.py` (doivent rester conformes).

## L1 (propositions, à valider)
- Exécuter `test_torch_training` (fumée F1, reprise S4 niveau A, garde NaN) ; calibrer le seuil F1 sur la première exécution.
- Exécuter F2/F6 : Core + Chat de bout en bout avec un export `smoke_test` (`EDGIA_ALLOW_UNTRAINED=true`), vérifier `/ready`, `/v1/models`, le streaming SSE et que le mode démo reste distinct.
- Troncature par budget de tokens dans Chat (modification séparée, proposée en patch) ; aligner `max_tokens`.
- Entraîneur BPE rapide (même format de fusions) et mesure de temps à 32 384 fusions.
- Relecture indépendante des formules (§3.3 de la spécification).

## Avant le préentraînement
- Constituer le corpus réel : dossiers de licence complets, porte 1 (et avis juridique classe B), audit d'échantillon pour les jeux « confiance déléguée ».
- `data-build --profile production`, vérifier rapports de rejets/fuites ; geler le tokenizer (tests T6–T8 sur données réelles, seuils définitifs).
- Pilote XS (~100 M de tokens) sur GPU : balayage du taux d'apprentissage, débit, bruit de base GPU ; puis XS complet (autorisation explicite à chaque étape).
- Évaluation réelle (rapport requis pour `--status trained`) ; porte 2 seulement si distribution envisagée.
