# Guide d'entraînement du modèle (de zéro)

**AUCUN entraînement n'a été réalisé lors de L0.** Ce guide décrit comment le faire quand les données réelles auront été validées.

1. **Sources** : compléter `sources.example.yaml` (dossier de licence, empreintes réelles, validateur humain), faire franchir la porte 1. `sources-check` doit les admettre.
2. **Données** : `data-build … --profile production` (le tokenizer de 32 768 est entraîné sur `train` seul ; il exige assez de texte : sinon erreur explicite).
   Vérifier `rejections.jsonl`, `leak_report.json`, `DATA_CARD.md`, puis `data-verify`.
3. **Plan** : `train-plan --model xs` (mémoire des logits, FLOPs théoriques).
4. **Fumée d'abord** (CPU) : `train-run --model smoke --train-config configs/native/smoke.yaml --data DS_SMOKE --out RUN_SMOKE` ; relever la perte et CALIBRER le seuil F1.
5. **Pilote XS** (~100 M de tokens, GPU) : `train-run --model xs --train-config configs/native/xs.yaml --data DS --out RUN --confirm-training` avec `max_steps` réduit ;
   mesurer le débit, choisir le taux d'apprentissage parmi {3e-4, 6e-4, 1e-3, 2e-3}, mesurer le bruit de base (deux runs de même graine) pour le niveau B.
6. **Reprise** : relancer la même commande (reprend au dernier checkpoint complet). Refus si configuration, tokenizer, verrou ou données diffèrent. Le niveau de reproductibilité (A/B/C) est écrit dans `trainer_state.json`.
7. **Export** : `export … --status pilot` ; `--status trained` exige `--evaluation-report` (un rapport réel) ; `--for-distribution` exige la porte 2 pour chaque source.
Interruption propre : Ctrl-C → checkpoint complet puis arrêt. Perte/gradient non fini → arrêt immédiat, aucun checkpoint écrit.
