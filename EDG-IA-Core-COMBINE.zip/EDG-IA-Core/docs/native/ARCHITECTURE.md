# Architecture technique d'EDG-IA Native (L0)

> État : voir `README_L0.md` (matrice « codé / testé / fonctionnel »). Spécification de référence : EDG-IA Native v1.1.

## 1. Vue d'ensemble

```
Données JSONL ──► portes de provenance ──► nettoyage ──► doublons ──► groupes ──► train/val/test ──► tokenizer (train seul)
                                                                                       │
                                  fragments uint16 + index + manifeste SHA-256 ◄───────┘
                                                │
                  chargeur sans état ──► boucle d'entraînement (PyTorch) ──► checkpoints atomiques ──► export safetensors
                                                                                                   │
                                           Core : runtime `edgia_native` ◄─────────────────────────┘
                                           (API /ready, /v1/models, /v1/chat/completions inchangée)
```
Le paquet `src/edgia_core/native/` est AJOUTÉ à Core. Le prototype de la phase 9 (`custom_model/`) est intact et n'est pas importé.

## 2. Modèle (XS : 25 172 352 paramètres)

| Élément | Valeur |
|---|---|
| Type | Transformer causal *decoder-only*, pré-normalisation |
| d / couches / têtes Q / têtes KV / dim. de tête | 384 / 8 / 6 / 2 / 64 |
| MLP SwiGLU | 1024 |
| Contexte / vocabulaire | 1024 / 32 768 (production), 1024 (smoke) |
| Embeddings | liés (aucun module de sortie : `logits = norm(x) · Eᵀ`) |

Composants (formules exactes dans `model.py` et `reference/numpy_model.py`) :
- **RMSNorm** : `y = x · rsqrt(mean(x²)+ε) · g`, moyenne en float32, résultat reconverti avant le gain.
- **RoPE** (convention « moitiés », θ = 10 000) : positions ABSOLUES (décalage = longueur du cache), K stocké dans le cache APRÈS rotation.
- **GQA** : la tête de requête h lit la tête KV `h // (H/Hkv)` (`repeat_interleave`).
- **Masque** : `is_causal=True` seulement si le cache est vide ; sinon aucun masque pour 1 requête, masque booléen explicite sinon (correction C5).
- **Cache KV** préalloué ; **génération** dans `generation.py` (indépendante du framework, testée avec la référence NumPy).
- **Initialisation depuis zéro** : normale(0 ; 0,02), projections résiduelles 0,02/√(2·couches) = 0,005, gains = 1.

Perte initiale attendue ≈ 10,5 ; **mesurée sur XS (référence NumPy) : 10,4969** (ln 32 768 = 10,3972).

## 3. Tokenizer (maison, sans bibliothèque externe)
- BPE d'octets : 128 identifiants réservés (0–8 nommés, 9–127 `<|reserved_NNN|>`) + 256 octets + fusions.
- Pré-découpage « edgia-split-v1 » écrit à la main (testé contre `re` sur 6 000 chaînes).
- **Sécurité** : `encode_text` ne produit jamais d'identifiant < 128 ; le gabarit est assemblé au niveau des identifiants ; masque de sortie sur {0,1,3,4,5,7,8,9…127}.
- Verrou `configs/native/special_tokens.lock.json` (SHA-256 vérifié au chargement).

## 4. Intégration Core (additive)
- `descriptor.py` : valeurs `Runtime.EDGIA_NATIVE` et `WeightsFormat.EDGIA_SAFETENSORS` (correspondance existante `safetensors→transformers` intacte).
- `loader.py` : une branche dans `build_engine`, import paresseux.
- `pyproject.toml` : extra optionnel `native`.
- `native/backend.py` : `NativeBackend(Backend)` ; refuse un modèle non entraîné sauf `EDGIA_ALLOW_UNTRAINED=true`.
Patches : `patches/*.patch` ; originaux : `native_baseline/originals/`.

## 5. Statuts de modèle
`random_init`, `smoke_test`, `pilot`, `trained` (+ `distribution_cleared`, faux par défaut). Profil smoke ⇒ statut `smoke_test` uniquement.
