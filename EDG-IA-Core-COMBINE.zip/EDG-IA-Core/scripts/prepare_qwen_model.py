#!/usr/bin/env python3
"""Download Qwen2.5-1.5B-Instruct locally and write a strict EDG-IA Core descriptor.

The script deliberately does NOT mark the model's license as human-reviewed.
Read the official LICENSE before enabling real mode for commercial use.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
import sys

try:
    import yaml
    from huggingface_hub import snapshot_download
except ImportError as exc:
    print("Dépendance manquante. Installez-la avec : python -m pip install PyYAML huggingface_hub", file=sys.stderr)
    raise SystemExit(2) from exc

ROOT = Path(__file__).resolve().parents[1]
MODEL_ID = "Qwen/Qwen2.5-1.5B-Instruct"
MODEL_DIR = ROOT / "models" / "qwen2.5-1.5b-instruct"
DESCRIPTOR = ROOT / "configs" / "model.yaml"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    if DESCRIPTOR.exists():
        print(f"Refus de remplacer le descripteur existant : {DESCRIPTOR}")
        print("Sauvegardez-le ou renommez-le manuellement si vous voulez en générer un nouveau.")
        return 2

    print(f"Téléchargement de {MODEL_ID} vers : {MODEL_DIR}")
    print("Le téléchargement initial nécessite Internet et plusieurs Go d'espace disque.")
    MODEL_DIR.parent.mkdir(parents=True, exist_ok=True)
    snapshot_download(repo_id=MODEL_ID, local_dir=str(MODEL_DIR))

    weights = sorted(MODEL_DIR.glob("*.safetensors"))
    if not weights or not (MODEL_DIR / "config.json").is_file():
        print("Échec : le dossier téléchargé ne contient pas config.json et des poids .safetensors.", file=sys.stderr)
        return 3
    if not (MODEL_DIR / "tokenizer_config.json").is_file() or not (MODEL_DIR / "tokenizer.json").is_file():
        print("Échec : fichiers du tokenizer manquants.", file=sys.stderr)
        return 3

    hashes = {p.name: sha256_file(p) for p in weights}
    descriptor = {
        "model_id": "qwen2.5-1.5b-instruct",
        "version": "1.0.0",
        "display_name": "Qwen2.5-1.5B-Instruct (premier modèle réel d'EDG-IA Core)",
        "weights_path": "../models/qwen2.5-1.5b-instruct",
        "tokenizer_path": "../models/qwen2.5-1.5b-instruct",
        "weights_format": "safetensors",
        "runtime": "transformers",
        "license": {
            "name": "Apache-2.0 (à vérifier dans la licence officielle téléchargée)",
            "url": "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct/blob/main/LICENSE",
            "commercial_use_allowed": None,
            "reviewed": False,
            "notes": "Ne pas activer le mode réel pour un usage commercial avant lecture et validation humaine de LICENSE.",
        },
        "hardware": {"device": "cpu", "min_ram_gb": 8, "min_vram_gb": None},
        "adaptation": {"method": "none", "base_model_id": MODEL_ID, "adapter_path": None},
        "sha256": hashes,
    }
    DESCRIPTOR.parent.mkdir(parents=True, exist_ok=True)
    DESCRIPTOR.write_text(yaml.safe_dump(descriptor, allow_unicode=True, sort_keys=False), encoding="utf-8")

    print(f"Descripteur créé : {DESCRIPTOR}")
    print(f"Fichiers safetensors contrôlés : {len(weights)}")
    print("ÉTAPE OBLIGATOIRE : lisez le fichier LICENSE du modèle et confirmez la licence avant l'activation.")
    print("Le descripteur reste volontairement bloqué (reviewed: false, commercial_use_allowed: null).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
