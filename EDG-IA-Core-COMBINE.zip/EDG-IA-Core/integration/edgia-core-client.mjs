// Client de référence d'EDG-IA Core pour Node 18+ (fetch intégré, aucune dépendance).
// À copier dans le backend de l'application EDG-IA ou à porter en TypeScript. Vérifié uniquement par
// tests/integration/test_node_client.py (serveur de démonstration lancé en vrai processus, Node 22).
//
// Règles intégrées :
//  - la clé d'API reste côté serveur (jamais dans une application mobile) ;
//  - un serveur en MODE DÉMONSTRATION est refusé par défaut (allowDemo: true pour le développement uniquement) ;
//  - seuls les champs connus de l'API sont envoyés (tout champ inconnu serait refusé en 422) ;
//  - le contenu des messages n'est jamais écrit dans les erreurs ;
//  - pas de repli silencieux vers un autre fournisseur : c'est une décision explicite de l'application.

const REQUEST_FIELDS = ["model", "max_tokens", "temperature", "top_p", "stop", "knowledge"];

export class EdgiaCoreError extends Error {
  constructor(message, { status = 0, code = "client_error", requestId = null, retryAfter = null } = {}) {
    super(message);
    this.name = "EdgiaCoreError";
    this.status = status;
    this.code = code; // code de l'API (ex. "server_busy") ou "demo_model_refused", "timeout", "network_error"
    this.requestId = requestId;
    this.retryAfter = retryAfter;
  }
}

export class EdgiaCoreClient {
  constructor({ baseUrl, apiKey, timeoutMs = 130_000, allowDemo = false, retryOnBusy = 1 }) {
    if (!baseUrl || !apiKey) throw new Error("baseUrl et apiKey sont obligatoires");
    this.baseUrl = baseUrl.replace(/\/+$/, "");
    this.apiKey = apiKey;
    this.timeoutMs = timeoutMs; // doit dépasser EDGIA_REQUEST_TIMEOUT_SECONDS du serveur
    this.allowDemo = allowDemo;
    this.retryOnBusy = retryOnBusy;
  }

  async #fetch(path, { method = "GET", body, auth = true } = {}) {
    const headers = {};
    if (auth) headers.Authorization = `Bearer ${this.apiKey}`;
    if (body !== undefined) headers["Content-Type"] = "application/json";
    let response;
    try {
      response = await fetch(this.baseUrl + path, {
        method,
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: AbortSignal.timeout(this.timeoutMs),
      });
    } catch (error) {
      if (error?.name === "TimeoutError") throw new EdgiaCoreError("Délai dépassé côté client", { code: "timeout" });
      throw new EdgiaCoreError("Serveur injoignable", { code: "network_error" });
    }
    if (!response.ok) throw await this.#toError(response);
    return response;
  }

  async #toError(response) {
    const requestId = response.headers.get("x-request-id");
    const retryAfter = response.headers.get("retry-after");
    let code = "http_error";
    let message = `Erreur HTTP ${response.status}`;
    try {
      const { error } = await response.json();
      code = error.code ?? code;
      message = error.message ?? message;
    } catch {
      /* corps non JSON : on garde le message générique */
    }
    return new EdgiaCoreError(message, { status: response.status, code, requestId, retryAfter });
  }

  #payload(messages, options) {
    if (!Array.isArray(messages) || messages.length === 0) throw new Error("messages requis");
    const payload = { messages: messages.map(({ role, content }) => ({ role, content })) };
    for (const field of REQUEST_FIELDS) if (options[field] !== undefined) payload[field] = options[field];
    return payload;
  }

  #checkDemo(edgia) {
    if (edgia?.demo && !this.allowDemo) {
      throw new EdgiaCoreError("Le serveur est en mode démonstration : ce n'est pas le modèle EDG-IA entraîné.", { code: "demo_model_refused" });
    }
  }

  async #postWithBusyRetry(path, body) {
    for (let attempt = 0; ; attempt++) {
      try {
        return await this.#fetch(path, { method: "POST", body });
      } catch (error) {
        if (error.code === "server_busy" && attempt < this.retryOnBusy) {
          await new Promise((resolve) => setTimeout(resolve, Math.min(5, Number(error.retryAfter) || 1) * 1000));
          continue;
        }
        throw error;
      }
    }
  }

  async ready() {
    return (await this.#fetch("/ready", { auth: false })).json();
  }

  async models() {
    return (await this.#fetch("/v1/models")).json();
  }

  /** Réponse complète : { text, finishReason, usage, model, edgia, sources, requestId } */
  async chat(messages, options = {}) {
    const response = await this.#postWithBusyRetry("/v1/chat/completions", this.#payload(messages, options));
    const data = await response.json();
    this.#checkDemo(data.edgia);
    const choice = data.choices[0];
    return {
      text: choice.message.content,
      finishReason: choice.finish_reason,
      usage: data.usage,
      model: data.model,
      edgia: data.edgia,
      sources: data.edgia.sources ?? null, // null : ancrage non demandé ; [] : rien de pertinent trouvé
      requestId: response.headers.get("x-request-id"),
    };
  }

  /** Flux : itérateur asynchrone de { type: "delta", text } puis { type: "done", finishReason, usage, edgia, sources }. */
  async *chatStream(messages, options = {}) {
    const response = await this.#postWithBusyRetry("/v1/chat/completions", { ...this.#payload(messages, options), stream: true });
    const requestId = response.headers.get("x-request-id");
    const decoder = new TextDecoder();
    let buffer = "";
    let finished = false;
    for await (const piece of response.body) {
      buffer += decoder.decode(piece, { stream: true });
      let boundary;
      while ((boundary = buffer.indexOf("\n\n")) >= 0) {
        const block = buffer.slice(0, boundary);
        buffer = buffer.slice(boundary + 2);
        if (!block.startsWith("data: ")) continue;
        const data = block.slice(6);
        if (data === "[DONE]") {
          finished = true;
          return;
        }
        const chunk = JSON.parse(data);
        if (chunk.error) throw new EdgiaCoreError(chunk.error.message, { status: 200, code: chunk.error.code, requestId });
        const choice = chunk.choices[0];
        if (choice.delta?.content) yield { type: "delta", text: choice.delta.content };
        if (choice.finish_reason) {
          this.#checkDemo(chunk.edgia);
          yield { type: "done", finishReason: choice.finish_reason, usage: chunk.usage, edgia: chunk.edgia, sources: chunk.edgia?.sources ?? null, requestId };
        }
      }
    }
    if (!finished) throw new EdgiaCoreError("Flux interrompu avant [DONE]", { code: "stream_truncated", requestId });
  }

  /**
   * Apprentissage par le chat : propose un FAIT (`{ text }`) ou une conversation corrigée (`{ messages }`, user/assistant en alternance).
   * `consent` doit être true (le consentement vient de l'utilisateur, jamais d'une valeur par défaut). La leçon reste en attente de relecture.
   * Retourne { id, kind, status, indexed, pii_redactions } ; le contenu n'est jamais renvoyé.
   */
  async teach(kind, { text, messages, consent }) {
    const body = { kind, consent: consent === true };
    if (text !== undefined) body.text = text;
    if (messages !== undefined) body.messages = messages.map(({ role, content }) => ({ role, content }));
    return (await this.#postWithBusyRetry("/v1/learning/lessons", body)).json();
  }

  /** Leçons de la clé du client (sans contenu), filtre facultatif : "pending" | "approved" | "rejected". */
  async lessons(status) {
    const query = status ? `?status=${encodeURIComponent(status)}` : "";
    return (await (await this.#fetch(`/v1/learning/lessons${query}`)).json()).data;
  }

  /** Retire une leçon (retrait du consentement). */
  async withdrawLesson(id) {
    return (await this.#fetch(`/v1/learning/lessons/${encodeURIComponent(id)}`, { method: "DELETE" })).json();
  }

  async search(query, { topK = 5, collection } = {}) {
    const body = { query, top_k: topK };
    if (collection) body.collection = collection;
    return (await (await this.#postWithBusyRetry("/v1/knowledge/search", body)).json()).data;
  }
}
