#!/usr/bin/env python3
"""Prouve que les fichiers EXISTANTS du projet n'ont pas été modifiés, hors des patches déclarés.

Compare l'arbre courant au manifeste de référence (`native_baseline/BASELINE_SHA256.txt`) :
  * fichier de référence absent            → SUPPRIMÉ  (interdit)
  * fichier de référence au contenu changé → MODIFIÉ   (autorisé UNIQUEMENT s'il figure dans PATCHED_FILES.json avec exactement
                                                       l'empreinte « patched_sha256 » déclarée)
  * fichier nouveau                        → AJOUTÉ    (autorisé UNIQUEMENT sous les préfixes déclarés ; les artefacts
                                                       d'exécution `__pycache__`, `*.pyc`, `.pytest_cache` sont ignorés)
Vérifie aussi la RÉVERSIBILITÉ : la copie d'origine de chaque fichier patché a bien l'empreinte de référence.
Code de sortie : 0 si tout est conforme, 1 sinon. Usage : python tools/verify_untouched.py [--root .] [--report rapport.md]
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from baseline_manifest import sha256_file, walk  # noqa: E402


def is_artifact(rel: str) -> bool:
    parts = rel.split("/")
    return "__pycache__" in parts or rel.endswith(".pyc") or ".pytest_cache" in parts


def verify(root: Path) -> dict:
    baseline_file = root / "native_baseline" / "BASELINE_SHA256.txt"
    declared = json.loads((root / "native_baseline" / "PATCHED_FILES.json").read_text(encoding="utf-8"))
    baseline = {}
    for line in baseline_file.read_text(encoding="utf-8").splitlines():
        digest, rel = line.split("  ", 1)
        baseline[rel] = digest
    patched = {p["path"]: p for p in declared["modified_files"]}
    current = walk(root)
    report = {"baseline_files": len(baseline), "unchanged": 0, "deleted": [], "modified_declared": [], "modified_unexpected": [],
              "added_allowed": 0, "added_unexpected": [], "ignored_artifacts": 0, "irreversible": []}
    for rel, digest in baseline.items():
        if rel not in current:
            report["deleted"].append(rel)
        elif current[rel] == digest:
            report["unchanged"] += 1
        elif rel in patched and current[rel] == patched[rel]["patched_sha256"] and patched[rel]["baseline_sha256"] == digest:
            report["modified_declared"].append(rel)
        else:
            report["modified_unexpected"].append(rel)
    prefixes = tuple(declared["allowed_new_prefixes"])
    root_files = set(declared["allowed_new_root_files"])
    for rel in sorted(set(current) - set(baseline)):
        if is_artifact(rel):
            report["ignored_artifacts"] += 1
        elif rel.startswith(prefixes) or rel in root_files:
            report["added_allowed"] += 1
        else:
            report["added_unexpected"].append(rel)
    for rel, info in patched.items():
        original = root / info["original_copy"]
        if not original.is_file() or sha256_file(original) != baseline.get(rel):
            report["irreversible"].append(rel)
    report["ok"] = not (report["deleted"] or report["modified_unexpected"] or report["added_unexpected"] or report["irreversible"])
    return report


def render(report: dict) -> str:
    lines = ["# Rapport de vérification d'intégrité (existant vs référence)", "",
             f"- Fichiers de référence : {report['baseline_files']}",
             f"- Inchangés : {report['unchanged']}",
             f"- Modifiés et déclarés (patches) : {len(report['modified_declared'])} → {', '.join(report['modified_declared']) or '—'}",
             f"- Modifiés NON déclarés : {len(report['modified_unexpected'])} {report['modified_unexpected']}",
             f"- Supprimés : {len(report['deleted'])} {report['deleted']}",
             f"- Ajoutés (dossiers autorisés) : {report['added_allowed']}",
             f"- Ajoutés hors dossiers autorisés : {len(report['added_unexpected'])} {report['added_unexpected']}",
             f"- Artefacts d'exécution ignorés (__pycache__, *.pyc) : {report['ignored_artifacts']}",
             f"- Patches non réversibles : {report['irreversible']}", "",
             f"**Résultat : {'CONFORME' if report['ok'] else 'NON CONFORME'}**", ""]
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=".")
    parser.add_argument("--report")
    args = parser.parse_args()
    report = verify(Path(args.root).resolve())
    text = render(report)
    print(text)
    if args.report:
        Path(args.report).write_text(text, encoding="utf-8")
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
