#!/usr/bin/env python3
"""Tests de mutation (spécification v1.1 §8.4) : on introduit une ERREUR VOLONTAIRE dans une COPIE du code et on vérifie que les
tests échouent. Un mutant qui « survit » révèle un test trop permissif. Le code livré n'est JAMAIS modifié.

Usage : python tools/mutation_check.py [--only ID ...] [--json rapport.json]
Limite assumée : les mutants dont `expected` vaut « survive_without_torch » ne peuvent être détectés que par la comparaison
PyTorch ↔ NumPy (M17), qui exige PyTorch ; ils sont listés honnêtement, pas cachés.
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
N = "src/edgia_core/native/"
T_REF, T_TOK, T_GEN = ["test_numpy_reference"], ["test_tokenizer"], ["test_generation"]
T_DATA, T_CK, T_REG = ["test_data_pipeline"], ["test_checkpoint_resume"], ["test_licenses_registry", "test_data_pipeline"]

MUTANTS = [
    ("GQA-mapping", N + "reference/numpy_model.py", "kv = head // group", "kv = head % cfg.n_kv_heads", T_REF),
    ("RoPE-offset-cache", N + "reference/numpy_model.py", "positions = np.arange(p0, p0 + t)", "positions = np.arange(0, t)", T_REF),
    ("masque-causal-avec-cache", N + "reference/numpy_model.py", "allowed = key_pos[None, :] <= positions[:, None]", "allowed = key_pos[None, :] <= np.arange(t)[:, None]", T_REF),
    ("attention-sans-racine-d", N + "reference/numpy_model.py", "scores = q @ k.T / np.sqrt(head_dim)", "scores = q @ k.T", T_REF),
    ("rmsnorm-sans-epsilon", N + "reference/numpy_model.py", "keepdims=True) + eps)", "keepdims=True) + 0.0)", T_REF),
    ("init-residuelle-non-reduite", N + "reference/numpy_model.py", "std = cfg.residual_init_std if name.endswith(naming.RESIDUAL_SUFFIXES) else cfg.init_std", "std = cfg.init_std", T_REF),
    ("swiglu-sans-silu", N + "reference/numpy_model.py", "return gate / (1.0 + np.exp(-gate)) * up", "return gate * up", T_REF),
    ("K-non-tourne-dans-le-cache", N + "reference/numpy_model.py", "k_new = np.stack([apply_rope(k[:, g], positions, cfg.rope_theta) for g in range(cfg.n_kv_heads)])", "k_new = np.stack([k[:, g] for g in range(cfg.n_kv_heads)])", T_REF),
    ("jeton-special-interprete-dans-le-texte", N + "tokenizer/tokenizer.py", "        return self._bpe.encode(text)\n\n    @staticmethod", "        return [specials.END] if text == \"<|end|>\" else self._bpe.encode(text)\n\n    @staticmethod", T_TOK),
    ("decodeur-flux-sans-tampon", N + "tokenizer/tokenizer.py", "return self._decoder.decode(data, final=False) if data else \"\"", "return data.decode(\"utf-8\", errors=\"replace\") if data else \"\"", T_TOK + T_GEN),
    ("masque-de-sortie-absent", N + "tokenizer/specials.py", "FORBIDDEN_OUTPUT_IDS = frozenset(range(N_SPECIAL)) - TERMINATOR_IDS", "FORBIDDEN_OUTPUT_IDS = frozenset()", T_TOK + T_GEN),
    ("tokenizer-entrainable-sur-val", N + "tokenizer/tokenizer.py", "if split != \"train\":", "if False:", T_TOK),
    ("chiffres-groupes", N + "tokenizer/pretokenizer.py", "    if _is_number(ch):\n        return i + 1", "    if _is_number(ch):\n        j = i + 1\n        while j < n and _is_number(text[j]):\n            j += 1\n        return j", ["test_pretokenizer", "test_tokenizer"]),
    ("normalisation-NFC-absente", N + "tokenizer/bpe.py", "    return unicodedata.normalize(\"NFC\", text)", "    return text", T_TOK),
    ("verrou-des-jetons-ignore", N + "tokenizer/tokenizer.py", "if raw.get(\"special_tokens_sha256\") != specials.lock_hash():", "if False:", T_TOK),
    ("quasi-doublons-non-regroupes", N + "data/dedup.py", "    for a, b, _ in near_pairs:\n        uf.union(a, b)", "    for a, b, _ in near_pairs:\n        pass", T_DATA),
    ("controle-de-fuite-desactive", N + "data/split.py", "        if fraction >= max_fraction:", "        if False:", T_DATA),
    ("porte-1-contournee", N + "data/registry.py", "        if self.decision_training != \"approved_training\":", "        if False:", T_REG),
    ("classe-B-sans-avis", N + "data/registry.py", "        if cls == licenses.CLASS_B and not self.training_review_ref:", "        if False:", T_REG),
    ("chargeur-pas-de-fenetre-faux", N + "data/loader.py", "start = (index - int(self._cum[shard])) * self.ctx", "start = (index - int(self._cum[shard])) * (self.ctx - 1)", T_DATA),
    ("chargeur-meme-permutation-a-chaque-epoque", N + "data/loader.py", "np.random.PCG64(self.seed + epoch)", "np.random.PCG64(self.seed)", T_DATA),
    ("tokenizer-entraine-sur-tout", N + "data/pipeline.py", "if split_of_doc[i] == \"train\" and i not in set(tokdev)]", "if i not in set(tokdev)]", T_DATA),
    ("reprise-sans-controle-d-empreintes", N + "train/checkpoint.py", "    if bad:\n        raise CheckpointError(\"reprise refusée", "    if False:\n        raise CheckpointError(\"reprise refusée", T_CK),
    ("verification-de-hash-checkpoint-absente", N + "train/checkpoint.py", "        elif sha256_file(file) != manifest[\"files\"].get(name):", "        elif False:", T_CK),
    ("marqueur-COMPLETE-jamais-ecrit", N + "train/checkpoint.py", "    (tmp / \"COMPLETE\").write_text(sha256_json(manifest) + \"\\n\", encoding=\"utf-8\")", "    pass", T_CK),
    ("echauffement-decale", N + "train/schedule.py", "return peak * (step + 1) / warm", "return peak * step / warm", T_CK),
    ("generation-ne-s-arrete-pas-sur-END", N + "generation.py", "if token in specials.TERMINATOR_IDS:", "if token in ():", T_GEN),
    ("generation-deborde-du-contexte", N + "generation.py", "if cache_len + 1 > max_seq_len:", "if cache_len + 1 > max_seq_len + 5:", T_GEN),
    ("glouton-prend-le-pire-token", N + "sampling.py", "return int(np.argmax(scores))", "return int(np.argmin(scores))", T_GEN),
    ("top-p-sans-le-token-franchissant", N + "sampling.py", "side=\"left\")) + 1", "side=\"left\"))", T_GEN),
    ("porte-2-contournee-a-l-export", N + "train/export.py", "        problems = distribution_problems(registry, sources_used, status)", "        problems = []", ["test_export"]),
    ("safetensors-trou-accepte", N + "safetensors_io.py", "        if entry.begin != cursor:", "        if False:", ["test_safetensors_io"]),
]
EXPECTED_SURVIVOR: dict[str, str] = {}  # aucun survivant attendu : chaque mutant doit être tué


def run_tests(workdir: Path, modules: list[str]) -> tuple[bool, str]:
    proc = subprocess.run([sys.executable, "tools/run_native_tests.py", *modules], cwd=workdir, capture_output=True, text=True, timeout=600)
    return proc.returncode == 0, (proc.stdout + proc.stderr)[-300:]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", nargs="*")
    parser.add_argument("--json")
    args = parser.parse_args()
    results, survivors = [], []
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp) / "w"
        (work / "src/edgia_core").mkdir(parents=True)
        shutil.copyfile(ROOT / "src/edgia_core/__init__.py", work / "src/edgia_core/__init__.py")
        shutil.copytree(ROOT / "src/edgia_core/native", work / "src/edgia_core/native", ignore=shutil.ignore_patterns("__pycache__"))
        for d in ("tests/native", "tools", "configs/native"):
            shutil.copytree(ROOT / d, work / d, ignore=shutil.ignore_patterns("__pycache__"))
        ok, tail = run_tests(work, sorted({m for mu in MUTANTS for m in mu[4]}))
        print(f"Référence (sans mutation) : {'tous les tests passent' if ok else 'ÉCHEC — mutation impossible'}")
        if not ok:
            print(tail)
            return 2
        for mid, rel, old, new, modules in MUTANTS:
            if args.only and mid not in args.only:
                continue
            target = work / rel
            original = target.read_text(encoding="utf-8")
            if original.count(old) != 1:
                results.append({"id": mid, "status": "INVALIDE (motif introuvable ou ambigu)"}); print(f"? {mid} : motif invalide"); survivors.append(mid)
                continue
            target.write_text(original.replace(old, new), encoding="utf-8")
            try:
                passed, tail = run_tests(work, modules)
            except subprocess.TimeoutExpired:
                passed, tail = False, "délai dépassé (considéré comme détecté)"
            finally:
                target.write_text(original, encoding="utf-8")
            status = "SURVIVANT" if passed else "tué"
            if passed and mid in EXPECTED_SURVIVOR:
                status = f"SURVIVANT ATTENDU ({EXPECTED_SURVIVOR[mid]})"
            elif passed:
                survivors.append(mid)
            results.append({"id": mid, "status": status, "tests": modules})
            print(f"{'✔' if not passed else ('·' if mid in EXPECTED_SURVIVOR else '✘')} {mid} : {status}")
    killed = sum(r["status"] == "tué" for r in results)
    summary = {"mutants": len(results), "killed": killed, "unexpected_survivors": survivors,
               "expected_survivors": [r["id"] for r in results if r["status"].startswith("SURVIVANT ATTENDU")]}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if args.json:
        Path(args.json).write_text(json.dumps({"summary": summary, "results": results}, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0 if not survivors else 1


if __name__ == "__main__":
    raise SystemExit(main())
