#!/usr/bin/env python3
"""Lance les tests d'EDG-IA Native avec unittest (aucune dépendance) ; compatible avec pytest (`pytest tests/native`).

Usage : python tools/run_native_tests.py [motif_de_fichier ...] [--verbose] [--json rapport.json]
Les tests qui exigent PyTorch, safetensors officiel ou pydantic sont SAUTÉS (et comptés comme tels) quand ces
bibliothèques sont absentes : un test sauté n'est PAS un test réussi.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tests" / "native")]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("patterns", nargs="*", default=["test_*.py"])
    parser.add_argument("--verbose", "-v", action="store_true")
    parser.add_argument("--json")
    args = parser.parse_args()
    suite = unittest.TestSuite()
    loader = unittest.TestLoader()
    for pattern in args.patterns:
        suite.addTests(loader.discover(str(ROOT / "tests" / "native"), pattern=pattern if pattern.endswith(".py") else pattern + ".py",
                                       top_level_dir=str(ROOT / "tests" / "native")))
    started = time.time()
    result = unittest.TextTestRunner(verbosity=2 if args.verbose else 1).run(suite)
    summary = {"tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
               "passed": result.testsRun - len(result.failures) - len(result.errors) - len(result.skipped),
               "skipped_reasons": sorted({reason for _, reason in result.skipped}), "seconds": round(time.time() - started, 1)}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if args.json:
        Path(args.json).write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
